-- GearGuard Database Schema
-- PostgreSQL

-- Create UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Equipment Table
CREATE TABLE equipment (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    serial_number VARCHAR(255) NOT NULL UNIQUE,
    department VARCHAR(100),
    assigned_employee VARCHAR(255),
    purchase_date DATE,
    warranty_info TEXT,
    location VARCHAR(255),
    default_team_id UUID,
    is_scrapped BOOLEAN DEFAULT FALSE,
    scrap_notes TEXT,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Teams Table
CREATE TABLE teams (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL UNIQUE,
    specialization VARCHAR(100),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Team Members Table
CREATE TABLE team_members (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    team_id UUID NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    role VARCHAR(100),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Maintenance Requests Table
CREATE TABLE maintenance_requests (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    subject VARCHAR(255) NOT NULL,
    description TEXT,
    equipment_id UUID NOT NULL REFERENCES equipment(id) ON DELETE CASCADE,
    request_type VARCHAR(50) NOT NULL CHECK (request_type IN ('Corrective', 'Preventive')),
    status VARCHAR(50) NOT NULL DEFAULT 'New' CHECK (status IN ('New', 'In Progress', 'Repaired', 'Scrap')),
    scheduled_date TIMESTAMP,
    duration INTEGER,
    assigned_team_id UUID REFERENCES teams(id),
    assigned_technician_id UUID REFERENCES team_members(id),
    category VARCHAR(100),
    priority VARCHAR(50) DEFAULT 'Medium' CHECK (priority IN ('Low', 'Medium', 'High')),
    hours_spent INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Foreign Key Constraints
ALTER TABLE equipment ADD CONSTRAINT fk_equipment_team 
    FOREIGN KEY (default_team_id) REFERENCES teams(id) ON DELETE SET NULL;

-- Indexes for performance
CREATE INDEX idx_equipment_department ON equipment(department);
CREATE INDEX idx_equipment_team ON equipment(default_team_id);
CREATE INDEX idx_maintenance_status ON maintenance_requests(status);
CREATE INDEX idx_maintenance_equipment ON maintenance_requests(equipment_id);
CREATE INDEX idx_maintenance_team ON maintenance_requests(assigned_team_id);
CREATE INDEX idx_maintenance_scheduled ON maintenance_requests(scheduled_date);
CREATE INDEX idx_team_members_team ON team_members(team_id);

-- Sample Data (Optional)
-- INSERT INTO teams (name, specialization) VALUES 
-- ('Mechanics', 'Mechanical Systems'),
-- ('Electricians', 'Electrical Systems'),
-- ('IT Support', 'Computer Systems'),
-- ('HVAC Team', 'Climate Control');
