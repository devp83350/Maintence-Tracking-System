"""
GearGuard Backend Server - Python Implementation
A lightweight maintenance tracking system backend
"""

from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
import json
import uuid
from datetime import datetime
from typing import Dict, List, Any
import os

# In-memory databases (will reset on restart)
EQUIPMENT_DB: Dict[str, Dict] = {}
TEAMS_DB: Dict[str, Dict] = {}
TEAM_MEMBERS_DB: Dict[str, Dict] = {}
REQUESTS_DB: Dict[str, Dict] = {}

class Equipment:
    @staticmethod
    def create(data: Dict) -> Dict:
        id = str(uuid.uuid4())
        equipment = {
            'id': id,
            'name': data.get('name'),
            'serial_number': data.get('serial_number'),
            'department': data.get('department'),
            'assigned_employee': data.get('assigned_employee'),
            'purchase_date': data.get('purchase_date'),
            'warranty_info': data.get('warranty_info'),
            'location': data.get('location'),
            'default_team_id': data.get('default_team_id'),
            'is_scrapped': False,
            'created_at': datetime.now().isoformat(),
            'updated_at': datetime.now().isoformat()
        }
        EQUIPMENT_DB[id] = equipment
        return equipment

    @staticmethod
    def get_all() -> List[Dict]:
        result = []
        for equip in EQUIPMENT_DB.values():
            team_name = None
            if equip.get('default_team_id') and equip['default_team_id'] in TEAMS_DB:
                team_name = TEAMS_DB[equip['default_team_id']]['name']
            
            # Count open maintenance requests
            open_count = sum(1 for req in REQUESTS_DB.values() 
                           if req['equipment_id'] == equip['id'] and req['status'] in ['New', 'In Progress'])
            
            result.append({**equip, 'team_name': team_name, 'open_maintenance_count': open_count})
        return result

    @staticmethod
    def get_by_id(id: str) -> Dict:
        equip = EQUIPMENT_DB.get(id)
        if equip:
            team_name = None
            if equip.get('default_team_id') and equip['default_team_id'] in TEAMS_DB:
                team_name = TEAMS_DB[equip['default_team_id']]['name']
            open_count = sum(1 for req in REQUESTS_DB.values() 
                           if req['equipment_id'] == id and req['status'] in ['New', 'In Progress'])
            return {**equip, 'team_name': team_name, 'open_maintenance_count': open_count}
        return None

    @staticmethod
    def update(id: str, data: Dict) -> Dict:
        if id in EQUIPMENT_DB:
            EQUIPMENT_DB[id].update({
                'name': data.get('name', EQUIPMENT_DB[id]['name']),
                'serial_number': data.get('serial_number', EQUIPMENT_DB[id]['serial_number']),
                'department': data.get('department', EQUIPMENT_DB[id]['department']),
                'assigned_employee': data.get('assigned_employee', EQUIPMENT_DB[id]['assigned_employee']),
                'purchase_date': data.get('purchase_date', EQUIPMENT_DB[id]['purchase_date']),
                'warranty_info': data.get('warranty_info', EQUIPMENT_DB[id]['warranty_info']),
                'location': data.get('location', EQUIPMENT_DB[id]['location']),
                'default_team_id': data.get('default_team_id', EQUIPMENT_DB[id]['default_team_id']),
                'updated_at': datetime.now().isoformat()
            })
            return Equipment.get_by_id(id)
        return None

    @staticmethod
    def delete(id: str) -> bool:
        if id in EQUIPMENT_DB:
            del EQUIPMENT_DB[id]
            return True
        return False

class Team:
    @staticmethod
    def create(data: Dict) -> Dict:
        id = str(uuid.uuid4())
        team = {
            'id': id,
            'name': data.get('name'),
            'specialization': data.get('specialization'),
            'member_count': 0,
            'created_at': datetime.now().isoformat(),
            'updated_at': datetime.now().isoformat()
        }
        TEAMS_DB[id] = team
        return team

    @staticmethod
    def get_all() -> List[Dict]:
        result = []
        for team in TEAMS_DB.values():
            member_count = sum(1 for m in TEAM_MEMBERS_DB.values() if m['team_id'] == team['id'])
            result.append({**team, 'member_count': member_count})
        return result

    @staticmethod
    def get_by_id(id: str) -> Dict:
        if id in TEAMS_DB:
            members = [m for m in TEAM_MEMBERS_DB.values() if m['team_id'] == id]
            return {**TEAMS_DB[id], 'members': members}
        return None

    @staticmethod
    def update(id: str, data: Dict) -> Dict:
        if id in TEAMS_DB:
            TEAMS_DB[id].update({
                'name': data.get('name', TEAMS_DB[id]['name']),
                'specialization': data.get('specialization', TEAMS_DB[id]['specialization']),
                'updated_at': datetime.now().isoformat()
            })
            return TEAMS_DB[id]
        return None

    @staticmethod
    def delete(id: str) -> bool:
        if id in TEAMS_DB:
            # Delete members too
            TEAM_MEMBERS_DB.clear()
            del TEAMS_DB[id]
            return True
        return False

    @staticmethod
    def add_member(team_id: str, data: Dict) -> Dict:
        member_id = str(uuid.uuid4())
        member = {
            'id': member_id,
            'team_id': team_id,
            'name': data.get('name'),
            'role': data.get('role'),
            'created_at': datetime.now().isoformat()
        }
        TEAM_MEMBERS_DB[member_id] = member
        return member

    @staticmethod
    def get_members(team_id: str) -> List[Dict]:
        return [m for m in TEAM_MEMBERS_DB.values() if m['team_id'] == team_id]

class MaintenanceRequest:
    @staticmethod
    def create(data: Dict) -> Dict:
        id = str(uuid.uuid4())
        
        # Auto-fill team and category from equipment
        equipment_id = data.get('equipment_id')
        equipment = Equipment.get_by_id(equipment_id)
        
        request = {
            'id': id,
            'subject': data.get('subject'),
            'description': data.get('description', ''),
            'equipment_id': equipment_id,
            'request_type': data.get('request_type', 'Corrective'),
            'status': data.get('status', 'New'),
            'scheduled_date': data.get('scheduled_date'),
            'duration': data.get('duration'),
            'assigned_team_id': equipment.get('default_team_id') if equipment else data.get('assigned_team_id'),
            'assigned_technician_id': data.get('assigned_technician_id'),
            'category': data.get('category', equipment.get('department') if equipment else 'General'),
            'priority': data.get('priority', 'Medium'),
            'hours_spent': data.get('hours_spent', 0),
            'created_at': datetime.now().isoformat(),
            'updated_at': datetime.now().isoformat()
        }
        REQUESTS_DB[id] = request
        return MaintenanceRequest.get_by_id(id)

    @staticmethod
    def get_all(filters: Dict = None) -> List[Dict]:
        result = []
        for req in REQUESTS_DB.values():
            # Apply filters
            if filters:
                if filters.get('status') and req['status'] != filters['status']:
                    continue
                if filters.get('team_id') and req['assigned_team_id'] != filters['team_id']:
                    continue
                if filters.get('equipment_id') and req['equipment_id'] != filters['equipment_id']:
                    continue
                if filters.get('request_type') and req['request_type'] != filters['request_type']:
                    continue
            
            # Get related data
            equipment = Equipment.get_by_id(req['equipment_id'])
            team = TEAMS_DB.get(req.get('assigned_team_id'), {})
            technician = TEAM_MEMBERS_DB.get(req.get('assigned_technician_id'), {})
            
            result.append({
                **req,
                'equipment_name': equipment.get('name') if equipment else 'Unknown',
                'team_name': team.get('name'),
                'technician_name': technician.get('name')
            })
        
        return sorted(result, key=lambda x: x['created_at'], reverse=True)

    @staticmethod
    def get_by_id(id: str) -> Dict:
        if id in REQUESTS_DB:
            req = REQUESTS_DB[id]
            equipment = Equipment.get_by_id(req['equipment_id'])
            team = TEAMS_DB.get(req.get('assigned_team_id'), {})
            technician = TEAM_MEMBERS_DB.get(req.get('assigned_technician_id'), {})
            
            return {
                **req,
                'equipment_name': equipment.get('name') if equipment else 'Unknown',
                'team_name': team.get('name'),
                'technician_name': technician.get('name')
            }
        return None

    @staticmethod
    def update(id: str, data: Dict) -> Dict:
        if id in REQUESTS_DB:
            REQUESTS_DB[id].update({
                'subject': data.get('subject', REQUESTS_DB[id]['subject']),
                'description': data.get('description', REQUESTS_DB[id]['description']),
                'status': data.get('status', REQUESTS_DB[id]['status']),
                'assigned_technician_id': data.get('assigned_technician_id', REQUESTS_DB[id]['assigned_technician_id']),
                'hours_spent': data.get('hours_spent', REQUESTS_DB[id]['hours_spent']),
                'scheduled_date': data.get('scheduled_date', REQUESTS_DB[id]['scheduled_date']),
                'priority': data.get('priority', REQUESTS_DB[id]['priority']),
                'updated_at': datetime.now().isoformat()
            })
            return MaintenanceRequest.get_by_id(id)
        return None

    @staticmethod
    def update_status(id: str, status: str) -> Dict:
        if id in REQUESTS_DB:
            REQUESTS_DB[id]['status'] = status
            REQUESTS_DB[id]['updated_at'] = datetime.now().isoformat()
            return MaintenanceRequest.get_by_id(id)
        return None

    @staticmethod
    def delete(id: str) -> bool:
        if id in REQUESTS_DB:
            del REQUESTS_DB[id]
            return True
        return False

    @staticmethod
    def get_stats() -> Dict:
        total = len(REQUESTS_DB)
        new_count = sum(1 for r in REQUESTS_DB.values() if r['status'] == 'New')
        in_progress = sum(1 for r in REQUESTS_DB.values() if r['status'] == 'In Progress')
        repaired = sum(1 for r in REQUESTS_DB.values() if r['status'] == 'Repaired')
        scrap = sum(1 for r in REQUESTS_DB.values() if r['status'] == 'Scrap')
        
        return {
            'total_requests': total,
            'new_count': new_count,
            'in_progress_count': in_progress,
            'repaired_count': repaired,
            'scrap_count': scrap
        }

class GearGuardHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        path = urlparse(self.path).path
        query_params = parse_qs(urlparse(self.path).query)
        
        # Convert query params to simple dict
        filters = {}
        if 'status' in query_params:
            filters['status'] = query_params['status'][0]
        if 'team_id' in query_params:
            filters['team_id'] = query_params['team_id'][0]
        if 'equipment_id' in query_params:
            filters['equipment_id'] = query_params['equipment_id'][0]
        if 'request_type' in query_params:
            filters['request_type'] = query_params['request_type'][0]
        
        # Equipment endpoints
        if path == '/api/equipment':
            self.send_json_response(Equipment.get_all())
        elif path.startswith('/api/equipment/') and path.endswith('/maintenance'):
            equip_id = path.split('/')[3]
            reqs = MaintenanceRequest.get_all({'equipment_id': equip_id})
            self.send_json_response(reqs)
        elif path.startswith('/api/equipment/'):
            equip_id = path.split('/')[3]
            equip = Equipment.get_by_id(equip_id)
            self.send_json_response(equip if equip else {'error': 'Not found'}, 404 if not equip else 200)
        
        # Team endpoints
        elif path == '/api/team':
            self.send_json_response(Team.get_all())
        elif path.startswith('/api/team/') and '/members' in path:
            parts = path.split('/')
            team_id = parts[3]
            self.send_json_response(Team.get_members(team_id))
        elif path.startswith('/api/team/'):
            team_id = path.split('/')[3]
            team = Team.get_by_id(team_id)
            self.send_json_response(team if team else {'error': 'Not found'}, 404 if not team else 200)
        
        # Request endpoints
        elif path == '/api/request':
            reqs = MaintenanceRequest.get_all(filters if filters else None)
            self.send_json_response(reqs)
        elif path == '/api/request/stats/summary':
            self.send_json_response(MaintenanceRequest.get_stats())
        elif path.startswith('/api/request/'):
            req_id = path.split('/')[3]
            req = MaintenanceRequest.get_by_id(req_id)
            self.send_json_response(req if req else {'error': 'Not found'}, 404 if not req else 200)
        
        # Health check
        elif path == '/api/health':
            self.send_json_response({'status': 'OK', 'message': 'GearGuard API is running'})
        
        else:
            self.send_error(404)

    def do_POST(self):
        path = urlparse(self.path).path
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length).decode('utf-8')
        
        try:
            data = json.loads(body) if body else {}
        except:
            data = {}
        
        # Equipment endpoints
        if path == '/api/equipment':
            result = Equipment.create(data)
            self.send_json_response(result, 201)
        
        # Team endpoints
        elif path == '/api/team':
            result = Team.create(data)
            self.send_json_response(result, 201)
        elif '/members' in path and 'team' in path:
            team_id = path.split('/')[3]
            result = Team.add_member(team_id, data)
            self.send_json_response(result, 201)
        
        # Request endpoints
        elif path == '/api/request':
            result = MaintenanceRequest.create(data)
            self.send_json_response(result, 201)
        
        else:
            self.send_error(404)

    def do_PUT(self):
        path = urlparse(self.path).path
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length).decode('utf-8')
        
        try:
            data = json.loads(body) if body else {}
        except:
            data = {}
        
        # Equipment endpoints
        if path.startswith('/api/equipment/'):
            equip_id = path.split('/')[3]
            result = Equipment.update(equip_id, data)
            self.send_json_response(result if result else {'error': 'Not found'}, 404 if not result else 200)
        
        # Team endpoints
        elif path.startswith('/api/team/'):
            team_id = path.split('/')[3]
            result = Team.update(team_id, data)
            self.send_json_response(result if result else {'error': 'Not found'}, 404 if not result else 200)
        
        # Request endpoints
        elif path.startswith('/api/request/'):
            req_id = path.split('/')[3]
            result = MaintenanceRequest.update(req_id, data)
            self.send_json_response(result if result else {'error': 'Not found'}, 404 if not result else 200)
        
        else:
            self.send_error(404)

    def do_PATCH(self):
        path = urlparse(self.path).path
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length).decode('utf-8')
        
        try:
            data = json.loads(body) if body else {}
        except:
            data = {}
        
        # Request status endpoints
        if '/status' in path and path.startswith('/api/request/'):
            req_id = path.split('/')[3]
            status = data.get('status')
            result = MaintenanceRequest.update_status(req_id, status)
            self.send_json_response(result if result else {'error': 'Not found'}, 404 if not result else 200)
        
        else:
            self.send_error(404)

    def do_DELETE(self):
        path = urlparse(self.path).path
        
        # Equipment endpoints
        if path.startswith('/api/equipment/'):
            equip_id = path.split('/')[3]
            Equipment.delete(equip_id)
            self.send_json_response({'message': 'Deleted'})
        
        # Team endpoints
        elif path.startswith('/api/team/'):
            team_id = path.split('/')[3]
            Team.delete(team_id)
            self.send_json_response({'message': 'Deleted'})
        elif 'members' in path:
            member_id = path.split('/')[4]
            if member_id in TEAM_MEMBERS_DB:
                del TEAM_MEMBERS_DB[member_id]
            self.send_json_response({'message': 'Deleted'})
        
        # Request endpoints
        elif path.startswith('/api/request/'):
            req_id = path.split('/')[3]
            MaintenanceRequest.delete(req_id)
            self.send_json_response({'message': 'Deleted'})
        
        else:
            self.send_error(404)

    def send_json_response(self, data: Any, status_code: int = 200):
        self.send_response(status_code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()
        
        response = json.dumps(data)
        self.wfile.write(response.encode('utf-8'))

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

    def log_message(self, format, *args):
        print(f"[{self.log_date_time_string()}] {format % args}")

if __name__ == '__main__':
    PORT = 5000
    server = HTTPServer(('0.0.0.0', PORT), GearGuardHandler)
    print(f'✓ GearGuard Backend running on http://localhost:{PORT}')
    print(f'✓ API Base: http://localhost:{PORT}/api')
    print(f'✓ Health Check: http://localhost:{PORT}/api/health')
    server.serve_forever()
