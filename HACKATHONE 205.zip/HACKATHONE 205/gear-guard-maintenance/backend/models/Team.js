const db = require('../config/database');
const { v4: uuidv4 } = require('uuid');

class Team {
  static async create(data) {
    const id = uuidv4();
    const query = `
      INSERT INTO teams (id, name, specialization, created_at)
      VALUES ($1, $2, $3, NOW())
      RETURNING *;
    `;
    const values = [id, data.name, data.specialization];
    const result = await db.query(query, values);
    return result.rows[0];
  }

  static async findAll() {
    const query = `
      SELECT t.*, COUNT(tm.id) as member_count
      FROM teams t
      LEFT JOIN team_members tm ON t.id = tm.team_id
      GROUP BY t.id
      ORDER BY t.created_at DESC;
    `;
    const result = await db.query(query);
    return result.rows;
  }

  static async findById(id) {
    const query = `
      SELECT t.*,
        json_agg(json_build_object('id', tm.id, 'name', tm.name, 'role', tm.role)) as members
      FROM teams t
      LEFT JOIN team_members tm ON t.id = tm.team_id
      WHERE t.id = $1
      GROUP BY t.id;
    `;
    const result = await db.query(query, [id]);
    return result.rows[0];
  }

  static async update(id, data) {
    const query = `
      UPDATE teams
      SET name = $1, specialization = $2, updated_at = NOW()
      WHERE id = $3
      RETURNING *;
    `;
    const values = [data.name, data.specialization, id];
    const result = await db.query(query, values);
    return result.rows[0];
  }

  static async delete(id) {
    const query = 'DELETE FROM teams WHERE id = $1 RETURNING *;';
    const result = await db.query(query, [id]);
    return result.rows[0];
  }

  static async addMember(teamId, memberData) {
    const id = uuidv4();
    const query = `
      INSERT INTO team_members (id, team_id, name, role, created_at)
      VALUES ($1, $2, $3, $4, NOW())
      RETURNING *;
    `;
    const values = [id, teamId, memberData.name, memberData.role];
    const result = await db.query(query, values);
    return result.rows[0];
  }

  static async getMembers(teamId) {
    const query = `
      SELECT * FROM team_members WHERE team_id = $1 ORDER BY created_at;
    `;
    const result = await db.query(query, [teamId]);
    return result.rows;
  }

  static async removeMember(memberId) {
    const query = 'DELETE FROM team_members WHERE id = $1 RETURNING *;';
    const result = await db.query(query, [memberId]);
    return result.rows[0];
  }
}

module.exports = Team;
