const db = require('../config/database');
const { v4: uuidv4 } = require('uuid');

class Equipment {
  static async create(data) {
    const id = uuidv4();
    const query = `
      INSERT INTO equipment (id, name, serial_number, department, assigned_employee, purchase_date, warranty_info, location, default_team_id, created_at)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, NOW())
      RETURNING *;
    `;
    const values = [
      id,
      data.name,
      data.serial_number,
      data.department,
      data.assigned_employee,
      data.purchase_date,
      data.warranty_info,
      data.location,
      data.default_team_id,
    ];
    const result = await db.query(query, values);
    return result.rows[0];
  }

  static async findAll() {
    const query = `
      SELECT e.*, t.name as team_name
      FROM equipment e
      LEFT JOIN teams t ON e.default_team_id = t.id
      ORDER BY e.created_at DESC;
    `;
    const result = await db.query(query);
    return result.rows;
  }

  static async findById(id) {
    const query = `
      SELECT e.*, t.name as team_name
      FROM equipment e
      LEFT JOIN teams t ON e.default_team_id = t.id
      WHERE e.id = $1;
    `;
    const result = await db.query(query, [id]);
    return result.rows[0];
  }

  static async update(id, data) {
    const query = `
      UPDATE equipment
      SET name = $1, serial_number = $2, department = $3, assigned_employee = $4,
          purchase_date = $5, warranty_info = $6, location = $7, default_team_id = $8,
          updated_at = NOW()
      WHERE id = $9
      RETURNING *;
    `;
    const values = [
      data.name,
      data.serial_number,
      data.department,
      data.assigned_employee,
      data.purchase_date,
      data.warranty_info,
      data.location,
      data.default_team_id,
      id,
    ];
    const result = await db.query(query, values);
    return result.rows[0];
  }

  static async delete(id) {
    const query = 'DELETE FROM equipment WHERE id = $1 RETURNING *;';
    const result = await db.query(query, [id]);
    return result.rows[0];
  }

  static async getMaintenanceCount(equipmentId) {
    const query = `
      SELECT COUNT(*) as count FROM maintenance_requests
      WHERE equipment_id = $1 AND status IN ('New', 'In Progress');
    `;
    const result = await db.query(query, [equipmentId]);
    return parseInt(result.rows[0].count);
  }
}

module.exports = Equipment;
