const db = require('../config/database');
const { v4: uuidv4 } = require('uuid');

class MaintenanceRequest {
  static async create(data) {
    const id = uuidv4();
    
    // Get equipment details to auto-fill team and category
    const equipmentQuery = 'SELECT * FROM equipment WHERE id = $1';
    const equipmentResult = await db.query(equipmentQuery, [data.equipment_id]);
    const equipment = equipmentResult.rows[0];

    const query = `
      INSERT INTO maintenance_requests (
        id, subject, description, equipment_id, request_type, status,
        scheduled_date, duration, assigned_team_id, assigned_technician_id,
        category, priority, hours_spent, created_at
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, NOW())
      RETURNING *;
    `;

    const values = [
      id,
      data.subject,
      data.description,
      data.equipment_id,
      data.request_type || 'Corrective',
      data.status || 'New',
      data.scheduled_date,
      data.duration,
      equipment?.default_team_id || data.assigned_team_id,
      data.assigned_technician_id,
      data.category || equipment?.department || 'General',
      data.priority || 'Medium',
      data.hours_spent || 0,
    ];

    const result = await db.query(query, values);
    return result.rows[0];
  }

  static async findAll(filters = {}) {
    let query = `
      SELECT mr.*, e.name as equipment_name, e.department,
             t.name as team_name, tm.name as technician_name
      FROM maintenance_requests mr
      LEFT JOIN equipment e ON mr.equipment_id = e.id
      LEFT JOIN teams t ON mr.assigned_team_id = t.id
      LEFT JOIN team_members tm ON mr.assigned_technician_id = tm.id
      WHERE 1=1
    `;

    const values = [];
    let paramCount = 1;

    if (filters.status) {
      query += ` AND mr.status = $${paramCount}`;
      values.push(filters.status);
      paramCount++;
    }

    if (filters.team_id) {
      query += ` AND mr.assigned_team_id = $${paramCount}`;
      values.push(filters.team_id);
      paramCount++;
    }

    if (filters.equipment_id) {
      query += ` AND mr.equipment_id = $${paramCount}`;
      values.push(filters.equipment_id);
      paramCount++;
    }

    if (filters.request_type) {
      query += ` AND mr.request_type = $${paramCount}`;
      values.push(filters.request_type);
      paramCount++;
    }

    query += ' ORDER BY mr.created_at DESC;';

    const result = await db.query(query, values);
    return result.rows;
  }

  static async findById(id) {
    const query = `
      SELECT mr.*, e.name as equipment_name, e.department,
             t.name as team_name, tm.name as technician_name
      FROM maintenance_requests mr
      LEFT JOIN equipment e ON mr.equipment_id = e.id
      LEFT JOIN teams t ON mr.assigned_team_id = t.id
      LEFT JOIN team_members tm ON mr.assigned_technician_id = tm.id
      WHERE mr.id = $1;
    `;
    const result = await db.query(query, [id]);
    return result.rows[0];
  }

  static async update(id, data) {
    const query = `
      UPDATE maintenance_requests
      SET subject = $1, description = $2, status = $3, assigned_technician_id = $4,
          hours_spent = $5, scheduled_date = $6, priority = $7, updated_at = NOW()
      WHERE id = $8
      RETURNING *;
    `;

    const values = [
      data.subject,
      data.description,
      data.status,
      data.assigned_technician_id,
      data.hours_spent,
      data.scheduled_date,
      data.priority,
      id,
    ];

    const result = await db.query(query, values);
    return result.rows[0];
  }

  static async updateStatus(id, newStatus) {
    const query = `
      UPDATE maintenance_requests
      SET status = $1, updated_at = NOW()
      WHERE id = $2
      RETURNING *;
    `;
    const result = await db.query(query, [newStatus, id]);
    return result.rows[0];
  }

  static async delete(id) {
    const query = 'DELETE FROM maintenance_requests WHERE id = $1 RETURNING *;';
    const result = await db.query(query, [id]);
    return result.rows[0];
  }

  static async getOverdueRequests() {
    const query = `
      SELECT mr.*, e.name as equipment_name, t.name as team_name
      FROM maintenance_requests mr
      LEFT JOIN equipment e ON mr.equipment_id = e.id
      LEFT JOIN teams t ON mr.assigned_team_id = t.id
      WHERE mr.status IN ('New', 'In Progress')
      AND mr.scheduled_date < NOW()
      ORDER BY mr.scheduled_date ASC;
    `;
    const result = await db.query(query);
    return result.rows;
  }

  static async getStatistics() {
    const query = `
      SELECT
        COUNT(*) as total_requests,
        SUM(CASE WHEN status = 'New' THEN 1 ELSE 0 END) as new_count,
        SUM(CASE WHEN status = 'In Progress' THEN 1 ELSE 0 END) as in_progress_count,
        SUM(CASE WHEN status = 'Repaired' THEN 1 ELSE 0 END) as repaired_count,
        SUM(CASE WHEN status = 'Scrap' THEN 1 ELSE 0 END) as scrap_count
      FROM maintenance_requests;
    `;
    const result = await db.query(query);
    return result.rows[0];
  }
}

module.exports = MaintenanceRequest;
