const express = require('express');
const router = express.Router();
const Equipment = require('../models/Equipment');

// Create equipment
router.post('/', async (req, res) => {
  try {
    const equipment = await Equipment.create(req.body);
    res.status(201).json(equipment);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get all equipment
router.get('/', async (req, res) => {
  try {
    const equipment = await Equipment.findAll();
    res.json(equipment);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get equipment by ID
router.get('/:id', async (req, res) => {
  try {
    const equipment = await Equipment.findById(req.params.id);
    if (!equipment) {
      return res.status(404).json({ error: 'Equipment not found' });
    }
    const maintenanceCount = await Equipment.getMaintenanceCount(req.params.id);
    res.json({ ...equipment, open_maintenance_count: maintenanceCount });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update equipment
router.put('/:id', async (req, res) => {
  try {
    const equipment = await Equipment.update(req.params.id, req.body);
    res.json(equipment);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Delete equipment
router.delete('/:id', async (req, res) => {
  try {
    const equipment = await Equipment.delete(req.params.id);
    res.json({ message: 'Equipment deleted', equipment });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get maintenance requests for equipment
router.get('/:id/maintenance', async (req, res) => {
  try {
    const MaintenanceRequest = require('../models/MaintenanceRequest');
    const requests = await MaintenanceRequest.findAll({ equipment_id: req.params.id });
    res.json(requests);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
