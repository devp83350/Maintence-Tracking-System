const express = require('express');
const router = express.Router();
const MaintenanceRequest = require('../models/MaintenanceRequest');

// Create maintenance request
router.post('/', async (req, res) => {
  try {
    const request = await MaintenanceRequest.create(req.body);
    res.status(201).json(request);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get all requests with filters
router.get('/', async (req, res) => {
  try {
    const filters = {
      status: req.query.status,
      team_id: req.query.team_id,
      equipment_id: req.query.equipment_id,
      request_type: req.query.request_type,
    };
    const requests = await MaintenanceRequest.findAll(filters);
    res.json(requests);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get request by ID
router.get('/:id', async (req, res) => {
  try {
    const request = await MaintenanceRequest.findById(req.params.id);
    if (!request) {
      return res.status(404).json({ error: 'Request not found' });
    }
    res.json(request);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update request
router.put('/:id', async (req, res) => {
  try {
    const request = await MaintenanceRequest.update(req.params.id, req.body);
    res.json(request);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update request status
router.patch('/:id/status', async (req, res) => {
  try {
    const request = await MaintenanceRequest.updateStatus(req.params.id, req.body.status);
    res.json(request);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Delete request
router.delete('/:id', async (req, res) => {
  try {
    const request = await MaintenanceRequest.delete(req.params.id);
    res.json({ message: 'Request deleted', request });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get overdue requests
router.get('/status/overdue', async (req, res) => {
  try {
    const requests = await MaintenanceRequest.getOverdueRequests();
    res.json(requests);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get statistics
router.get('/stats/summary', async (req, res) => {
  try {
    const stats = await MaintenanceRequest.getStatistics();
    res.json(stats);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
