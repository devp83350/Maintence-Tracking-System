const express = require('express');
const router = express.Router();
const Team = require('../models/Team');

// Create team
router.post('/', async (req, res) => {
  try {
    const team = await Team.create(req.body);
    res.status(201).json(team);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get all teams
router.get('/', async (req, res) => {
  try {
    const teams = await Team.findAll();
    res.json(teams);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get team by ID
router.get('/:id', async (req, res) => {
  try {
    const team = await Team.findById(req.params.id);
    if (!team) {
      return res.status(404).json({ error: 'Team not found' });
    }
    res.json(team);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update team
router.put('/:id', async (req, res) => {
  try {
    const team = await Team.update(req.params.id, req.body);
    res.json(team);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Delete team
router.delete('/:id', async (req, res) => {
  try {
    const team = await Team.delete(req.params.id);
    res.json({ message: 'Team deleted', team });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Add team member
router.post('/:teamId/members', async (req, res) => {
  try {
    const member = await Team.addMember(req.params.teamId, req.body);
    res.status(201).json(member);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get team members
router.get('/:teamId/members', async (req, res) => {
  try {
    const members = await Team.getMembers(req.params.teamId);
    res.json(members);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Remove team member
router.delete('/members/:memberId', async (req, res) => {
  try {
    const member = await Team.removeMember(req.params.memberId);
    res.json({ message: 'Member removed', member });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
