const express = require('express');
const cors = require('express-cors');
const bodyParser = require('body-parser');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cors());

// Database
const db = require('./config/database');

// Initialize database
db.initialize();

// Routes
const equipmentRoutes = require('./routes/equipment');
const teamRoutes = require('./routes/team');
const requestRoutes = require('./routes/request');

app.use('/api/equipment', equipmentRoutes);
app.use('/api/team', teamRoutes);
app.use('/api/request', requestRoutes);

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', message: 'GearGuard API is running' });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Internal Server Error', message: err.message });
});

app.listen(PORT, () => {
  console.log(`GearGuard Backend running on http://localhost:${PORT}`);
});
