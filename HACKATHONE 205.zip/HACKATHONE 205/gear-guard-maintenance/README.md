# GearGuard - The Ultimate Maintenance Tracker 🔧

A comprehensive, modular maintenance management system designed for companies to efficiently track assets, manage maintenance teams, and handle repair requests.

## Features

### ✅ Core Functionality

- **Equipment Management**: Track all company assets with detailed records including serial numbers, departments, locations, and warranty information
- **Team Management**: Create specialized maintenance teams and manage team members
- **Maintenance Requests**: Handle both corrective (breakdown) and preventive (routine) maintenance requests
- **Automated Workflows**: Auto-filling of equipment data when creating requests
- **Status Tracking**: Track requests through lifecycle stages (New → In Progress → Repaired → Scrap)

### 📊 User Interfaces

- **Kanban Board**: Visualize requests by status with drag-and-drop functionality
- **Calendar View**: Schedule and view preventive maintenance on a calendar
- **Dashboard**: Real-time statistics and recent requests overview
- **Reports & Analytics**: Visual insights on request distribution by team and category

### 🎯 Smart Features

- **Auto-Fill**: Automatically populate equipment category and team when equipment is selected
- **Overdue Highlighting**: Red indicators for overdue requests
- **Technician Assignment**: Display technician avatars on request cards
- **Smart Buttons**: Quick access to equipment maintenance requests with count badges
- **Priority Levels**: Categorize requests as Low, Medium, or High priority

## Tech Stack

### Backend

- **Runtime**: Node.js
- **Framework**: Express.js
- **Database**: PostgreSQL
- **ORM**: Native SQL with node-postgres

### Frontend

- **HTML5**: Semantic markup
- **CSS3**: Modern styling with Flexbox and Grid
- **JavaScript (ES6+)**: Vanilla JavaScript (no frameworks, lightweight)

### DevOps

- **Containerization**: Docker
- **Orchestration**: Docker Compose
- **Database**: PostgreSQL 15 Alpine

## Project Structure

```text
gear-guard-maintenance/
├── backend/
│   ├── config/
│   │   └── database.js
│   ├── models/
│   │   ├── Equipment.js
│   │   ├── Team.js
│   │   └── MaintenanceRequest.js
│   ├── routes/
│   │   ├── equipment.js
│   │   ├── team.js
│   │   └── request.js
│   ├── package.json
│   ├── server.js
│   ├── .env.example
│   └── Dockerfile
├── frontend/
│   ├── styles/
│   │   ├── main.css
│   │   ├── kanban.css
│   │   └── calendar.css
│   ├── scripts/
│   │   ├── api.js
│   │   ├── ui.js
│   │   ├── kanban.js
│   │   ├── calendar.js
│   │   └── app.js
│   ├── index.html
│   ├── Dockerfile
│   └── .env.example
├── database/
│   └── schema.sql
├── docker-compose.yml
└── README.md
```

## Installation & Setup

### Option 1: Docker (Recommended)

1. **Clone/Extract the project**

   ```bash
   c
   ```

2. **Build and start containers**

   ```bash
   docker-compose up --build
   ```

3. **Access the application**

   - Frontend: <http://localhost:3000>
   - Backend API: <http://localhost:5000>
   - Database: localhost:5432

### Option 2: Local Development

1. **Backend Setup**

   ```bash
   cd backend
   npm install
   cp .env.example .env
   npm run dev
   ```

2. **Frontend Setup**

   ```bash
   cd frontend
   # Serve index.html using any HTTP server
   python -m http.server 8000
   # Or use VS Code Live Server extension
   ```

3. **Database Setup**

   ```bash
   # Create PostgreSQL database
   psql -U postgres -d gear_guard -f database/schema.sql
   ```

## Configuration

### Backend (.env)

```env
PORT=5000
DB_HOST=localhost
DB_PORT=5432
DB_USER=postgres
DB_PASSWORD=password
DB_NAME=gear_guard
NODE_ENV=development
```

### Database

- Default User: `postgres`
- Default Password: `password`
- Database: `gear_guard`

## API Endpoints

### Equipment

- `GET /api/equipment` - Get all equipment
- `POST /api/equipment` - Create equipment
- `GET /api/equipment/:id` - Get equipment by ID
- `PUT /api/equipment/:id` - Update equipment
- `DELETE /api/equipment/:id` - Delete equipment
- `GET /api/equipment/:id/maintenance` - Get equipment maintenance requests

### Teams

- `GET /api/team` - Get all teams
- `POST /api/team` - Create team
- `GET /api/team/:id` - Get team by ID
- `PUT /api/team/:id` - Update team
- `DELETE /api/team/:id` - Delete team
- `POST /api/team/:teamId/members` - Add team member
- `GET /api/team/:teamId/members` - Get team members
- `DELETE /api/team/members/:memberId` - Remove team member

### Maintenance Requests

- `GET /api/request` - Get all requests (with filters)
- `POST /api/request` - Create request
- `GET /api/request/:id` - Get request by ID
- `PUT /api/request/:id` - Update request
- `PATCH /api/request/:id/status` - Update request status
- `DELETE /api/request/:id` - Delete request
- `GET /api/request/status/overdue` - Get overdue requests
- `GET /api/request/stats/summary` - Get statistics

## Usage Guide

### Creating Equipment

1. Navigate to **Equipment** tab
2. Click **+ Add Equipment**
3. Fill in details (name, serial number, department, etc.)
4. Select a default maintenance team
5. Click **Save**

### Creating Teams

1. Navigate to **Teams** tab
2. Click **+ Add Team**
3. Enter team name and specialization
4. Click **Save**
5. Click **Members** to add team members

### Creating Maintenance Requests

1. Navigate to **Kanban** tab
2. Click **+ New Request** button
3. Fill in request details:

   - Subject and description
   - Select equipment (auto-fills category and team)
   - Choose request type (Corrective/Preventive)
   - Set priority level
   - Assign technician if needed

4. Click **Create Request**

### Managing Requests via Kanban

- **Drag & Drop**: Move cards between columns to update status
- **View Details**: Click a card to edit request details
- **Track Progress**: Visual status indicators for each stage
- **Priority Indicators**: Color-coded priority badges

### Calendar View

- View preventive maintenance requests by date
- Click on a date to schedule new maintenance
- Visual distinction between corrective and preventive requests

### Reports

- **Requests by Team**: Bar chart showing distribution across teams
- **Requests by Category**: Distribution by equipment category
- **Request Status**: Overview of requests in each lifecycle stage

## Workflow Examples

### Breakdown (Corrective) Maintenance

1. User creates request for broken equipment
2. System auto-fills team and category from equipment
3. Request appears in "New" column on Kanban
4. Technician self-assigns or is assigned
5. Status moves to "In Progress"
6. Upon completion, hours spent is logged
7. Status moves to "Repaired"

### Preventive (Routine) Maintenance

1. Manager creates "Preventive" type request
2. Sets scheduled date
3. Request appears in Calendar View
4. Team can view upcoming maintenance
5. Progress tracked through same workflow

## Features Highlight

### Smart Automation

- **Auto-Fill Equipment Data**: When selecting equipment in a request, category and default team are automatically populated
- **Open Request Badges**: Equipment cards show count of open maintenance requests
- **Overdue Indicators**: Requests past scheduled date are highlighted in red
- **Status Workflow**: Requests flow through predefined lifecycle stages

### User Experience

- **Responsive Design**: Works on desktop and mobile devices
- **Drag-and-Drop Kanban**: Intuitive request management
- **Real-time Statistics**: Dashboard updates reflect current status
- **Clean UI**: Minimal, modern design with smooth animations
- **Role-based Views**: Different functionality based on user role

## Database Schema

### equipment

- Stores all company assets with details like serial number, department, location
- Links to default maintenance team
- Tracks scrap status

### teams

- Specialized maintenance teams (Mechanics, Electricians, IT Support, etc.)
- Specialization field for categorization

### team_members

- Individual technicians within teams
- Role designation

### maintenance_requests

- Requests for both corrective and preventive maintenance
- Links to equipment and assigned team
- Tracks status through lifecycle
- Records hours spent

## Performance Optimizations

- **Database Indexes**: Fast queries on frequently searched fields
- **Lazy Loading**: Data loaded on-demand
- **Efficient API Calls**: Minimal data transfer
- **CSS Grid/Flexbox**: Optimized rendering
- **Event Delegation**: Single event listeners for multiple elements

## Future Enhancements

- [ ] User authentication and role-based access control
- [ ] Email notifications for overdue requests
- [ ] Mobile app version (React Native)
- [ ] Advanced reporting with export (PDF/Excel)
- [ ] Predictive maintenance using ML
- [ ] IoT sensor integration
- [ ] Multi-language support
- [ ] Dark mode theme
- [ ] Real-time collaboration features
- [ ] Mobile-optimized views

## Troubleshooting

### Database Connection Issues

```bash
# Check if PostgreSQL is running
docker ps | grep gear-guard-db

# View logs
docker logs gear-guard-db
```

### Backend Not Starting

```bash
# Check if port 5000 is available
lsof -i :5000

# View backend logs
docker logs gear-guard-backend
```

### Frontend Can't Connect to API

- Ensure backend is running on port 5000
- Check browser console for CORS errors
- Verify API_BASE_URL in `scripts/api.js`

## Development Guide

### Adding a New Feature

1. Create model in `backend/models/`
2. Create routes in `backend/routes/`
3. Add UI components in `frontend/`
4. Update `frontend/scripts/api.js` with new endpoints
5. Test via browser and API calls

### Database Migrations

```bash
# Connect to database
psql -U postgres -d gear_guard

# Run migration
psql -U postgres -d gear_guard -f database/migration.sql
```

## License

MIT License - Feel free to use for any purpose

## Support

For issues or questions, please check the documentation or create an issue.

---

**GearGuard v1.0.0** - Built for efficient maintenance management 🚀
