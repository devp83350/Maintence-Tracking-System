// Main App Initialization
document.addEventListener('DOMContentLoaded', async () => {
    initializeEventListeners();
    await loadInitialData();
    UI.switchView('dashboard');
});

async function loadInitialData() {
    try {
        UI.populateEquipmentSelect();
        UI.populateTeamSelect();
        await loadEquipment();
        await loadTeams();
        await loadDashboardStats();
        KanbanBoard.setupDragAndDrop();
    } catch (error) {
        console.error('Error loading initial data:', error);
        UI.showNotification('Error loading data', 'error');
    }
}

function initializeEventListeners() {
    // Navigation
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const view = link.dataset.view;
            UI.switchView(view);
            
            if (view === 'kanban') {
                KanbanBoard.loadRequests();
            } else if (view === 'calendar') {
                CalendarView.loadCalendar();
            } else if (view === 'reports') {
                loadReports();
            }
        });
    });

    // Equipment Modal
    document.getElementById('add-equipment-btn').addEventListener('click', () => {
        document.getElementById('equipment-id').value = '';
        document.getElementById('equipment-form').reset();
        document.getElementById('modal-title').textContent = 'Add Equipment';
        UI.showModal('equipment-modal');
    });

    document.getElementById('equipment-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        const id = document.getElementById('equipment-id').value;
        const data = {
            name: document.getElementById('equip-name').value,
            serial_number: document.getElementById('equip-serial').value,
            department: document.getElementById('equip-department').value,
            assigned_employee: document.getElementById('equip-employee').value,
            purchase_date: document.getElementById('equip-purchase-date').value,
            warranty_info: document.getElementById('equip-warranty').value,
            location: document.getElementById('equip-location').value,
            default_team_id: document.getElementById('equip-team').value,
        };

        try {
            if (id) {
                await APIClient.updateEquipment(id, data);
                UI.showNotification('Equipment updated successfully');
            } else {
                await APIClient.createEquipment(data);
                UI.showNotification('Equipment created successfully');
            }
            UI.hideModal('equipment-modal');
            loadEquipment();
        } catch (error) {
            console.error('Error saving equipment:', error);
            UI.showNotification('Error saving equipment', 'error');
        }
    });

    document.querySelectorAll('.close').forEach(btn => {
        btn.addEventListener('click', (e) => {
            UI.hideModal(e.target.closest('.modal').id);
        });
    });

    document.getElementById('cancel-btn').addEventListener('click', () => {
        UI.hideModal('equipment-modal');
    });

    // Team Modal
    document.getElementById('add-team-btn').addEventListener('click', () => {
        document.getElementById('team-id').value = '';
        document.getElementById('team-form').reset();
        UI.showModal('team-modal');
    });

    document.getElementById('team-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        const id = document.getElementById('team-id').value;
        const data = {
            name: document.getElementById('team-name').value,
            specialization: document.getElementById('team-specialization').value,
        };

        try {
            if (id) {
                await APIClient.updateTeam(id, data);
                UI.showNotification('Team updated successfully');
            } else {
                await APIClient.createTeam(data);
                UI.showNotification('Team created successfully');
            }
            UI.hideModal('team-modal');
            loadTeams();
            UI.populateTeamSelect();
        } catch (error) {
            console.error('Error saving team:', error);
            UI.showNotification('Error saving team', 'error');
        }
    });

    document.getElementById('cancel-team-btn').addEventListener('click', () => {
        UI.hideModal('team-modal');
    });

    // Request Modal
    document.getElementById('new-request-btn').addEventListener('click', () => {
        document.getElementById('request-id').value = '';
        document.getElementById('request-form').reset();
        document.getElementById('request-modal-title').textContent = 'New Maintenance Request';
        UI.showModal('request-modal');
    });

    document.getElementById('request-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        const id = document.getElementById('request-id').value;
        const data = {
            subject: document.getElementById('req-subject').value,
            description: document.getElementById('req-description').value,
            equipment_id: document.getElementById('req-equipment').value,
            request_type: document.getElementById('req-type').value,
            scheduled_date: document.getElementById('req-scheduled-date').value,
            duration: document.getElementById('req-duration').value,
            priority: document.getElementById('req-priority').value,
        };

        try {
            if (id) {
                await APIClient.updateRequest(id, data);
                UI.showNotification('Request updated successfully');
            } else {
                await APIClient.createRequest(data);
                UI.showNotification('Request created successfully');
            }
            UI.hideModal('request-modal');
            KanbanBoard.loadRequests();
            loadDashboardStats();
        } catch (error) {
            console.error('Error saving request:', error);
            UI.showNotification('Error saving request', 'error');
        }
    });

    document.getElementById('cancel-request-btn').addEventListener('click', () => {
        UI.hideModal('request-modal');
    });

    // Close modals on outside click
    window.addEventListener('click', (e) => {
        if (e.target.classList.contains('modal')) {
            e.target.classList.add('hidden');
            e.target.classList.remove('show');
        }
    });
}

async function loadReports() {
    const requests = await APIClient.getRequests();
    const teams = await APIClient.getTeams();
    
    // Prepare data for reports
    const requestsByTeam = {};
    const requestsByCategory = {};
    
    requests.forEach(req => {
        const team = req.team_name || 'Unassigned';
        const category = req.category || 'General';
        
        requestsByTeam[team] = (requestsByTeam[team] || 0) + 1;
        requestsByCategory[category] = (requestsByCategory[category] || 0) + 1;
    });

    // Render simple text charts
    document.getElementById('team-chart').innerHTML = `
        <div style="padding: 20px;">
            ${Object.entries(requestsByTeam).map(([team, count]) => `
                <div style="margin-bottom: 10px;">
                    <strong>${team}</strong>: ${count} requests
                    <div style="background: #e2e8f0; height: 20px; margin-top: 5px; border-radius: 3px;">
                        <div style="background: #2563eb; height: 100%; width: ${(count / requests.length) * 100}%; border-radius: 3px;"></div>
                    </div>
                </div>
            `).join('')}
        </div>
    `;

    document.getElementById('category-chart').innerHTML = `
        <div style="padding: 20px;">
            ${Object.entries(requestsByCategory).map(([cat, count]) => `
                <div style="margin-bottom: 10px;">
                    <strong>${cat}</strong>: ${count} requests
                    <div style="background: #e2e8f0; height: 20px; margin-top: 5px; border-radius: 3px;">
                        <div style="background: #10b981; height: 100%; width: ${(count / requests.length) * 100}%; border-radius: 3px;"></div>
                    </div>
                </div>
            `).join('')}
        </div>
    `;

    const stats = await APIClient.getRequestStats();
    document.getElementById('status-chart').innerHTML = `
        <div style="padding: 20px;">
            <div style="margin-bottom: 10px;">
                <strong>New</strong>: ${stats.new_count} requests
                <div style="background: #e2e8f0; height: 20px; margin-top: 5px; border-radius: 3px;">
                    <div style="background: #2563eb; height: 100%; width: ${(stats.new_count / stats.total_requests) * 100}%; border-radius: 3px;"></div>
                </div>
            </div>
            <div style="margin-bottom: 10px;">
                <strong>In Progress</strong>: ${stats.in_progress_count} requests
                <div style="background: #e2e8f0; height: 20px; margin-top: 5px; border-radius: 3px;">
                    <div style="background: #f59e0b; height: 100%; width: ${(stats.in_progress_count / stats.total_requests) * 100}%; border-radius: 3px;"></div>
                </div>
            </div>
            <div style="margin-bottom: 10px;">
                <strong>Repaired</strong>: ${stats.repaired_count} requests
                <div style="background: #e2e8f0; height: 20px; margin-top: 5px; border-radius: 3px;">
                    <div style="background: #10b981; height: 100%; width: ${(stats.repaired_count / stats.total_requests) * 100}%; border-radius: 3px;"></div>
                </div>
            </div>
            <div style="margin-bottom: 10px;">
                <strong>Scrap</strong>: ${stats.scrap_count} requests
                <div style="background: #e2e8f0; height: 20px; margin-top: 5px; border-radius: 3px;">
                    <div style="background: #ef4444; height: 100%; width: ${(stats.scrap_count / stats.total_requests) * 100}%; border-radius: 3px;"></div>
                </div>
            </div>
        </div>
    `;
}
