// Kanban Board
class KanbanBoard {
    static async loadRequests(filterRequests = null) {
        const requests = filterRequests || await APIClient.getRequests();
        
        // Clear all columns
        ['New', 'In Progress', 'Repaired', 'Scrap'].forEach(status => {
            const columnId = status.toLowerCase().replace(' ', '-') + '-column';
            document.getElementById(columnId).innerHTML = '';
        });

        // Render cards
        requests.forEach(request => {
            const statusMap = {
                'New': 'new',
                'In Progress': 'in-progress',
                'Repaired': 'repaired',
                'Scrap': 'scrap'
            };
            
            const columnId = statusMap[request.status] + '-column';
            const column = document.getElementById(columnId);
            
            if (column) {
                const card = this.createCard(request);
                column.appendChild(card);
            }
        });

        // Update counts
        this.updateColumnCounts();
    }

    static createCard(request) {
        const card = document.createElement('div');
        card.className = `kanban-card ${request.scheduled_date && new Date(request.scheduled_date) < new Date() && request.status !== 'Repaired' ? 'overdue' : ''}`;
        card.draggable = true;
        card.dataset.id = request.id;
        card.innerHTML = `
            <h4>${request.subject}</h4>
            <div class="kanban-card-meta">
                <strong>${request.equipment_name}</strong> | ${request.request_type}
            </div>
            <div class="kanban-card-equipment">${request.category}</div>
            <div class="kanban-card-meta">
                Team: ${request.team_name || 'Unassigned'}
            </div>
            ${request.scheduled_date ? `<div class="kanban-card-meta">📅 ${new Date(request.scheduled_date).toLocaleDateString()}</div>` : ''}
            <div class="kanban-card-footer">
                <div class="kanban-avatar" title="${request.technician_name || 'Unassigned'}">
                    ${UI.getAvatarInitials(request.technician_name)}
                </div>
                <span class="kanban-priority ${request.priority?.toLowerCase() || 'medium'}">${request.priority || 'Medium'}</span>
            </div>
        `;

        card.addEventListener('dragstart', this.handleDragStart);
        card.addEventListener('click', () => this.openCardDetails(request.id));

        return card;
    }

    static handleDragStart(e) {
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/html', e.target);
        e.target.classList.add('dragging');
    }

    static handleDragOver(e) {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
    }

    static handleDrop(e, status) {
        e.preventDefault();
        const card = document.querySelector('.dragging');
        if (card) {
            const requestId = card.dataset.id;
            APIClient.updateRequestStatus(requestId, status).then(() => {
                this.loadRequests();
                UI.showNotification(`Request moved to ${status}`);
            });
        }
    }

    static async handleDragEnd(e) {
        e.target.classList.remove('dragging');
    }

    static updateColumnCounts() {
        document.querySelectorAll('.kanban-column').forEach(column => {
            const status = column.dataset.status;
            const count = column.querySelectorAll('.kanban-card').length;
            column.querySelector('.count').textContent = count;
        });
    }

    static async openCardDetails(requestId) {
        const request = await APIClient.getRequestById(requestId);
        document.getElementById('request-id').value = request.id;
        document.getElementById('req-subject').value = request.subject;
        document.getElementById('req-description').value = request.description || '';
        document.getElementById('req-equipment').value = request.equipment_id;
        document.getElementById('req-type').value = request.request_type;
        document.getElementById('req-scheduled-date').value = request.scheduled_date || '';
        document.getElementById('req-duration').value = request.duration || '';
        document.getElementById('req-category').value = request.category || '';
        document.getElementById('req-team').value = request.team_name || '';
        document.getElementById('req-priority').value = request.priority || 'Medium';
        document.getElementById('request-modal-title').textContent = 'Edit Maintenance Request';
        UI.showModal('request-modal');
    }

    static setupDragAndDrop() {
        document.querySelectorAll('.cards-container').forEach(container => {
            container.addEventListener('dragover', this.handleDragOver);
            container.addEventListener('drop', (e) => {
                const status = e.currentTarget.closest('.kanban-column').dataset.status;
                this.handleDrop(e, status);
            });
        });

        document.addEventListener('dragend', (e) => this.handleDragEnd(e));
    }
}
