// API Configuration
const API_BASE_URL = 'http://localhost:5000/api';

class APIClient {
    // Equipment APIs
    static async getEquipment() {
        return fetch(`${API_BASE_URL}/equipment`).then(r => r.json());
    }

    static async getEquipmentById(id) {
        return fetch(`${API_BASE_URL}/equipment/${id}`).then(r => r.json());
    }

    static async createEquipment(data) {
        return fetch(`${API_BASE_URL}/equipment`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data),
        }).then(r => r.json());
    }

    static async updateEquipment(id, data) {
        return fetch(`${API_BASE_URL}/equipment/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data),
        }).then(r => r.json());
    }

    static async deleteEquipment(id) {
        return fetch(`${API_BASE_URL}/equipment/${id}`, {
            method: 'DELETE',
        }).then(r => r.json());
    }

    // Team APIs
    static async getTeams() {
        return fetch(`${API_BASE_URL}/team`).then(r => r.json());
    }

    static async getTeamById(id) {
        return fetch(`${API_BASE_URL}/team/${id}`).then(r => r.json());
    }

    static async createTeam(data) {
        return fetch(`${API_BASE_URL}/team`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data),
        }).then(r => r.json());
    }

    static async updateTeam(id, data) {
        return fetch(`${API_BASE_URL}/team/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data),
        }).then(r => r.json());
    }

    static async deleteTeam(id) {
        return fetch(`${API_BASE_URL}/team/${id}`, {
            method: 'DELETE',
        }).then(r => r.json());
    }

    static async addTeamMember(teamId, data) {
        return fetch(`${API_BASE_URL}/team/${teamId}/members`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data),
        }).then(r => r.json());
    }

    static async getTeamMembers(teamId) {
        return fetch(`${API_BASE_URL}/team/${teamId}/members`).then(r => r.json());
    }

    // Maintenance Request APIs
    static async getRequests(filters = {}) {
        const params = new URLSearchParams();
        if (filters.status) params.append('status', filters.status);
        if (filters.team_id) params.append('team_id', filters.team_id);
        if (filters.equipment_id) params.append('equipment_id', filters.equipment_id);
        if (filters.request_type) params.append('request_type', filters.request_type);

        return fetch(`${API_BASE_URL}/request?${params}`).then(r => r.json());
    }

    static async getRequestById(id) {
        return fetch(`${API_BASE_URL}/request/${id}`).then(r => r.json());
    }

    static async createRequest(data) {
        return fetch(`${API_BASE_URL}/request`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data),
        }).then(r => r.json());
    }

    static async updateRequest(id, data) {
        return fetch(`${API_BASE_URL}/request/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data),
        }).then(r => r.json());
    }

    static async updateRequestStatus(id, status) {
        return fetch(`${API_BASE_URL}/request/${id}/status`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status }),
        }).then(r => r.json());
    }

    static async deleteRequest(id) {
        return fetch(`${API_BASE_URL}/request/${id}`, {
            method: 'DELETE',
        }).then(r => r.json());
    }

    static async getRequestStats() {
        return fetch(`${API_BASE_URL}/request/stats/summary`).then(r => r.json());
    }

    static async getOverdueRequests() {
        return fetch(`${API_BASE_URL}/request/status/overdue`).then(r => r.json());
    }
}
