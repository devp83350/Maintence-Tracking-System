// Calendar
class CalendarView {
    static currentDate = new Date();

    static async loadCalendar() {
        const requests = await APIClient.getRequests({ request_type: 'Preventive' });
        this.render(requests);
    }

    static render(requests) {
        const container = document.getElementById('calendar');
        const year = this.currentDate.getFullYear();
        const month = this.currentDate.getMonth();

        const firstDay = new Date(year, month, 1);
        const lastDay = new Date(year, month + 1, 0);
        const prevLastDay = new Date(year, month, 0).getDate();
        const nextDays = 7 - lastDay.getDay() - 1;

        let html = `
            <div class="calendar">
                <div class="calendar-header">
                    <button onclick="CalendarView.previousMonth()">← Previous</button>
                    <h3 class="current-month">${this.currentDate.toLocaleString('default', { month: 'long', year: 'numeric' })}</h3>
                    <button onclick="CalendarView.nextMonth()">Next →</button>
                </div>
                <div class="calendar-weekdays">
                    ${['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => `<div class="weekday">${day}</div>`).join('')}
                </div>
                <div class="calendar-days">
        `;

        // Previous month days
        for (let i = prevLastDay - firstDay.getDay() + 1; i <= prevLastDay; i++) {
            html += `<div class="calendar-day other-month">${i}</div>`;
        }

        // Current month days
        for (let day = 1; day <= lastDay.getDate(); day++) {
            const date = new Date(year, month, day);
            const dateString = date.toISOString().split('T')[0];
            const dayRequests = requests.filter(r => r.scheduled_date?.startsWith(dateString));
            const isToday = date.toDateString() === new Date().toDateString();

            html += `
                <div class="calendar-day ${isToday ? 'today' : ''}" onclick="CalendarView.selectDate('${dateString}')">
                    <div class="calendar-day-number">${day}</div>
                    <div class="calendar-day-events">
                        ${dayRequests.slice(0, 2).map(req => `
                            <div class="calendar-event ${req.request_type.toLowerCase()}" title="${req.subject}">${req.subject.substring(0, 10)}</div>
                        `).join('')}
                        ${dayRequests.length > 2 ? `<div style="font-size: 10px; padding: 2px;">+${dayRequests.length - 2} more</div>` : ''}
                    </div>
                </div>
            `;
        }

        // Next month days
        for (let i = 1; i <= nextDays; i++) {
            html += `<div class="calendar-day other-month">${i}</div>`;
        }

        html += `
                </div>
            </div>
        `;

        container.innerHTML = html;
    }

    static previousMonth() {
        this.currentDate.setMonth(this.currentDate.getMonth() - 1);
        this.loadCalendar();
    }

    static nextMonth() {
        this.currentDate.setMonth(this.currentDate.getMonth() + 1);
        this.loadCalendar();
    }

    static selectDate(dateString) {
        document.getElementById('req-scheduled-date').value = dateString;
        UI.switchView('kanban');
        UI.showModal('request-modal');
    }
}
