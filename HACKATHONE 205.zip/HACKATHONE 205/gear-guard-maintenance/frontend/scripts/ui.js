// UI Helper Functions
class UI {
    static showModal(modalId) {
        const modal = document.getElementById(modalId);
        modal.classList.remove('hidden');
        modal.classList.add('show');
    }

    static hideModal(modalId) {
        const modal = document.getElementById(modalId);
        modal.classList.add('hidden');
        modal.classList.remove('show');
    }

    static switchView(viewName) {
        document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
        document.getElementById(`${viewName}-view`).classList.add('active');

        document.querySelectorAll('.nav-link').forEach(link => link.classList.remove('active'));
        document.querySelector(`[data-view="${viewName}"]`).classList.add('active');
    }

    static renderEquipmentList(equipment) {
        const container = document.getElementById('equipment-list');
        container.innerHTML = equipment.map(item => `
            <div class="list-item">
                <h3>${item.name}</h3>
                <p><strong>Serial:</strong> ${item.serial_number}</p>
                <p><strong>Department:</strong> ${item.department || 'N/A'}</p>
                <p><strong>Location:</strong> ${item.location || 'N/A'}</p>
                <p><strong>Team:</strong> <span class="badge">${item.team_name || 'Unassigned'}</span></p>
                ${item.open_maintenance_count > 0 ? `<p><strong>Open Requests:</strong> <span class="badge danger">${item.open_maintenance_count}</span></p>` : ''}
                <div class="list-item-actions">
                    <button class="btn btn-primary btn-small" onclick="editEquipment('${item.id}')">Edit</button>
                    <button class="btn btn-danger btn-small" onclick="deleteEquipment('${item.id}')">Delete</button>
                    <button class="btn btn-small" onclick="showEquipmentMaintenance('${item.id}')">Maintenance (${item.open_maintenance_count || 0})</button>
                </div>
            </div>
        `).join('');
    }

    static renderTeamsList(teams) {
        const container = document.getElementById('teams-list');
        container.innerHTML = teams.map(team => `
            <div class="list-item">
                <h3>${team.name}</h3>
                <p><strong>Specialization:</strong> ${team.specialization || 'General'}</p>
                <p><strong>Members:</strong> <span class="badge">${team.member_count || 0}</span></p>
                <div class="list-item-actions">
                    <button class="btn btn-primary btn-small" onclick="editTeam('${team.id}')">Edit</button>
                    <button class="btn btn-danger btn-small" onclick="deleteTeam('${team.id}')">Delete</button>
                    <button class="btn btn-small" onclick="viewTeamMembers('${team.id}')">Members</button>
                </div>
            </div>
        `).join('');
    }

    static populateEquipmentSelect() {
        APIClient.getEquipment().then(equipment => {
            const selects = [
                document.getElementById('equip-team'),
                document.getElementById('req-equipment'),
            ];

            selects.forEach(select => {
                if (select && select.id === 'req-equipment') {
                    select.innerHTML = '<option value="">Select Equipment</option>' +
                        equipment.map(item => `<option value="${item.id}" data-team="${item.default_team_id}" data-category="${item.department}">${item.name}</option>`).join('');
                }
            });
        });
    }

    static populateTeamSelect() {
        APIClient.getTeams().then(teams => {
            const select = document.getElementById('equip-team');
            if (select) {
                select.innerHTML = '<option value="">Select Team</option>' +
                    teams.map(team => `<option value="${team.id}">${team.name}</option>`).join('');
            }
        });
    }

    static showNotification(message, type = 'success') {
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.innerHTML = message;
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 20px;
            border-radius: 6px;
            color: white;
            background-color: ${type === 'success' ? '#10b981' : '#ef4444'};
            z-index: 2000;
            animation: slideIn 0.3s ease-in;
        `;
        document.body.appendChild(notification);
        setTimeout(() => notification.remove(), 3000);
    }

    static getAvatarInitials(name) {
        if (!name) return '?';
        return name.split(' ').map(n => n[0]).join('').toUpperCase();
    }
}

// Global state
let currentEquipmentId = null;
let currentTeamId = null;
let currentRequestId = null;
let allEquipment = [];
let allTeams = [];

// Equipment Functions
async function editEquipment(id) {
    const equipment = await APIClient.getEquipmentById(id);
    document.getElementById('equipment-id').value = equipment.id;
    document.getElementById('equip-name').value = equipment.name;
    document.getElementById('equip-serial').value = equipment.serial_number;
    document.getElementById('equip-department').value = equipment.department || '';
    document.getElementById('equip-employee').value = equipment.assigned_employee || '';
    document.getElementById('equip-purchase-date').value = equipment.purchase_date || '';
    document.getElementById('equip-warranty').value = equipment.warranty_info || '';
    document.getElementById('equip-location').value = equipment.location || '';
    document.getElementById('equip-team').value = equipment.default_team_id || '';
    document.getElementById('modal-title').textContent = 'Edit Equipment';
    UI.showModal('equipment-modal');
}

async function deleteEquipment(id) {
    if (confirm('Are you sure you want to delete this equipment?')) {
        await APIClient.deleteEquipment(id);
        UI.showNotification('Equipment deleted successfully');
        loadEquipment();
    }
}

async function loadEquipment() {
    allEquipment = await APIClient.getEquipment();
    UI.renderEquipmentList(allEquipment);
}

async function showEquipmentMaintenance(equipmentId) {
    UI.switchView('kanban');
    const requests = await APIClient.getRequests({ equipment_id: equipmentId });
    // Load kanban with filtered requests
    KanbanBoard.loadRequests(requests);
}

// Team Functions
async function editTeam(id) {
    const team = await APIClient.getTeamById(id);
    document.getElementById('team-id').value = team.id;
    document.getElementById('team-name').value = team.name;
    document.getElementById('team-specialization').value = team.specialization || '';
    UI.showModal('team-modal');
}

async function deleteTeam(id) {
    if (confirm('Are you sure you want to delete this team?')) {
        await APIClient.deleteTeam(id);
        UI.showNotification('Team deleted successfully');
        loadTeams();
    }
}

async function loadTeams() {
    allTeams = await APIClient.getTeams();
    UI.renderTeamsList(allTeams);
}

async function viewTeamMembers(teamId) {
    const team = await APIClient.getTeamById(teamId);
    alert(`Team Members:\n${team.members.map(m => m.name + ' (' + m.role + ')').join('\n')}`);
}

// Auto-fill equipment data
async function autoFillEquipmentData() {
    const select = document.getElementById('req-equipment');
    const selectedOption = select.options[select.selectedIndex];
    const equipment = await APIClient.getEquipmentById(selectedOption.value);

    document.getElementById('req-category').value = equipment.department || '';
    document.getElementById('req-team').value = equipment.team_name || 'Unassigned';
}

// Load Dashboard Stats
async function loadDashboardStats() {
    const stats = await APIClient.getRequestStats();
    document.getElementById('total-requests').textContent = stats.total_requests || 0;
    document.getElementById('new-requests').textContent = stats.new_count || 0;
    document.getElementById('in-progress-requests').textContent = stats.in_progress_count || 0;
    document.getElementById('repaired-requests').textContent = stats.repaired_count || 0;

    const recentRequests = await APIClient.getRequests();
    const container = document.getElementById('recent-list');
    container.innerHTML = recentRequests.slice(0, 5).map(req => `
        <div class="request-item ${req.scheduled_date && new Date(req.scheduled_date) < new Date() && req.status !== 'Repaired' ? 'overdue' : ''}">
            <div class="request-info">
                <h4>${req.subject}</h4>
                <p>${req.equipment_name} | ${req.request_type}</p>
                <p>${new Date(req.created_at).toLocaleDateString()}</p>
            </div>
            <div class="request-status">${req.status}</div>
        </div>
    `).join('');
}
