"""
URL configuration for gearguard project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.auth.views import LoginView, LogoutView
from .frontend_views import (
    dashboard, kanban_board, calendar_view,
    equipment_list, equipment_detail,
    maintenance_request_list, maintenance_request_detail,
    teams_list, team_detail
)

urlpatterns = [
    # Admin
    path('admin/', admin.site.urls),
    
    # API
    path('api/', include('core.urls')),
    path('api-auth/', include('rest_framework.urls')),
    
    # Authentication
    path('login/', LoginView.as_view(template_name='login.html'), name='login'),
    path('logout/', LogoutView.as_view(next_page='login'), name='logout'),
    
    # Frontend Views
    path('', dashboard, name='dashboard'),
    path('kanban/', kanban_board, name='kanban'),
    path('calendar/', calendar_view, name='calendar'),
    
    path('equipment/', equipment_list, name='equipment_list'),
    path('equipment/<int:pk>/', equipment_detail, name='equipment_detail'),
    
    path('requests/', maintenance_request_list, name='maintenance_request_list'),
    path('requests/<int:pk>/', maintenance_request_detail, name='maintenance_request_detail'),
    
    path('teams/', teams_list, name='teams_list'),
    path('teams/<int:pk>/', team_detail, name='team_detail'),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
