from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_http_methods
from django.http import JsonResponse
from maintenance.models import MaintenanceRequest
from equipment.models import Equipment
from teams.models import MaintenanceTeam, TeamMember
from django.db.models import Count, Q
from django.utils import timezone


@login_required
def dashboard(request):
    """Main dashboard view"""
    # Get statistics
    total_requests = MaintenanceRequest.objects.count()
    open_requests = MaintenanceRequest.objects.filter(
        status__in=['new', 'in_progress']
    ).count()
    overdue_requests = MaintenanceRequest.objects.filter(
        scheduled_date__lt=timezone.now().date(),
        status__in=['new', 'in_progress']
    ).count()
    
    my_assignments = MaintenanceRequest.objects.filter(
        assigned_to=request.user
    ).count()
    
    # Recent requests
    recent_requests = MaintenanceRequest.objects.select_related(
        'equipment', 'maintenance_team', 'assigned_to'
    ).order_by('-created_at')[:10]
    
    # Equipment health
    scrapped_count = Equipment.objects.filter(is_scrapped=True).count()
    active_equipment = Equipment.objects.filter(is_scrapped=False).count()
    
    # Requests by status
    requests_by_status = MaintenanceRequest.objects.values('status').annotate(
        count=Count('id')
    )
    
    # Requests by team
    requests_by_team = MaintenanceRequest.objects.values('maintenance_team__name').annotate(
        count=Count('id')
    )
    
    context = {
        'total_requests': total_requests,
        'open_requests': open_requests,
        'overdue_requests': overdue_requests,
        'my_assignments': my_assignments,
        'scrapped_count': scrapped_count,
        'active_equipment': active_equipment,
        'recent_requests': recent_requests,
        'requests_by_status': requests_by_status,
        'requests_by_team': requests_by_team,
    }
    
    return render(request, 'dashboard.html', context)


@login_required
def kanban_board(request):
    """Kanban board view for maintenance requests"""
    team_id = request.GET.get('team_id')
    
    queryset = MaintenanceRequest.objects.select_related(
        'equipment', 'maintenance_team', 'assigned_to'
    )
    
    if team_id:
        queryset = queryset.filter(maintenance_team_id=team_id)
    
    # Group by status
    kanban_data = {}
    for status_key, status_label in MaintenanceRequest.STATUS_CHOICES:
        kanban_data[status_key] = {
            'label': status_label,
            'requests': queryset.filter(status=status_key).order_by('-priority', '-created_at')
        }
    
    teams = MaintenanceTeam.objects.all()
    
    context = {
        'kanban_data': kanban_data,
        'teams': teams,
        'selected_team_id': team_id,
    }
    
    return render(request, 'maintenance/kanban.html', context)


@login_required
def calendar_view(request):
    """Calendar view for preventive maintenance"""
    events = MaintenanceRequest.objects.filter(
        request_type='preventive'
    ).values('id', 'subject', 'scheduled_date', 'status', 'priority')
    
    context = {
        'events': events,
    }
    
    return render(request, 'maintenance/calendar.html', context)


@login_required
def equipment_list(request):
    """List all equipment"""
    equipment = Equipment.objects.select_related('maintenance_team').all()
    
    # Filters
    department = request.GET.get('department')
    is_scrapped = request.GET.get('is_scrapped')
    
    if department:
        equipment = equipment.filter(department=department)
    
    if is_scrapped is not None:
        equipment = equipment.filter(is_scrapped=is_scrapped == 'true')
    
    context = {
        'equipment': equipment,
        'departments': Equipment.objects.values_list('department', flat=True).distinct(),
    }
    
    return render(request, 'maintenance/equipment_list.html', context)


@login_required
def equipment_detail(request, pk):
    """Equipment detail view"""
    equipment = Equipment.objects.select_related('maintenance_team', 'assigned_to').get(pk=pk)
    maintenance_requests = MaintenanceRequest.objects.filter(equipment=equipment)
    open_requests = maintenance_requests.filter(status__in=['new', 'in_progress'])
    
    context = {
        'equipment': equipment,
        'maintenance_requests': maintenance_requests,
        'open_requests': open_requests,
    }
    
    return render(request, 'maintenance/equipment_detail.html', context)


@login_required
def maintenance_request_list(request):
    """List maintenance requests"""
    requests = MaintenanceRequest.objects.select_related(
        'equipment', 'maintenance_team', 'assigned_to'
    ).all()
    
    # Filters
    status = request.GET.get('status')
    priority = request.GET.get('priority')
    team_id = request.GET.get('team_id')
    assigned_to_me = request.GET.get('assigned_to_me')
    
    if status:
        requests = requests.filter(status=status)
    
    if priority:
        requests = requests.filter(priority=priority)
    
    if team_id:
        requests = requests.filter(maintenance_team_id=team_id)
    
    if assigned_to_me:
        requests = requests.filter(assigned_to=request.user)
    
    context = {
        'requests': requests,
        'teams': MaintenanceTeam.objects.all(),
    }
    
    return render(request, 'maintenance/request_list.html', context)


@login_required
def maintenance_request_detail(request, pk):
    """Maintenance request detail view"""
    maint_request = MaintenanceRequest.objects.select_related(
        'equipment', 'maintenance_team', 'assigned_to', 'created_by'
    ).prefetch_related('activities', 'attachments').get(pk=pk)
    
    context = {
        'request': maint_request,
    }
    
    return render(request, 'maintenance/request_detail.html', context)


@login_required
def teams_list(request):
    """List all teams"""
    teams = MaintenanceTeam.objects.prefetch_related('members__user').annotate(
        total_requests=Count('maintenance_requests'),
        open_requests=Count(
            'maintenance_requests',
            filter=Q(maintenance_requests__status__in=['new', 'in_progress'])
        )
    )
    
    context = {
        'teams': teams,
    }
    
    return render(request, 'maintenance/teams_list.html', context)


@login_required
def team_detail(request, pk):
    """Team detail view"""
    team = MaintenanceTeam.objects.prefetch_related('members__user').get(pk=pk)
    members = team.members.select_related('user')
    requests = MaintenanceRequest.objects.filter(maintenance_team=team)
    
    context = {
        'team': team,
        'members': members,
        'requests': requests,
    }
    
    return render(request, 'maintenance/team_detail.html', context)
