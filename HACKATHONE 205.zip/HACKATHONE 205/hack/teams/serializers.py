from rest_framework import serializers
from .models import MaintenanceTeam, TeamMember


class TeamMemberSerializer(serializers.ModelSerializer):
    user_name = serializers.CharField(source='user.get_full_name', read_only=True)
    user_email = serializers.CharField(source='user.email', read_only=True)
    assigned_requests_count = serializers.IntegerField(read_only=True)
    
    class Meta:
        model = TeamMember
        fields = [
            'id', 'user', 'user_name', 'user_email', 'role', 'is_active',
            'joined_date', 'assigned_requests_count'
        ]
        read_only_fields = ['joined_date']


class MaintenanceTeamSerializer(serializers.ModelSerializer):
    members = TeamMemberSerializer(many=True, read_only=True)
    member_count = serializers.IntegerField(read_only=True)
    active_requests_count = serializers.IntegerField(read_only=True)
    
    class Meta:
        model = MaintenanceTeam
        fields = [
            'id', 'name', 'description', 'member_count', 'active_requests_count',
            'members', 'created_at', 'updated_at'
        ]
        read_only_fields = ['created_at', 'updated_at']


class MaintenanceTeamListSerializer(serializers.ModelSerializer):
    """Lightweight serializer for list views"""
    member_count = serializers.IntegerField(read_only=True)
    active_requests_count = serializers.IntegerField(read_only=True)
    
    class Meta:
        model = MaintenanceTeam
        fields = ['id', 'name', 'member_count', 'active_requests_count', 'created_at']
