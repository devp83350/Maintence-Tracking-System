from django.contrib import admin
from .models import MaintenanceTeam, TeamMember


class TeamMemberInline(admin.TabularInline):
    model = TeamMember
    extra = 1
    fields = ['user', 'role', 'is_active', 'joined_date']
    readonly_fields = ['joined_date']


@admin.register(MaintenanceTeam)
class MaintenanceTeamAdmin(admin.ModelAdmin):
    list_display = ['name', 'member_count', 'active_requests_count', 'created_at']
    list_filter = ['created_at']
    search_fields = ['name', 'description']
    readonly_fields = ['created_at', 'updated_at']
    inlines = [TeamMemberInline]


@admin.register(TeamMember)
class TeamMemberAdmin(admin.ModelAdmin):
    list_display = ['user', 'team', 'role', 'is_active', 'joined_date']
    list_filter = ['team', 'role', 'is_active']
    search_fields = ['user__first_name', 'user__last_name', 'user__email']
    readonly_fields = ['joined_date']
