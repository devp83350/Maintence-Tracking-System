from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from .models import MaintenanceTeam, TeamMember
from .serializers import MaintenanceTeamSerializer, MaintenanceTeamListSerializer, TeamMemberSerializer


class MaintenanceTeamViewSet(viewsets.ModelViewSet):
    """ViewSet for Maintenance Team management"""
    permission_classes = [IsAuthenticated]
    search_fields = ['name', 'description']
    ordering_fields = ['name', 'created_at']
    ordering = ['name']
    
    def get_queryset(self):
        return MaintenanceTeam.objects.prefetch_related('members__user')
    
    def get_serializer_class(self):
        if self.action == 'list':
            return MaintenanceTeamListSerializer
        return MaintenanceTeamSerializer
    
    @action(detail=True, methods=['get'])
    def maintenance_requests(self, request, pk=None):
        """Get all maintenance requests for this team"""
        team = self.get_object()
        from maintenance.models import MaintenanceRequest
        from maintenance.serializers import MaintenanceRequestListSerializer
        
        requests = MaintenanceRequest.objects.filter(maintenance_team=team)
        serializer = MaintenanceRequestListSerializer(requests, many=True)
        return Response(serializer.data)
    
    @action(detail=True, methods=['get'])
    def kanban_view(self, request, pk=None):
        """Get kanban board data grouped by status"""
        team = self.get_object()
        from maintenance.models import MaintenanceRequest
        from maintenance.serializers import MaintenanceRequestListSerializer
        
        requests = MaintenanceRequest.objects.filter(
            maintenance_team=team
        ).order_by('status', '-created_at')
        
        kanban_data = {}
        for status_choice in ['new', 'in_progress', 'repaired', 'scrap']:
            kanban_data[status_choice] = MaintenanceRequestListSerializer(
                requests.filter(status=status_choice),
                many=True
            ).data
        
        return Response(kanban_data)


class TeamMemberViewSet(viewsets.ModelViewSet):
    """ViewSet for Team Member management"""
    permission_classes = [IsAuthenticated]
    serializer_class = TeamMemberSerializer
    filterset_fields = ['team', 'role', 'is_active']
    search_fields = ['user__first_name', 'user__last_name', 'user__email']
    
    def get_queryset(self):
        return TeamMember.objects.select_related('user', 'team')
