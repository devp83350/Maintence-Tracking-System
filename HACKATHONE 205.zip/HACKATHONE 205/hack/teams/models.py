from django.db import models
from django.contrib.auth.models import User


class MaintenanceTeam(models.Model):
    """Teams responsible for equipment maintenance"""
    
    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['name']
    
    def __str__(self):
        return self.name
    
    @property
    def member_count(self):
        return self.members.count()
    
    @property
    def active_requests_count(self):
        from maintenance.models import MaintenanceRequest
        return MaintenanceRequest.objects.filter(
            maintenance_team=self,
            status__in=['new', 'in_progress']
        ).count()


class TeamMember(models.Model):
    """Individual technicians in maintenance teams"""
    
    ROLE_CHOICES = [
        ('technician', 'Technician'),
        ('lead', 'Team Lead'),
        ('manager', 'Manager'),
    ]
    
    team = models.ForeignKey(MaintenanceTeam, on_delete=models.CASCADE, related_name='members')
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='team_memberships')
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='technician')
    is_active = models.BooleanField(default=True)
    joined_date = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ('team', 'user')
        ordering = ['team', 'role', 'user__first_name']
    
    def __str__(self):
        return f"{self.user.get_full_name()} - {self.team.name} ({self.get_role_display()})"
    
    @property
    def assigned_requests_count(self):
        from maintenance.models import MaintenanceRequest
        return MaintenanceRequest.objects.filter(
            assigned_to=self.user,
            status__in=['new', 'in_progress']
        ).count()
