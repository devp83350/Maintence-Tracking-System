# 🛠️ GearGuard Development & Deployment Guide

## 📋 Prerequisites

- Python 3.8+
- pip package manager
- Git (for version control)
- PostgreSQL 12+ (for production) or SQLite (for development)

## 🚀 Development Setup

### 1. Clone/Navigate to Project
```bash
cd "e:\HACKATHONE 205\hack"
```

### 2. Install Dependencies
```bash
pip install -r requirements.txt
```

### 3. Database Setup
```bash
# Create migrations (already done)
python manage.py makemigrations

# Apply migrations
python manage.py migrate

# Create superuser for admin
python manage.py createsuperuser --username admin --email admin@gearguard.com

# Populate demo data
python manage.py populate_demo_data
```

### 4. Run Development Server
```bash
python manage.py runserver
# Server runs on http://localhost:8000
```

### 5. Access the System
- **Frontend**: http://localhost:8000/
- **Admin Panel**: http://localhost:8000/admin/
- **API**: http://localhost:8000/api/
- **API Docs**: Can be added using `drf-spectacular`

## 👤 Demo User Accounts

These are automatically created by `populate_demo_data`:

| Role | Username | Password | Description |
|------|----------|----------|-------------|
| Manager | manager1 | (set via admin) | Full access, assign tasks |
| Technician | tech1 | (set via admin) | Can update own tasks |
| Technician | tech2 | (set via admin) | Electrical team lead |
| Technician | tech3 | (set via admin) | In Electrical team |
| Viewer | viewer1 | (set via admin) | Read-only access |
| Admin | admin | (set during setup) | System admin |

**To set demo passwords:**
```bash
python manage.py shell
from django.contrib.auth.models import User
u = User.objects.get(username='manager1')
u.set_password('password123')
u.save()
exit()
```

## 🏗️ Project Structure Overview

```
gearguard/
├── accounts/          # User management
├── equipment/         # Asset tracking
├── teams/            # Team management
├── maintenance/      # Core maintenance system ⭐
├── dashboard/        # Analytics
├── core/            # Shared utilities
├── templates/       # HTML templates
├── static/          # CSS, JS, images
└── manage.py
```

## 🔌 API Examples

### Create a Maintenance Request (Auto-fill Demo)
```bash
curl -X POST http://localhost:8000/api/maintenance-requests/ \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{
    "subject": "Fix conveyor belt",
    "description": "Belt slipping during operation",
    "equipment": 1,
    "request_type": "corrective",
    "priority": "high"
  }'
# Note: maintenance_team auto-fills from equipment!
```

### Get Kanban Board Data
```bash
curl http://localhost:8000/api/maintenance-requests/kanban_board/?team_id=1
```

### Get Dashboard Stats
```bash
curl http://localhost:8000/api/maintenance-requests/dashboard_stats/
```

### Update Request Status
```bash
curl -X POST http://localhost:8000/api/maintenance-requests/1/mark_in_progress/ \
  -H "Authorization: Bearer YOUR_TOKEN"
```

## 📱 Frontend Pages

### Dashboard
- **URL**: `/`
- **Features**: KPI metrics, charts, recent requests
- **Tech**: Chart.js, Tailwind CSS

### Kanban Board
- **URL**: `/kanban/`
- **Features**: Drag-and-drop status columns, team filtering
- **Tech**: SortableJS, HTMX

### Calendar
- **URL**: `/calendar/`
- **Features**: Preventive maintenance schedule
- **Tech**: FullCalendar.js

### Equipment List
- **URL**: `/equipment/`
- **Features**: Browse assets, filters, open request count
- **Tech**: Tailwind, responsive grid

### Maintenance Requests
- **URL**: `/requests/`
- **Features**: Filterable list, status transitions
- **Tech**: HTMX, Alpine.js

### Teams
- **URL**: `/teams/`
- **Features**: Team overview, member list, workload
- **Tech**: Responsive tables

## 🎯 Key Business Logic

### 1. Auto-Fill Maintenance Team
When creating a request, if equipment is selected, the maintenance_team automatically fills with equipment.maintenance_team.

**Implementation**: Django signal in `maintenance/models.py`

### 2. Workflow State Machine
Requests follow a strict state machine:
```
new ──→ in_progress ──→ repaired
 └──────────────────────┘
       ↓ (any state)
      scrap
```

**Validation**: `MaintenanceRequest.can_transition_to()` method

### 3. Auto-Scrap Equipment
When a request is marked as "scrap", the equipment.is_scrapped flag is automatically set to True.

**Implementation**: `MaintenanceRequest.mark_as_scrapped()` method

### 4. Activity Logging
Every change creates an activity record:
- Status changes
- Assignments
- Comments
- Attachments

**Model**: `MaintenanceRequestActivity`

## 🔍 Admin Interface Features

### Equipment Admin
- Inline maintenance history
- Warranty status display
- Bulk actions for scrapping
- Search by serial number

### Maintenance Request Admin
- Nested activities and attachments
- Status workflow validation
- Created by tracking
- Cost tracking fields

### Team Admin
- Inline team members
- Role assignment (Technician, Lead, Manager)
- Workload metrics

## 📊 Reporting & Analytics

### Available Reports (via API)

1. **Dashboard Stats** → `/api/maintenance-requests/dashboard_stats/`
   - Total requests by status
   - Overdue count
   - My assignments

2. **Team Workload** → `/api/maintenance-requests/team_workload/`
   - Requests per team
   - Open vs completed

3. **Technician Workload** → `/api/maintenance-requests/technician_workload/`
   - Assigned tasks per person
   - Workload balance

4. **Equipment Health** → Via Equipment API
   - Open requests count
   - Warranty status
   - Last maintenance date

## 🧪 Testing

### Run Django Tests
```bash
python manage.py test
```

### Run Management Command
```bash
python manage.py populate_demo_data
```

### Check System Health
```bash
python manage.py check
python manage.py check --deploy
```

## 🌐 Switching to PostgreSQL (Production)

### 1. Install PostgreSQL Driver
```bash
pip install psycopg2-binary
```

### 2. Update settings.py
```python
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'gearguard_db',
        'USER': 'gearguard_user',
        'PASSWORD': 'secure_password',
        'HOST': 'localhost',
        'PORT': '5432',
    }
}
```

### 3. Create Database
```bash
createdb gearguard_db
```

### 4. Apply Migrations
```bash
python manage.py migrate
```

## 🚀 Production Deployment Checklist

- [ ] Set `DEBUG = False`
- [ ] Set `ALLOWED_HOSTS` properly
- [ ] Use environment variables for secrets
- [ ] Enable HTTPS/SSL
- [ ] Set up database backups
- [ ] Configure static files serving
- [ ] Set up error logging (Sentry)
- [ ] Configure email for notifications
- [ ] Enable CORS for frontend domains
- [ ] Set up rate limiting
- [ ] Create superuser for admin
- [ ] Run `python manage.py collectstatic`

## 📚 Docker Deployment (Optional)

Create `Dockerfile`:
```dockerfile
FROM python:3.12-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
CMD ["python", "manage.py", "runserver", "0.0.0.0:8000"]
```

Build and run:
```bash
docker build -t gearguard .
docker run -p 8000:8000 gearguard
```

## 🐛 Troubleshooting

### Issue: Port 8000 already in use
```bash
# Find and kill process on port 8000
netstat -ano | findstr :8000
taskkill /PID <PID> /F
```

### Issue: Database locked (SQLite)
```bash
# Delete SQLite lock file
del db.sqlite3-wal
del db.sqlite3-shm
```

### Issue: Missing migrations
```bash
python manage.py makemigrations
python manage.py migrate --run-syncdb
```

### Issue: Static files not loading
```bash
python manage.py collectstatic --noinput
```

## 📖 Additional Resources

- [Django Official Docs](https://docs.djangoproject.com/)
- [Django REST Framework](https://www.django-rest-framework.org/)
- [HTMX Documentation](https://htmx.org/)
- [Alpine.js Guide](https://alpinejs.dev/)
- [Tailwind CSS](https://tailwindcss.com/)
- [FullCalendar](https://fullcalendar.io/)

## 🤝 Contributing

1. Create feature branch: `git checkout -b feature/your-feature`
2. Commit changes: `git commit -am 'Add feature'`
3. Push branch: `git push origin feature/your-feature`
4. Open pull request

## 📞 Support

For issues or questions:
1. Check existing GitHub issues
2. Review logs: `tail -f logs/error.log`
3. Check Django debug toolbar
4. Run tests to isolate issues

---

**Happy coding! 🚀 Good luck with the hackathon!**
