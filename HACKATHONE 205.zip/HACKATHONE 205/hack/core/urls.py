from django.urls import path, include
from rest_framework.routers import DefaultRouter
from equipment.views import EquipmentViewSet
from teams.views import MaintenanceTeamViewSet, TeamMemberViewSet
from maintenance.views import MaintenanceRequestViewSet
from accounts.views import UserViewSet, UserProfileViewSet

# Create router and register viewsets
router = DefaultRouter()
router.register(r'equipment', EquipmentViewSet, basename='equipment')
router.register(r'teams', MaintenanceTeamViewSet, basename='team')
router.register(r'team-members', TeamMemberViewSet, basename='team-member')
router.register(r'maintenance-requests', MaintenanceRequestViewSet, basename='maintenance-request')
router.register(r'users', UserViewSet, basename='user')
router.register(r'profiles', UserProfileViewSet, basename='profile')

urlpatterns = [
    path('', include(router.urls)),
]
