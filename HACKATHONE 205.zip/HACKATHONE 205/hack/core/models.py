from django.db import models


class SystemSettings(models.Model):
    """Global system settings"""
    
    setting_key = models.CharField(max_length=100, unique=True)
    setting_value = models.TextField()
    description = models.CharField(max_length=200, blank=True)
    
    class Meta:
        verbose_name_plural = "System Settings"
    
    def __str__(self):
        return self.setting_key
