from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from datetime import date, timedelta
from accounts.models import UserProfile
from teams.models import MaintenanceTeam, TeamMember
from equipment.models import Equipment
from maintenance.models import MaintenanceRequest


class Command(BaseCommand):
    help = 'Populate database with demo data for hackathon'

    def handle(self, *args, **options):
        self.stdout.write(self.style.SUCCESS('Starting data population...'))
        
        # Create Users
        self.stdout.write('Creating users...')
        
        users_data = [
            {'username': 'manager1', 'first_name': 'John', 'last_name': 'Manager', 'email': 'john@gearguard.com'},
            {'username': 'tech1', 'first_name': 'Alice', 'last_name': 'Smith', 'email': 'alice@gearguard.com'},
            {'username': 'tech2', 'first_name': 'Bob', 'last_name': 'Johnson', 'email': 'bob@gearguard.com'},
            {'username': 'tech3', 'first_name': 'Carol', 'last_name': 'Williams', 'email': 'carol@gearguard.com'},
            {'username': 'viewer1', 'first_name': 'David', 'last_name': 'Brown', 'email': 'david@gearguard.com'},
        ]
        
        users = {}
        for user_data in users_data:
            user, created = User.objects.get_or_create(
                username=user_data['username'],
                defaults={
                    'first_name': user_data['first_name'],
                    'last_name': user_data['last_name'],
                    'email': user_data['email'],
                }
            )
            users[user_data['username']] = user
            
            # Create UserProfile
            profile, _ = UserProfile.objects.get_or_create(
                user=user,
                defaults={
                    'role': 'manager' if 'manager' in user_data['username'] else (
                        'viewer' if 'viewer' in user_data['username'] else 'technician'
                    ),
                    'phone': f'+1-555-{2000 + len(users):04d}',
                    'department': 'Maintenance' if 'tech' in user_data['username'] else 'Management',
                }
            )
        
        self.stdout.write(self.style.SUCCESS(f'✓ Created {len(users)} users'))
        
        # Create Maintenance Teams
        self.stdout.write('Creating maintenance teams...')
        
        teams_data = [
            {'name': 'Mechanical Team', 'description': 'Responsible for mechanical equipment'},
            {'name': 'Electrical Team', 'description': 'Responsible for electrical systems'},
            {'name': 'Hydraulics Team', 'description': 'Responsible for hydraulic systems'},
        ]
        
        teams = {}
        for team_data in teams_data:
            team, created = MaintenanceTeam.objects.get_or_create(
                name=team_data['name'],
                defaults={'description': team_data['description']}
            )
            teams[team_data['name']] = team
        
        self.stdout.write(self.style.SUCCESS(f'✓ Created {len(teams)} teams'))
        
        # Assign technicians to teams
        self.stdout.write('Assigning technicians to teams...')
        
        team_assignments = {
            'Mechanical Team': ['tech1'],
            'Electrical Team': ['tech2', 'tech3'],
            'Hydraulics Team': ['tech1'],
        }
        
        for team_name, tech_usernames in team_assignments.items():
            team = teams[team_name]
            for username in tech_usernames:
                member, _ = TeamMember.objects.get_or_create(
                    team=team,
                    user=users[username],
                    defaults={'role': 'technician' if username != 'tech1' else 'lead'}
                )
        
        # Create Equipment
        self.stdout.write('Creating equipment...')
        
        equipment_data = [
            {
                'name': 'CNC Lathe #1',
                'serial_number': 'CNC-LAT-001',
                'department': 'Manufacturing',
                'location': 'Building A - Floor 2',
                'team': 'Mechanical Team',
                'purchase_date': date(2020, 6, 15),
                'warranty_expiry': date(2025, 6, 15),
            },
            {
                'name': 'Industrial Pump',
                'serial_number': 'PUMP-HYD-001',
                'department': 'Production',
                'location': 'Building B - Ground Floor',
                'team': 'Hydraulics Team',
                'purchase_date': date(2018, 3, 20),
                'warranty_expiry': date(2023, 3, 20),
            },
            {
                'name': 'Electrical Panel',
                'serial_number': 'ELEC-PAN-001',
                'department': 'Operations',
                'location': 'Building A - Ground Floor',
                'team': 'Electrical Team',
                'purchase_date': date(2021, 1, 10),
                'warranty_expiry': date(2026, 1, 10),
            },
            {
                'name': 'Conveyor Belt System',
                'serial_number': 'CONV-SYS-001',
                'department': 'Manufacturing',
                'location': 'Building C - Ground Floor',
                'team': 'Mechanical Team',
                'purchase_date': date(2019, 8, 5),
                'warranty_expiry': date(2024, 8, 5),
            },
            {
                'name': 'Compressor Unit',
                'serial_number': 'COMP-UNI-001',
                'department': 'Maintenance',
                'location': 'Building A - Basement',
                'team': 'Mechanical Team',
                'purchase_date': date(2017, 11, 30),
                'warranty_expiry': date(2022, 11, 30),
            },
        ]
        
        equipment_objs = {}
        for equip_data in equipment_data:
            team = teams[equip_data.pop('team')]
            equip, created = Equipment.objects.get_or_create(
                serial_number=equip_data['serial_number'],
                defaults={
                    'maintenance_team': team,
                    'assigned_to': users['tech1'] if 'Mechanical' in team.name else users['tech2'],
                    **equip_data
                }
            )
            equipment_objs[equip_data['serial_number']] = equip
        
        self.stdout.write(self.style.SUCCESS(f'✓ Created {len(equipment_objs)} equipment'))
        
        # Create Maintenance Requests
        self.stdout.write('Creating maintenance requests...')
        
        request_data = [
            {
                'subject': 'CNC Lathe Spindle Repair',
                'description': 'Spindle not reaching full RPM. Need inspection and repair.',
                'equipment': 'CNC-LAT-001',
                'team': 'Mechanical Team',
                'assigned_to': 'tech1',
                'request_type': 'corrective',
                'status': 'in_progress',
                'priority': 'high',
                'scheduled_date': date.today() + timedelta(days=1),
            },
            {
                'subject': 'Hydraulic Pump Maintenance',
                'description': 'Regular preventive maintenance for hydraulic pump system.',
                'equipment': 'PUMP-HYD-001',
                'team': 'Hydraulics Team',
                'assigned_to': 'tech2',
                'request_type': 'preventive',
                'status': 'new',
                'priority': 'medium',
                'scheduled_date': date.today() + timedelta(days=5),
            },
            {
                'subject': 'Electrical Panel Inspection',
                'description': 'Annual safety inspection of main electrical panel.',
                'equipment': 'ELEC-PAN-001',
                'team': 'Electrical Team',
                'assigned_to': 'tech3',
                'request_type': 'preventive',
                'status': 'new',
                'priority': 'critical',
                'scheduled_date': date.today() + timedelta(days=2),
            },
            {
                'subject': 'Conveyor Belt Misalignment',
                'description': 'Belt is misaligned, causing vibration and noise.',
                'equipment': 'CONV-SYS-001',
                'team': 'Mechanical Team',
                'assigned_to': 'tech1',
                'request_type': 'corrective',
                'status': 'new',
                'priority': 'high',
                'scheduled_date': date.today(),
            },
            {
                'subject': 'Compressor Oil Change',
                'description': 'Oil change and filter replacement for air compressor.',
                'equipment': 'COMP-UNI-001',
                'team': 'Mechanical Team',
                'assigned_to': None,
                'request_type': 'preventive',
                'status': 'repaired',
                'priority': 'low',
                'scheduled_date': date.today() - timedelta(days=5),
            },
        ]
        
        for req_data in request_data:
            equipment = equipment_objs[req_data.pop('equipment')]
            team = teams[req_data.pop('team')]
            assigned_user = users.get(req_data.pop('assigned_to'))
            
            maint_req, created = MaintenanceRequest.objects.get_or_create(
                subject=req_data['subject'],
                equipment=equipment,
                defaults={
                    'maintenance_team': team,
                    'assigned_to': assigned_user,
                    'created_by': users['manager1'],
                    **req_data
                }
            )
        
        self.stdout.write(self.style.SUCCESS(f'✓ Created {len(request_data)} maintenance requests'))
        
        self.stdout.write(self.style.SUCCESS('\n✓ Demo data population completed successfully!'))
        self.stdout.write(self.style.WARNING('\nDemo Users:'))
        self.stdout.write('  Manager: manager1 / Manager User')
        self.stdout.write('  Technicians: tech1, tech2, tech3')
        self.stdout.write('  Viewer: viewer1')
