# 🚀 GearGuard - Professional Maintenance Management System

## 🎯 Overview
A comprehensive Django-based maintenance management system designed for hackathons with enterprise-grade architecture and modern UX. Built with the guidance of Odoo's modular approach.

## 📋 Features Implemented

### ✅ Core Architecture
- **Modular Django Apps**: `accounts`, `equipment`, `teams`, `maintenance`, `dashboard`, `core`
- **Professional Admin Interface**: Full Django admin with inlined forms and fieldsets
- **Django REST Framework**: Complete API layer for all features
- **Database**: SQLite (hackathon) → easily switch to PostgreSQL for production

### ✅ Master Data Management

#### Equipment Module
- Equipment registration with serial numbers, departments, locations
- Warranty tracking (auto-detect under-warranty status)
- Equipment scrap lifecycle management
- Open requests count (Smart Button)
- Team assignment and maintenance history tracking

#### Teams Module
- Maintenance team creation and management
- Team member roles (Technician, Team Lead, Manager)
- Member workload tracking
- Active requests per team
- Kanban view by team

### ✅ Core Maintenance Request Management

#### Workflow State Machine
- **Status Flow**: New → In Progress → Repaired
- **Any Status → Scrap** (marks equipment as scrapped)
- **Controlled Transitions**: Validates state transitions before allowing changes
- **Auto-fill Logic**: When equipment is selected, maintenance_team auto-fills
- **Activity Logging**: All status changes tracked with user and timestamp

#### Request Types & Priority
- **Corrective**: Equipment breakdowns
- **Preventive**: Scheduled maintenance
- **Priority Levels**: Critical, High, Medium, Low

### ✅ Advanced Features

#### 1. **Kanban Board** (Visual Impact)
- Drag-and-drop columns by status
- Color-coded priority badges
- Equipment info on each card
- Technician assignment display
- Team filtering

#### 2. **Calendar View** (Preventive Maintenance)
- FullCalendar integration
- Preventive tasks by scheduled date
- Priority-based color coding
- Click to view task details

#### 3. **Dashboard** (Real-time Analytics)
- Key metrics: Total, Open, Overdue, My Assignments
- Equipment health status
- Charts:
  - Requests by Status (doughnut)
  - Requests by Team (bar)
- Recent requests table
- Quick action buttons

#### 4. **Smart Buttons**
- Equipment: "🔧 Maintenance (n)" → filters to open requests
- Teams: Shows active request count
- One-click status transitions

#### 5. **Reporting APIs**
- Dashboard statistics endpoint
- Team workload breakdown
- Technician workload breakdown
- Requests grouped by status/priority/team

### ✅ User Roles & Permissions

#### Roles Implemented
- **Manager**: Full access, can assign tasks, view reports
- **Technician**: Can view assigned tasks, update status
- **Viewer**: Read-only access to all data
- **Admin**: Full system admin access

### ✅ Frontend (HTMX + Alpine.js + Tailwind)

#### Technologies
- **Tailwind CSS**: Modern, responsive design
- **HTMX**: Lightweight interactivity without page reloads
- **Alpine.js**: Reactive components
- **SortableJS**: Drag-and-drop kanban board
- **FullCalendar**: Interactive calendar
- **Chart.js**: Data visualization

#### Pages Implemented
1. **Login Page**: Demo credentials display
2. **Dashboard**: Metrics, charts, recent requests
3. **Kanban Board**: Drag-and-drop status management
4. **Calendar**: Preventive maintenance schedule
5. **Equipment List**: Browsable equipment catalog with filters
6. **Responsive Navigation**: All views linked together

## 📁 Project Structure

```
gearguard/
├── accounts/              # User profiles & roles
│   ├── models.py         # UserProfile model
│   ├── serializers.py    # DRF serializers
│   ├── views.py          # API ViewSets
│   └── admin.py          # Admin interface
│
├── equipment/            # Equipment/Assets
│   ├── models.py         # Equipment, EquipmentHistory
│   ├── serializers.py    # Equipment serializers
│   ├── views.py          # Equipment API
│   └── admin.py          # Equipment admin
│
├── teams/                # Maintenance Teams
│   ├── models.py         # MaintenanceTeam, TeamMember
│   ├── serializers.py    # Team serializers
│   ├── views.py          # Team API & Kanban view
│   └── admin.py          # Team admin
│
├── maintenance/          # Core: Requests & Workflow
│   ├── models.py         # MaintenanceRequest, Activity, Attachment
│   │                      # ⭐ Auto-fill signals
│   │                      # ⭐ Workflow validation
│   ├── serializers.py    # Request serializers with validation
│   ├── views.py          # API + Dashboard + Kanban + Calendar + Reports
│   └── admin.py          # Rich admin interface
│
├── dashboard/            # Dashboard widgets
│   ├── models.py         # Widget customization
│   └── admin.py
│
├── core/                 # Shared utilities
│   ├── urls.py           # API router configuration
│   ├── management/commands/
│   │   └── populate_demo_data.py  # ⭐ Demo data loader
│   └── models.py         # System settings
│
├── templates/
│   ├── base/
│   │   └── base.html     # Base template with nav
│   ├── login.html        # Login page
│   ├── dashboard.html    # Dashboard with charts
│   └── maintenance/
│       ├── kanban.html   # Kanban board
│       ├── calendar.html # Calendar view
│       ├── equipment_list.html
│       └── ...
│
├── gearguard/
│   ├── settings.py       # Django config
│   ├── urls.py           # URL routing
│   └── frontend_views.py # Template views
│
└── manage.py
```

## 🚀 Quick Start

### 1. Installation
```bash
cd "e:\HACKATHONE 205\hack"
python manage.py migrate
python manage.py createsuperuser
python manage.py populate_demo_data
```

### 2. Running the Server
```bash
python manage.py runserver
```

### 3. Accessing the System
- **Frontend**: http://localhost:8000
- **Admin**: http://localhost:8000/admin
- **API**: http://localhost:8000/api/

### 4. Demo Accounts
```
Manager: manager1 (any password - set via admin)
Technician: tech1, tech2, tech3
Viewer: viewer1
Admin: admin
```

## 💡 Business Logic Highlights

### Auto-fill Magic
```python
@receiver(post_save, sender=MaintenanceRequest)
def auto_fill_maintenance_team(sender, instance, created, **kwargs):
    if created and instance.equipment and not instance.maintenance_team:
        instance.maintenance_team = instance.equipment.maintenance_team
        instance.save()
```

### Workflow State Machine
```python
def can_transition_to(self, new_status):
    allowed_transitions = {
        'new': ['in_progress', 'scrap'],
        'in_progress': ['repaired', 'scrap'],
        'repaired': ['scrap'],
        'scrap': [],
    }
```

### Activity Logging
Every status change, assignment, and comment is logged with:
- Action type
- User who performed it
- Timestamp
- Description

### Smart Buttons
```html
<!-- In Equipment Detail -->
🔧 Maintenance ({{ equipment.open_requests_count }})
→ Filters MaintenanceRequest where equipment=this & status in ['new','in_progress']
```

## 📊 API Endpoints

### Equipment
- `GET /api/equipment/` - List all
- `POST /api/equipment/` - Create
- `GET /api/equipment/{id}/open_requests/` - Smart button
- `GET /api/equipment/{id}/warranty_status/` - Warranty check
- `POST /api/equipment/{id}/mark_as_scrapped/` - Equipment lifecycle

### Maintenance Requests
- `GET /api/maintenance-requests/` - List with filters
- `POST /api/maintenance-requests/` - Create (auto-fill)
- `POST /api/maintenance-requests/{id}/mark_in_progress/` - Status change
- `POST /api/maintenance-requests/{id}/mark_repaired/` - Mark complete
- `POST /api/maintenance-requests/{id}/mark_scrapped/` - Scrap equipment
- `POST /api/maintenance-requests/{id}/assign_to/` - Assign to technician
- `GET /api/maintenance-requests/kanban_board/` - Kanban data by status
- `GET /api/maintenance-requests/calendar_view/` - Calendar events
- `GET /api/maintenance-requests/dashboard_stats/` - Analytics
- `GET /api/maintenance-requests/team_workload/` - Team reports
- `GET /api/maintenance-requests/technician_workload/` - Technician reports

### Teams
- `GET /api/teams/` - List teams
- `GET /api/teams/{id}/kanban_view/` - Team's kanban board
- `GET /api/teams/{id}/maintenance_requests/` - Team's requests

### Users & Profiles
- `GET /api/users/` - List users
- `GET /api/profiles/me/` - Current user profile

## 🎨 Frontend Features

### Responsive Design
- Mobile-first with Tailwind CSS
- Collapsible sidebar (ready to implement)
- Card-based layouts

### Interactivity
- HTMX: Status updates without page reload
- Alpine.js: Filter dropdowns, modals
- SortableJS: Kanban drag-and-drop
- FullCalendar: Interactive calendar

### Visual Feedback
- Color-coded priorities (Red/Orange/Yellow/Green)
- Status badges (Blue/Yellow/Green)
- Loading spinners (HTMX)
- Toast notifications (ready to implement)

## 🏆 Hackathon Scoring Points

✅ **Professional Architecture**: Modular Django apps (not just CRUD)
✅ **Workflow Automation**: Auto-fill, state machine, activity logging
✅ **Visual Features**: Kanban board, calendar, dashboard with charts
✅ **Smart UX**: One-click actions, equipment health indicators
✅ **Scalability**: DRF APIs, database indexing, select_related optimization
✅ **Polish**: Responsive UI, role-based access, demo data
✅ **Documentation**: Clear models, comments, this README

## 📈 Future Enhancement Roadmap

### Phase 2 (If Time Allows)
- [ ] Notifications (email/SMS for overdue tasks)
- [ ] File uploads for maintenance reports
- [ ] Export reports (PDF, Excel)
- [ ] Mobile app (React Native)
- [ ] Forecasting (predict failures)

### Phase 3 (Post-Hackathon)
- [ ] Integration with IoT sensors
- [ ] Predictive maintenance with ML
- [ ] Supply chain integration
- [ ] Multi-tenant SaaS version

## 🔐 Security Notes

For production deployment:
1. Set `DEBUG = False` in settings.py
2. Use environment variables for `SECRET_KEY`
3. Enable `ALLOWED_HOSTS`
4. Implement HTTPS
5. Use PostgreSQL instead of SQLite
6. Set up proper CORS for mobile apps
7. Enable CSRF protection on all forms

## 📝 License

Open source for hackathon purposes.

---

## 🎓 Learning Resources Used

- Django Official Documentation
- Django REST Framework Guide
- Odoo Architecture Patterns
- HTMX & Alpine.js Docs
- Tailwind CSS Components

**Built with ❤️ for the hackathon. Ship fast, break things responsibly! 🚀**
