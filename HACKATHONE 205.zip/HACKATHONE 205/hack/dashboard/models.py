from django.db import models
from django.contrib.auth.models import User


class DashboardWidget(models.Model):
    """Customizable dashboard widgets for users"""
    
    WIDGET_TYPES = [
        ('requests_by_status', 'Requests by Status'),
        ('requests_by_team', 'Requests by Team'),
        ('equipment_health', 'Equipment Health'),
        ('technician_workload', 'Technician Workload'),
        ('recent_activities', 'Recent Activities'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='dashboard_widgets')
    widget_type = models.CharField(max_length=50, choices=WIDGET_TYPES)
    position = models.IntegerField(default=0)
    is_visible = models.BooleanField(default=True)
    
    class Meta:
        ordering = ['position']
    
    def __str__(self):
        return f"{self.user.username} - {self.get_widget_type_display()}"
