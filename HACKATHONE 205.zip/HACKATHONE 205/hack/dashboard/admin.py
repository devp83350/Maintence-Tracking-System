from django.contrib import admin
from .models import DashboardWidget


@admin.register(DashboardWidget)
class DashboardWidgetAdmin(admin.ModelAdmin):
    list_display = ['user', 'widget_type', 'is_visible', 'position']
    list_filter = ['widget_type', 'is_visible']
    search_fields = ['user__first_name', 'user__last_name']
