from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver
from equipment.models import Equipment
from teams.models import MaintenanceTeam


class MaintenanceRequest(models.Model):
    """Core model: maintenance requests for equipment"""
    
    TYPE_CHOICES = [
        ('corrective', 'Corrective (Breakdown)'),
        ('preventive', 'Preventive (Scheduled)'),
    ]
    
    STATUS_CHOICES = [
        ('new', 'New'),
        ('in_progress', 'In Progress'),
        ('repaired', 'Repaired'),
        ('scrap', 'Scrap'),
    ]
    
    PRIORITY_CHOICES = [
        ('low', 'Low'),
        ('medium', 'Medium'),
        ('high', 'High'),
        ('critical', 'Critical'),
    ]
    
    # Core fields
    subject = models.CharField(max_length=200)
    description = models.TextField()
    equipment = models.ForeignKey(
        Equipment, 
        on_delete=models.PROTECT,
        related_name='maintenance_requests'
    )
    maintenance_team = models.ForeignKey(
        MaintenanceTeam, 
        on_delete=models.PROTECT,
        related_name='maintenance_requests'
    )
    assigned_to = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='assigned_requests'
    )
    
    # Request type and status
    request_type = models.CharField(max_length=20, choices=TYPE_CHOICES)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='new')
    priority = models.CharField(max_length=20, choices=PRIORITY_CHOICES, default='medium')
    
    # Scheduling
    scheduled_date = models.DateField(null=True, blank=True)
    start_date = models.DateTimeField(null=True, blank=True)
    completion_date = models.DateTimeField(null=True, blank=True)
    duration_hours = models.FloatField(null=True, blank=True)
    
    # Cost tracking
    estimated_cost = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    actual_cost = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    
    # Notes
    internal_notes = models.TextField(blank=True)
    
    # Metadata
    created_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        related_name='created_requests'
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['status']),
            models.Index(fields=['equipment']),
            models.Index(fields=['maintenance_team']),
            models.Index(fields=['assigned_to']),
        ]
    
    def __str__(self):
        return f"[{self.get_status_display()}] {self.subject} - {self.equipment}"
    
    def can_transition_to(self, new_status):
        """Check if status transition is allowed"""
        allowed_transitions = {
            'new': ['in_progress', 'scrap'],
            'in_progress': ['repaired', 'scrap'],
            'repaired': ['scrap'],
            'scrap': [],
        }
        return new_status in allowed_transitions.get(self.status, [])
    
    def mark_as_repaired(self):
        """Mark request as repaired and update equipment if scrapped"""
        if self.can_transition_to('repaired'):
            self.status = 'repaired'
            self.completion_date = models.functions.Now()
            self.save()
            return True
        return False
    
    def mark_as_scrapped(self):
        """Mark request as scrap and update equipment status"""
        if self.can_transition_to('scrap'):
            self.status = 'scrap'
            self.equipment.is_scrapped = True
            self.equipment.save()
            self.save()
            return True
        return False


class MaintenanceRequestAttachment(models.Model):
    """Attachments for maintenance requests (photos, documents)"""
    
    request = models.ForeignKey(
        MaintenanceRequest,
        on_delete=models.CASCADE,
        related_name='attachments'
    )
    file = models.FileField(upload_to='maintenance_attachments/%Y/%m/%d/')
    uploaded_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    uploaded_at = models.DateTimeField(auto_now_add=True)
    description = models.CharField(max_length=200, blank=True)
    
    class Meta:
        ordering = ['-uploaded_at']
    
    def __str__(self):
        return f"Attachment for {self.request}"


class MaintenanceRequestActivity(models.Model):
    """Activity log for maintenance requests"""
    
    ACTION_CHOICES = [
        ('created', 'Created'),
        ('assigned', 'Assigned'),
        ('status_changed', 'Status Changed'),
        ('comment_added', 'Comment Added'),
        ('attachment_added', 'Attachment Added'),
    ]
    
    request = models.ForeignKey(
        MaintenanceRequest,
        on_delete=models.CASCADE,
        related_name='activities'
    )
    action = models.CharField(max_length=20, choices=ACTION_CHOICES)
    performed_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    description = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['-created_at']
        verbose_name_plural = "Maintenance Request Activities"
    
    def __str__(self):
        return f"{self.get_action_display()} - {self.request}"


# Signals for automation
@receiver(post_save, sender=MaintenanceRequest)
def auto_fill_maintenance_team(sender, instance, created, **kwargs):
    """AUTO-FILL: When equipment is selected, auto-fill maintenance team"""
    if created and instance.equipment and not instance.maintenance_team:
        instance.maintenance_team = instance.equipment.maintenance_team
        instance.save(update_fields=['maintenance_team'])


@receiver(post_save, sender=MaintenanceRequest)
def create_activity_log(sender, instance, created, **kwargs):
    """Create activity log on request creation"""
    if created:
        MaintenanceRequestActivity.objects.create(
            request=instance,
            action='created',
            performed_by=instance.created_by,
            description=f"Maintenance request created: {instance.subject}"
        )
