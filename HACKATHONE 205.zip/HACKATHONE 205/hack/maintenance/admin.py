from django.contrib import admin
from .models import MaintenanceRequest, MaintenanceRequestAttachment, MaintenanceRequestActivity


class AttachmentInline(admin.TabularInline):
    model = MaintenanceRequestAttachment
    extra = 1
    readonly_fields = ['uploaded_at']


class ActivityInline(admin.TabularInline):
    model = MaintenanceRequestActivity
    extra = 0
    can_delete = False
    readonly_fields = ['action', 'performed_by', 'description', 'created_at']
    fields = ['action', 'performed_by', 'description', 'created_at']


@admin.register(MaintenanceRequest)
class MaintenanceRequestAdmin(admin.ModelAdmin):
    list_display = ['subject', 'equipment', 'status', 'priority', 'assigned_to', 'created_at']
    list_filter = ['status', 'priority', 'request_type', 'maintenance_team', 'created_at']
    search_fields = ['subject', 'description', 'equipment__name']
    readonly_fields = ['created_at', 'updated_at', 'created_by']
    
    fieldsets = (
        ('Request Info', {
            'fields': ('subject', 'description', 'equipment', 'maintenance_team')
        }),
        ('Assignment & Status', {
            'fields': ('assigned_to', 'status', 'request_type', 'priority')
        }),
        ('Scheduling', {
            'fields': ('scheduled_date', 'start_date', 'completion_date', 'duration_hours')
        }),
        ('Costs', {
            'fields': ('estimated_cost', 'actual_cost'),
            'classes': ('collapse',)
        }),
        ('Notes', {
            'fields': ('internal_notes',),
            'classes': ('collapse',)
        }),
        ('System Info', {
            'fields': ('created_by', 'created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )
    
    inlines = [AttachmentInline, ActivityInline]
    
    def save_model(self, request, obj, form, change):
        if not obj.created_by:
            obj.created_by = request.user
        super().save_model(request, obj, form, change)


@admin.register(MaintenanceRequestAttachment)
class AttachmentAdmin(admin.ModelAdmin):
    list_display = ['request', 'description', 'uploaded_by', 'uploaded_at']
    list_filter = ['uploaded_at']
    search_fields = ['request__subject', 'description']
    readonly_fields = ['uploaded_at']


@admin.register(MaintenanceRequestActivity)
class ActivityAdmin(admin.ModelAdmin):
    list_display = ['request', 'action', 'performed_by', 'created_at']
    list_filter = ['action', 'created_at']
    search_fields = ['request__subject', 'description']
    readonly_fields = ['created_at']
    can_delete = False
