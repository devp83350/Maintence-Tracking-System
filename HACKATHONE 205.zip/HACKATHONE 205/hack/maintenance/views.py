from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.db.models import Count, Q
from django.utils import timezone
from .models import MaintenanceRequest, MaintenanceRequestAttachment, MaintenanceRequestActivity
from .serializers import (
    MaintenanceRequestSerializer, 
    MaintenanceRequestListSerializer,
    MaintenanceRequestCreateSerializer,
    MaintenanceRequestStatusUpdateSerializer,
    MaintenanceRequestAttachmentSerializer
)


class MaintenanceRequestViewSet(viewsets.ModelViewSet):
    """
    ViewSet for Maintenance Requests - the heart of the system
    Provides CRUD, status transitions, kanban, calendar, and reporting
    """
    permission_classes = [IsAuthenticated]
    filterset_fields = ['status', 'priority', 'request_type', 'maintenance_team', 'assigned_to']
    search_fields = ['subject', 'description', 'equipment__name']
    ordering_fields = ['created_at', 'scheduled_date', 'priority']
    ordering = ['-created_at']
    
    def get_queryset(self):
        return MaintenanceRequest.objects.select_related(
            'equipment', 'maintenance_team', 'assigned_to', 'created_by'
        ).prefetch_related('activities', 'attachments')
    
    def get_serializer_class(self):
        if self.action == 'create':
            return MaintenanceRequestCreateSerializer
        elif self.action == 'update_status':
            return MaintenanceRequestStatusUpdateSerializer
        elif self.action == 'list':
            return MaintenanceRequestListSerializer
        return MaintenanceRequestSerializer
    
    def create(self, request, *args, **kwargs):
        """Create new maintenance request with auto-fill logic"""
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        
        # Return full serialized object
        request_obj = serializer.instance
        response_serializer = MaintenanceRequestSerializer(request_obj)
        return Response(response_serializer.data, status=status.HTTP_201_CREATED)
    
    # ===== Status Transitions =====
    @action(detail=True, methods=['post'])
    def mark_in_progress(self, request, pk=None):
        """Mark request as in progress"""
        maintenance_request = self.get_object()
        if maintenance_request.can_transition_to('in_progress'):
            maintenance_request.status = 'in_progress'
            maintenance_request.start_date = timezone.now()
            maintenance_request.save()
            
            MaintenanceRequestActivity.objects.create(
                request=maintenance_request,
                action='status_changed',
                performed_by=request.user,
                description=f"Status changed to In Progress"
            )
            
            return Response(
                MaintenanceRequestSerializer(maintenance_request).data,
                status=status.HTTP_200_OK
            )
        return Response(
            {'error': 'Invalid status transition'},
            status=status.HTTP_400_BAD_REQUEST
        )
    
    @action(detail=True, methods=['post'])
    def mark_repaired(self, request, pk=None):
        """Mark request as repaired"""
        maintenance_request = self.get_object()
        if maintenance_request.mark_as_repaired():
            MaintenanceRequestActivity.objects.create(
                request=maintenance_request,
                action='status_changed',
                performed_by=request.user,
                description=f"Status changed to Repaired"
            )
            
            return Response(
                MaintenanceRequestSerializer(maintenance_request).data,
                status=status.HTTP_200_OK
            )
        return Response(
            {'error': 'Invalid status transition'},
            status=status.HTTP_400_BAD_REQUEST
        )
    
    @action(detail=True, methods=['post'])
    def mark_scrapped(self, request, pk=None):
        """Mark request and equipment as scrapped"""
        maintenance_request = self.get_object()
        if maintenance_request.mark_as_scrapped():
            MaintenanceRequestActivity.objects.create(
                request=maintenance_request,
                action='status_changed',
                performed_by=request.user,
                description=f"Status changed to Scrap - Equipment marked as scrapped"
            )
            
            return Response(
                MaintenanceRequestSerializer(maintenance_request).data,
                status=status.HTTP_200_OK
            )
        return Response(
            {'error': 'Invalid status transition'},
            status=status.HTTP_400_BAD_REQUEST
        )
    
    # ===== Assignment =====
    @action(detail=True, methods=['post'])
    def assign_to(self, request, pk=None):
        """Assign maintenance request to a technician"""
        maintenance_request = self.get_object()
        user_id = request.data.get('user_id')
        
        if not user_id:
            return Response({'error': 'user_id required'}, status=status.HTTP_400_BAD_REQUEST)
        
        from django.contrib.auth.models import User
        try:
            user = User.objects.get(id=user_id)
            maintenance_request.assigned_to = user
            maintenance_request.save()
            
            MaintenanceRequestActivity.objects.create(
                request=maintenance_request,
                action='assigned',
                performed_by=request.user,
                description=f"Assigned to {user.get_full_name()}"
            )
            
            return Response(
                MaintenanceRequestSerializer(maintenance_request).data,
                status=status.HTTP_200_OK
            )
        except User.DoesNotExist:
            return Response({'error': 'User not found'}, status=status.HTTP_404_NOT_FOUND)
    
    # ===== Kanban Board =====
    @action(detail=False, methods=['get'])
    def kanban_board(self, request):
        """Get kanban board data grouped by status"""
        team_id = request.query_params.get('team_id')
        
        queryset = self.get_queryset()
        if team_id:
            queryset = queryset.filter(maintenance_team_id=team_id)
        
        kanban_data = {}
        for status_key, status_label in MaintenanceRequest.STATUS_CHOICES:
            kanban_data[status_key] = {
                'label': status_label,
                'count': queryset.filter(status=status_key).count(),
                'requests': MaintenanceRequestListSerializer(
                    queryset.filter(status=status_key).order_by('-priority', '-created_at'),
                    many=True
                ).data
            }
        
        return Response(kanban_data)
    
    # ===== Calendar View =====
    @action(detail=False, methods=['get'])
    def calendar_view(self, request):
        """Get preventive maintenance requests for calendar"""
        queryset = self.get_queryset().filter(request_type='preventive')
        
        calendar_events = []
        for req in queryset:
            if req.scheduled_date:
                calendar_events.append({
                    'id': req.id,
                    'title': req.subject,
                    'date': req.scheduled_date,
                    'status': req.status,
                    'priority': req.priority,
                    'equipment': req.equipment.name,
                    'team': req.maintenance_team.name
                })
        
        return Response(calendar_events)
    
    # ===== Dashboard Stats =====
    @action(detail=False, methods=['get'])
    def dashboard_stats(self, request):
        """Get statistics for dashboard"""
        queryset = self.get_queryset()
        
        stats = {
            'total_requests': queryset.count(),
            'by_status': {},
            'by_priority': {},
            'by_type': {},
            'overdue_count': queryset.filter(
                scheduled_date__lt=timezone.now().date(),
                status__in=['new', 'in_progress']
            ).count(),
            'my_assignments': queryset.filter(assigned_to=request.user).count(),
        }
        
        # Status breakdown
        for status_key, status_label in MaintenanceRequest.STATUS_CHOICES:
            stats['by_status'][status_key] = queryset.filter(status=status_key).count()
        
        # Priority breakdown
        for priority_key, priority_label in MaintenanceRequest.PRIORITY_CHOICES:
            stats['by_priority'][priority_key] = queryset.filter(priority=priority_key).count()
        
        # Type breakdown
        for type_key, type_label in MaintenanceRequest.TYPE_CHOICES:
            stats['by_type'][type_key] = queryset.filter(request_type=type_key).count()
        
        return Response(stats)
    
    # ===== Team Reports =====
    @action(detail=False, methods=['get'])
    def team_workload(self, request):
        """Get workload statistics per team"""
        from teams.models import MaintenanceTeam
        
        teams = MaintenanceTeam.objects.annotate(
            total_requests=Count('maintenance_requests'),
            open_requests=Count(
                'maintenance_requests',
                filter=Q(maintenance_requests__status__in=['new', 'in_progress'])
            ),
            overdue_requests=Count(
                'maintenance_requests',
                filter=Q(
                    maintenance_requests__scheduled_date__lt=timezone.now().date(),
                    maintenance_requests__status__in=['new', 'in_progress']
                )
            )
        )
        
        return Response([{
            'team_id': team.id,
            'name': team.name,
            'total_requests': team.total_requests,
            'open_requests': team.open_requests,
            'overdue_requests': team.overdue_requests,
        } for team in teams])
    
    # ===== Technician Workload =====
    @action(detail=False, methods=['get'])
    def technician_workload(self, request):
        """Get workload per technician"""
        from django.contrib.auth.models import User
        
        technicians = User.objects.annotate(
            assigned_requests=Count('assigned_requests'),
            open_assigned=Count(
                'assigned_requests',
                filter=Q(assigned_requests__status__in=['new', 'in_progress'])
            )
        ).filter(assigned_requests__gt=0).distinct()
        
        return Response([{
            'technician_id': tech.id,
            'name': tech.get_full_name(),
            'assigned_requests': tech.assigned_requests,
            'open_assigned': tech.open_assigned,
        } for tech in technicians])
