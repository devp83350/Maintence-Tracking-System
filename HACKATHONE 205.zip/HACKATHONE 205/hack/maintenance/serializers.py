from rest_framework import serializers
from .models import MaintenanceRequest, MaintenanceRequestAttachment, MaintenanceRequestActivity


class MaintenanceRequestActivitySerializer(serializers.ModelSerializer):
    performed_by_name = serializers.CharField(source='performed_by.get_full_name', read_only=True)
    
    class Meta:
        model = MaintenanceRequestActivity
        fields = ['id', 'action', 'performed_by', 'performed_by_name', 'description', 'created_at']
        read_only_fields = ['created_at']


class MaintenanceRequestAttachmentSerializer(serializers.ModelSerializer):
    uploaded_by_name = serializers.CharField(source='uploaded_by.get_full_name', read_only=True)
    
    class Meta:
        model = MaintenanceRequestAttachment
        fields = ['id', 'file', 'uploaded_by', 'uploaded_by_name', 'uploaded_at', 'description']
        read_only_fields = ['uploaded_at']


class MaintenanceRequestSerializer(serializers.ModelSerializer):
    equipment_name = serializers.CharField(source='equipment.name', read_only=True)
    team_name = serializers.CharField(source='maintenance_team.name', read_only=True)
    assigned_to_name = serializers.CharField(source='assigned_to.get_full_name', read_only=True)
    created_by_name = serializers.CharField(source='created_by.get_full_name', read_only=True)
    
    activities = MaintenanceRequestActivitySerializer(many=True, read_only=True)
    attachments = MaintenanceRequestAttachmentSerializer(many=True, read_only=True)
    
    class Meta:
        model = MaintenanceRequest
        fields = [
            'id', 'subject', 'description', 'equipment', 'equipment_name',
            'maintenance_team', 'team_name', 'assigned_to', 'assigned_to_name',
            'request_type', 'status', 'priority', 'scheduled_date', 'start_date',
            'completion_date', 'duration_hours', 'estimated_cost', 'actual_cost',
            'internal_notes', 'created_by', 'created_by_name', 'created_at', 'updated_at',
            'activities', 'attachments'
        ]
        read_only_fields = ['created_by', 'created_at', 'updated_at']


class MaintenanceRequestListSerializer(serializers.ModelSerializer):
    """Lightweight serializer for list and kanban views"""
    equipment_name = serializers.CharField(source='equipment.name', read_only=True)
    team_name = serializers.CharField(source='maintenance_team.name', read_only=True)
    assigned_to_name = serializers.CharField(source='assigned_to.get_full_name', read_only=True)
    
    class Meta:
        model = MaintenanceRequest
        fields = [
            'id', 'subject', 'equipment', 'equipment_name', 'team_name',
            'assigned_to', 'assigned_to_name', 'status', 'priority', 'scheduled_date',
            'created_at'
        ]


class MaintenanceRequestCreateSerializer(serializers.ModelSerializer):
    """Serializer for creating maintenance requests with auto-fill logic"""
    
    class Meta:
        model = MaintenanceRequest
        fields = [
            'subject', 'description', 'equipment', 'maintenance_team',
            'assigned_to', 'request_type', 'priority', 'scheduled_date',
            'estimated_cost', 'internal_notes'
        ]
    
    def create(self, validated_data):
        """Auto-fill maintenance_team from equipment if not provided"""
        if not validated_data.get('maintenance_team') and validated_data.get('equipment'):
            validated_data['maintenance_team'] = validated_data['equipment'].maintenance_team
        
        # Set created_by from request context
        validated_data['created_by'] = self.context['request'].user
        validated_data['status'] = 'new'
        
        return super().create(validated_data)


class MaintenanceRequestStatusUpdateSerializer(serializers.ModelSerializer):
    """Serializer for updating request status with validation"""
    
    class Meta:
        model = MaintenanceRequest
        fields = ['status', 'completion_date']
    
    def validate_status(self, value):
        instance = self.instance
        if not instance.can_transition_to(value):
            raise serializers.ValidationError(
                f"Cannot transition from '{instance.get_status_display()}' to '{value}'"
            )
        return value
