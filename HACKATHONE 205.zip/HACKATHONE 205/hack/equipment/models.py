from django.db import models
from django.contrib.auth.models import User
from teams.models import MaintenanceTeam


class Equipment(models.Model):
    """Represents equipment/assets that need maintenance"""
    
    name = models.CharField(max_length=100)
    serial_number = models.CharField(max_length=50, unique=True)
    department = models.CharField(max_length=100)
    assigned_to = models.ForeignKey(
        User, 
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True,
        related_name='equipment_assigned'
    )
    maintenance_team = models.ForeignKey(MaintenanceTeam, on_delete=models.PROTECT)
    location = models.CharField(max_length=100)
    purchase_date = models.DateField()
    warranty_expiry = models.DateField()
    is_scrapped = models.BooleanField(default=False)
    
    # Metadata
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-created_at']
        verbose_name_plural = "Equipment"
    
    def __str__(self):
        return f"{self.name} ({self.serial_number})"
    
    @property
    def open_requests_count(self):
        """Get count of open maintenance requests for this equipment"""
        from maintenance.models import MaintenanceRequest
        return MaintenanceRequest.objects.filter(
            equipment=self,
            status__in=['new', 'in_progress']
        ).count()
    
    @property
    def is_under_warranty(self):
        from datetime import date
        return date.today() <= self.warranty_expiry


class EquipmentHistory(models.Model):
    """Track changes to equipment"""
    
    equipment = models.ForeignKey(Equipment, on_delete=models.CASCADE, related_name='history')
    changed_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    changed_at = models.DateTimeField(auto_now_add=True)
    change_description = models.TextField()
    
    class Meta:
        ordering = ['-changed_at']
        verbose_name_plural = "Equipment Histories"
    
    def __str__(self):
        return f"{self.equipment} - {self.changed_at}"
