from rest_framework import serializers
from .models import Equipment, EquipmentHistory


class EquipmentHistorySerializer(serializers.ModelSerializer):
    changed_by_name = serializers.CharField(source='changed_by.get_full_name', read_only=True)
    
    class Meta:
        model = EquipmentHistory
        fields = ['id', 'equipment', 'changed_by', 'changed_by_name', 'changed_at', 'change_description']
        read_only_fields = ['changed_at']


class EquipmentSerializer(serializers.ModelSerializer):
    maintenance_team_name = serializers.CharField(source='maintenance_team.name', read_only=True)
    assigned_to_name = serializers.CharField(source='assigned_to.get_full_name', read_only=True)
    open_requests_count = serializers.IntegerField(read_only=True)
    is_under_warranty = serializers.BooleanField(read_only=True)
    history = EquipmentHistorySerializer(many=True, read_only=True)
    
    class Meta:
        model = Equipment
        fields = [
            'id', 'name', 'serial_number', 'department', 'assigned_to', 'assigned_to_name',
            'maintenance_team', 'maintenance_team_name', 'location', 'purchase_date',
            'warranty_expiry', 'is_scrapped', 'is_under_warranty', 'open_requests_count',
            'created_at', 'updated_at', 'history'
        ]
        read_only_fields = ['created_at', 'updated_at']


class EquipmentListSerializer(serializers.ModelSerializer):
    """Lightweight serializer for list views"""
    maintenance_team_name = serializers.CharField(source='maintenance_team.name', read_only=True)
    open_requests_count = serializers.IntegerField(read_only=True)
    
    class Meta:
        model = Equipment
        fields = [
            'id', 'name', 'serial_number', 'department', 'maintenance_team',
            'maintenance_team_name', 'is_scrapped', 'open_requests_count', 'created_at'
        ]
