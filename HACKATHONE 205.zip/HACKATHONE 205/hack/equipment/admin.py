from django.contrib import admin
from .models import Equipment, EquipmentHistory


@admin.register(Equipment)
class EquipmentAdmin(admin.ModelAdmin):
    list_display = ['name', 'serial_number', 'department', 'maintenance_team', 'is_scrapped', 'created_at']
    list_filter = ['department', 'maintenance_team', 'is_scrapped', 'created_at']
    search_fields = ['name', 'serial_number', 'department', 'location']
    readonly_fields = ['created_at', 'updated_at']
    
    fieldsets = (
        ('Basic Info', {
            'fields': ('name', 'serial_number', 'department', 'location')
        }),
        ('Maintenance', {
            'fields': ('maintenance_team', 'assigned_to')
        }),
        ('Lifecycle', {
            'fields': ('purchase_date', 'warranty_expiry', 'is_scrapped')
        }),
        ('System Info', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )


@admin.register(EquipmentHistory)
class EquipmentHistoryAdmin(admin.ModelAdmin):
    list_display = ['equipment', 'changed_by', 'changed_at']
    list_filter = ['equipment', 'changed_at']
    search_fields = ['equipment__name', 'change_description']
    readonly_fields = ['changed_at']
