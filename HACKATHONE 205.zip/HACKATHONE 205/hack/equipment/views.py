from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from .models import Equipment, EquipmentHistory
from .serializers import EquipmentSerializer, EquipmentListSerializer


class EquipmentViewSet(viewsets.ModelViewSet):
    """
    ViewSet for Equipment management
    Provides CRUD operations and custom actions
    """
    permission_classes = [IsAuthenticated]
    filterset_fields = ['department', 'maintenance_team', 'is_scrapped']
    search_fields = ['name', 'serial_number', 'department']
    ordering_fields = ['name', 'created_at']
    ordering = ['-created_at']
    
    def get_queryset(self):
        return Equipment.objects.select_related('maintenance_team', 'assigned_to')
    
    def get_serializer_class(self):
        if self.action == 'list':
            return EquipmentListSerializer
        return EquipmentSerializer
    
    @action(detail=True, methods=['get'])
    def maintenance_requests(self, request, pk=None):
        """Get all maintenance requests for this equipment"""
        equipment = self.get_object()
        from maintenance.models import MaintenanceRequest
        from maintenance.serializers import MaintenanceRequestListSerializer
        
        requests = MaintenanceRequest.objects.filter(equipment=equipment)
        serializer = MaintenanceRequestListSerializer(requests, many=True)
        return Response(serializer.data)
    
    @action(detail=True, methods=['get'])
    def open_requests(self, request, pk=None):
        """Get open maintenance requests for this equipment"""
        equipment = self.get_object()
        from maintenance.models import MaintenanceRequest
        from maintenance.serializers import MaintenanceRequestListSerializer
        
        requests = MaintenanceRequest.objects.filter(
            equipment=equipment,
            status__in=['new', 'in_progress']
        )
        serializer = MaintenanceRequestListSerializer(requests, many=True)
        return Response({
            'count': requests.count(),
            'requests': serializer.data
        })
    
    @action(detail=True, methods=['post'])
    def mark_as_scrapped(self, request, pk=None):
        """Mark equipment as scrapped"""
        equipment = self.get_object()
        equipment.is_scrapped = True
        equipment.save()
        return Response({'status': 'equipment marked as scrapped'})
    
    @action(detail=True, methods=['get'])
    def warranty_status(self, request, pk=None):
        """Get warranty status of equipment"""
        equipment = self.get_object()
        return Response({
            'is_under_warranty': equipment.is_under_warranty,
            'warranty_expiry': equipment.warranty_expiry,
            'days_until_expiry': (equipment.warranty_expiry - __import__('datetime').date.today()).days
        })
