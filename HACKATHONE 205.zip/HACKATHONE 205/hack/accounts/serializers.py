from rest_framework import serializers
from django.contrib.auth.models import User
from .models import UserProfile


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'first_name', 'last_name', 'email']


class UserProfileSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    user_id = serializers.IntegerField(write_only=True)
    full_name = serializers.CharField(read_only=True)
    
    class Meta:
        model = UserProfile
        fields = ['id', 'user', 'user_id', 'role', 'phone', 'department', 'is_active', 'full_name']
        read_only_fields = ['created_at', 'updated_at']
