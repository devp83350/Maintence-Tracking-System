"""
Analytics Service Microservice
Processes events to build read models for reporting
Provides metrics, dashboards, and insights
"""

from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse
import json
from typing import Dict, List, Any
from datetime import datetime
import sys
import os

# Add shared directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../')))

from shared.event_bus import get_event_bus

class AnalyticsService:
    """Analytics and reporting service"""

    def __init__(self):
        self.event_bus = get_event_bus()
        self.metrics: Dict[str, Any] = {
            'total_requests': 0,
            'completed_requests': 0,
            'pending_requests': 0,
            'average_resolution_time': 0,
            'team_performance': {},
            'equipment_stats': {}
        }
        self._subscribe_to_events()

    def _subscribe_to_events(self):
        """Subscribe to domain events"""
        self.event_bus.subscribe('request.created', self._on_request_created)
        self.event_bus.subscribe('request.completed', self._on_request_completed)
        self.event_bus.subscribe('request.assigned', self._on_request_assigned)

    def _on_request_created(self, data: Dict):
        """Handle request created event"""
        self.metrics['total_requests'] += 1
        self.metrics['pending_requests'] += 1
        print(f'✓ Analytics: Request created - Total: {self.metrics["total_requests"]}')

    def _on_request_completed(self, data: Dict):
        """Handle request completed event"""
        self.metrics['completed_requests'] += 1
        self.metrics['pending_requests'] -= 1
        
        # Update average resolution time
        hours_spent = data.get('hours_spent', 0)
        if self.metrics['completed_requests'] > 0:
            self.metrics['average_resolution_time'] = (
                (self.metrics['average_resolution_time'] * 
                 (self.metrics['completed_requests'] - 1) + hours_spent) /
                self.metrics['completed_requests']
            )
        print(f'✓ Analytics: Request completed - Avg time: {self.metrics["average_resolution_time"]:.2f}h')

    def _on_request_assigned(self, data: Dict):
        """Handle request assigned event"""
        team_id = data.get('team_id')
        if team_id:
            if team_id not in self.metrics['team_performance']:
                self.metrics['team_performance'][team_id] = {
                    'assigned': 0,
                    'completed': 0,
                    'performance_score': 0
                }
            self.metrics['team_performance'][team_id]['assigned'] += 1

    def get_dashboard_metrics(self) -> Dict[str, Any]:
        """Get dashboard metrics"""
        return {
            'timestamp': datetime.now().isoformat(),
            'metrics': self.metrics,
            'summary': {
                'total_requests': self.metrics['total_requests'],
                'completed_requests': self.metrics['completed_requests'],
                'pending_requests': self.metrics['pending_requests'],
                'completion_rate': (
                    self.metrics['completed_requests'] / self.metrics['total_requests'] * 100
                    if self.metrics['total_requests'] > 0 else 0
                ),
                'average_resolution_hours': round(self.metrics['average_resolution_time'], 2)
            }
        }

    def get_team_performance(self) -> Dict[str, Any]:
        """Get team performance metrics"""
        return {
            'timestamp': datetime.now().isoformat(),
            'teams': self.metrics['team_performance']
        }

    def get_equipment_stats(self) -> Dict[str, Any]:
        """Get equipment statistics"""
        return {
            'timestamp': datetime.now().isoformat(),
            'equipment': self.metrics['equipment_stats']
        }

# Global service instance
analytics_service = AnalyticsService()

class AnalyticsHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        path = urlparse(self.path).path
        
        try:
            if path == '/dashboard':
                metrics = analytics_service.get_dashboard_metrics()
                self.send_json_response(metrics)
            elif path == '/team-performance':
                performance = analytics_service.get_team_performance()
                self.send_json_response(performance)
            elif path == '/equipment-stats':
                stats = analytics_service.get_equipment_stats()
                self.send_json_response(stats)
            elif path == '/metrics':
                self.send_json_response(analytics_service.metrics)
            elif path == '/health':
                self.send_json_response({'status': 'healthy'})
            else:
                self.send_json_response({'error': 'Not found'}, 404)
        except Exception as e:
            self.send_json_response({'error': str(e)}, 500)

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

    def send_json_response(self, data: Any, status_code: int = 200):
        self.send_response(status_code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(json.dumps(data).encode('utf-8'))

    def log_message(self, format, *args):
        print(f"[ANALYTICS-SERVICE] {format % args}")

if __name__ == '__main__':
    PORT = 5004
    server = HTTPServer(('0.0.0.0', PORT), AnalyticsHandler)
    print(f'✓ Analytics Service running on http://localhost:{PORT}')
    print(f'✓ Event-driven reporting enabled')
    server.serve_forever()
