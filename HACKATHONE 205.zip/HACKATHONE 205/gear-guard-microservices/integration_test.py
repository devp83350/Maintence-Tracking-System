"""
Integration Test Script for GearGuard Microservices
Verifies all services are working together correctly
"""

import requests
import json
import time
from typing import Dict, Any

class GearGuardIntegrationTest:
    """Test GearGuard microservices integration"""

    def __init__(self, gateway_url: str = 'http://localhost:5000'):
        self.gateway_url = gateway_url
        self.results = []

    def test_gateway_health(self) -> bool:
        """Test API Gateway health"""
        try:
            url = f'{self.gateway_url}/api/gateway/health'
            response = requests.get(url, timeout=5)
            
            if response.status_code == 200:
                data = response.json()
                print(f'✓ Gateway Health: {data["status"]}')
                print(f'  Services: {data["services"]}')
                return True
            else:
                print(f'✗ Gateway health check failed: {response.status_code}')
                return False
        except Exception as e:
            print(f'✗ Gateway connection error: {e}')
            return False

    def test_auth_service(self) -> Dict[str, Any]:
        """Test Auth Service"""
        print('\n📝 Testing Auth Service...')
        
        # Register user
        try:
            url = f'{self.gateway_url}/api/auth/register'
            user_data = {
                'username': f'technician_{int(time.time())}',
                'password': 'password123',
                'role': 'technician'
            }
            response = requests.post(url, json=user_data, timeout=5)
            
            if response.status_code == 201:
                user = response.json()
                print(f'✓ User registered: {user["id"]}')
                return user
            else:
                print(f'✗ User registration failed: {response.status_code}')
                return None
        except Exception as e:
            print(f'✗ Auth service error: {e}')
            return None

    def test_equipment_service(self) -> Dict[str, Any]:
        """Test Equipment Service"""
        print('\n🔧 Testing Equipment Service...')
        
        try:
            url = f'{self.gateway_url}/api/equipment'
            equipment_data = {
                'name': f'Equipment_{int(time.time())}',
                'serial_number': f'SN-{int(time.time())}',
                'department': 'Manufacturing',
                'location': 'Floor 1'
            }
            response = requests.post(url, json=equipment_data, timeout=5)
            
            if response.status_code == 201:
                equipment = response.json()
                print(f'✓ Equipment created: {equipment["id"]}')
                
                # List equipment
                list_url = f'{self.gateway_url}/api/equipment'
                list_response = requests.get(list_url, timeout=5)
                if list_response.status_code == 200:
                    equipment_list = list_response.json()
                    print(f'✓ Equipment list retrieved: {len(equipment_list)} items')
                
                return equipment
            else:
                print(f'✗ Equipment creation failed: {response.status_code}')
                return None
        except Exception as e:
            print(f'✗ Equipment service error: {e}')
            return None

    def test_workflow_service(self, equipment_id: str = None) -> Dict[str, Any]:
        """Test Workflow Service"""
        print('\n📋 Testing Workflow Service...')
        
        try:
            url = f'{self.gateway_url}/api/workflow/requests'
            request_data = {
                'subject': f'Maintenance_{int(time.time())}',
                'description': 'Test maintenance request',
                'equipment_id': equipment_id or 'test-equipment-id',
                'request_type': 'preventive',
                'priority': 'medium'
            }
            response = requests.post(url, json=request_data, timeout=5)
            
            if response.status_code == 201:
                request_obj = response.json()
                print(f'✓ Request created: {request_obj["id"]}')
                print(f'  Status: {request_obj["status"]}')
                
                # List requests
                list_url = f'{self.gateway_url}/api/workflow/requests'
                list_response = requests.get(list_url, timeout=5)
                if list_response.status_code == 200:
                    requests_list = list_response.json()
                    print(f'✓ Requests list retrieved: {len(requests_list)} items')
                
                return request_obj
            else:
                print(f'✗ Request creation failed: {response.status_code}')
                return None
        except Exception as e:
            print(f'✗ Workflow service error: {e}')
            return None

    def test_analytics_service(self) -> bool:
        """Test Analytics Service"""
        print('\n📊 Testing Analytics Service...')
        
        try:
            url = f'{self.gateway_url}/api/analytics/dashboard'
            response = requests.get(url, timeout=5)
            
            if response.status_code == 200:
                metrics = response.json()
                print(f'✓ Dashboard metrics retrieved')
                print(f'  Total requests: {metrics.get("summary", {}).get("total_requests", 0)}')
                print(f'  Completed: {metrics.get("summary", {}).get("completed_requests", 0)}')
                print(f'  Pending: {metrics.get("summary", {}).get("pending_requests", 0)}')
                return True
            else:
                print(f'✗ Dashboard retrieval failed: {response.status_code}')
                return False
        except Exception as e:
            print(f'✗ Analytics service error: {e}')
            return False

    def test_team_management(self) -> Dict[str, Any]:
        """Test Team Management"""
        print('\n👥 Testing Team Management...')
        
        try:
            url = f'{self.gateway_url}/api/auth/teams'
            team_data = {
                'name': f'Team_{int(time.time())}',
                'specialization': 'Mechanical'
            }
            response = requests.post(url, json=team_data, timeout=5)
            
            if response.status_code == 201:
                team = response.json()
                print(f'✓ Team created: {team["id"]}')
                
                # List teams
                list_url = f'{self.gateway_url}/api/auth/teams'
                list_response = requests.get(list_url, timeout=5)
                if list_response.status_code == 200:
                    teams_list = list_response.json()
                    print(f'✓ Teams list retrieved: {len(teams_list)} teams')
                
                return team
            else:
                print(f'✗ Team creation failed: {response.status_code}')
                return None
        except Exception as e:
            print(f'✗ Team management error: {e}')
            return None

    def test_saga_workflow(self) -> bool:
        """Test Saga pattern workflow"""
        print('\n🔄 Testing Saga Workflow...')
        
        try:
            # Create equipment
            equipment = self.test_equipment_service()
            if not equipment:
                return False
            
            # Create request
            request_obj = self.test_workflow_service(equipment['id'])
            if not request_obj:
                return False
            
            # Simulate assignment (Saga step 1)
            print('  [Saga] Attempting to assign request...')
            url = f'{self.gateway_url}/api/workflow/requests/{request_obj["id"]}'
            assign_data = {
                'action': 'assign',
                'team_id': 'team-123',
                'technician_id': 'tech-456'
            }
            response = requests.put(url, json=assign_data, timeout=5)
            
            if response.status_code == 200:
                assigned = response.json()
                print(f'✓ Request assigned (Saga step 1)')
                print(f'  Status: {assigned["status"]}')
                
                # Simulate starting work (Saga step 2)
                start_data = {'action': 'start'}
                response = requests.put(url, json=start_data, timeout=5)
                if response.status_code == 200:
                    started = response.json()
                    print(f'✓ Work started (Saga step 2)')
                    print(f'  Status: {started["status"]}')
                    
                    # Simulate completion (Saga step 3)
                    complete_data = {
                        'action': 'complete',
                        'hours_spent': 2.5,
                        'completion_notes': 'Maintenance completed successfully'
                    }
                    response = requests.put(url, json=complete_data, timeout=5)
                    if response.status_code == 200:
                        completed = response.json()
                        print(f'✓ Work completed (Saga step 3)')
                        print(f'  Status: {completed["status"]}')
                        print(f'✓ Saga workflow completed successfully!')
                        return True
            
            print(f'✗ Saga workflow failed')
            return False
            
        except Exception as e:
            print(f'✗ Saga workflow error: {e}')
            return False

    def run_all_tests(self):
        """Run all integration tests"""
        print('=' * 60)
        print('GearGuard Microservices Integration Tests')
        print('=' * 60)
        
        tests_passed = 0
        tests_total = 0
        
        # Test 1: Gateway Health
        tests_total += 1
        if self.test_gateway_health():
            tests_passed += 1
        
        # Test 2: Auth Service
        tests_total += 1
        if self.test_auth_service():
            tests_passed += 1
        
        # Test 3: Equipment Service
        tests_total += 1
        equipment = self.test_equipment_service()
        if equipment:
            tests_passed += 1
        
        # Test 4: Workflow Service
        tests_total += 1
        if self.test_workflow_service(equipment['id'] if equipment else None):
            tests_passed += 1
        
        # Test 5: Analytics Service
        tests_total += 1
        if self.test_analytics_service():
            tests_passed += 1
        
        # Test 6: Team Management
        tests_total += 1
        if self.test_team_management():
            tests_passed += 1
        
        # Test 7: Saga Workflow
        tests_total += 1
        if self.test_saga_workflow():
            tests_passed += 1
        
        # Summary
        print('\n' + '=' * 60)
        print(f'Test Results: {tests_passed}/{tests_total} passed')
        print('=' * 60)
        
        if tests_passed == tests_total:
            print('✅ All integration tests passed!')
            return True
        else:
            print(f'⚠️  {tests_total - tests_passed} test(s) failed')
            return False

if __name__ == '__main__':
    import sys
    
    gateway_url = 'http://localhost:5000'
    if len(sys.argv) > 1:
        gateway_url = sys.argv[1]
    
    tester = GearGuardIntegrationTest(gateway_url)
    success = tester.run_all_tests()
    
    sys.exit(0 if success else 1)
