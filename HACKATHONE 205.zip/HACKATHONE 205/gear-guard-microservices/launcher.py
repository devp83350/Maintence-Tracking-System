#!/usr/bin/env python3
"""
GearGuard Microservices Launcher
Starts all services with proper initialization and health checks
"""

import subprocess
import time
import requests
import sys
from typing import Dict, List
import threading

class MicroservicesLauncher:
    """Launch and monitor all GearGuard microservices"""

    SERVICES = {
        'event-store': {
            'cmd': ['python', 'event-store/event_store.py'],
            'port': 5005,
            'health_url': 'http://localhost:5005/health'
        },
        'auth-service': {
            'cmd': ['python', 'auth-service/src/auth_service.py'],
            'port': 5001,
            'health_url': 'http://localhost:5001/health'
        },
        'equipment-service': {
            'cmd': ['python', 'equipment-service/src/equipment_service.py'],
            'port': 5002,
            'health_url': 'http://localhost:5002/health'
        },
        'workflow-service': {
            'cmd': ['python', 'workflow-service/src/workflow_service.py'],
            'port': 5003,
            'health_url': 'http://localhost:5003/health'
        },
        'analytics-service': {
            'cmd': ['python', 'analytics-service/src/analytics_service.py'],
            'port': 5004,
            'health_url': 'http://localhost:5004/health'
        },
        'api-gateway': {
            'cmd': ['python', 'api-gateway/gateway.py'],
            'port': 5000,
            'health_url': 'http://localhost:5000/api/gateway/health'
        }
    }

    def __init__(self):
        self.processes: Dict[str, subprocess.Popen] = {}
        self.startup_order = [
            'event-store',
            'auth-service',
            'equipment-service',
            'workflow-service',
            'analytics-service',
            'api-gateway'
        ]

    def start_service(self, service_name: str) -> bool:
        """Start a single service"""
        if service_name not in self.SERVICES:
            print(f'✗ Service {service_name} not found')
            return False

        service_config = self.SERVICES[service_name]
        print(f'\n🚀 Starting {service_name}...')

        try:
            process = subprocess.Popen(
                service_config['cmd'],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            self.processes[service_name] = process
            print(f'✓ {service_name} process started (PID: {process.pid})')
            return True
        except Exception as e:
            print(f'✗ Failed to start {service_name}: {e}')
            return False

    def check_health(self, service_name: str, timeout: int = 30) -> bool:
        """Check if service is healthy"""
        if service_name not in self.SERVICES:
            return False

        service_config = self.SERVICES[service_name]
        health_url = service_config['health_url']
        start_time = time.time()

        while time.time() - start_time < timeout:
            try:
                response = requests.get(health_url, timeout=2)
                if response.status_code == 200:
                    print(f'✓ {service_name} is healthy')
                    return True
            except requests.exceptions.ConnectionError:
                print(f'  Waiting for {service_name} to start...')
                time.sleep(2)
            except Exception as e:
                print(f'  Health check error: {e}')
                time.sleep(2)

        print(f'✗ {service_name} health check failed (timeout)')
        return False

    def start_all(self) -> bool:
        """Start all services in order"""
        print('=' * 60)
        print('GearGuard Microservices Launcher')
        print('=' * 60)

        for service_name in self.startup_order:
            if not self.start_service(service_name):
                print(f'✗ Failed to start {service_name}, aborting startup')
                self.stop_all()
                return False

            # Wait for service to be healthy
            if not self.check_health(service_name):
                print(f'✗ {service_name} failed health check, aborting startup')
                self.stop_all()
                return False

            time.sleep(1)

        return True

    def stop_all(self):
        """Stop all running services"""
        print('\n\n🛑 Shutting down services...')

        for service_name in reversed(self.startup_order):
            if service_name in self.processes:
                process = self.processes[service_name]
                process.terminate()
                try:
                    process.wait(timeout=5)
                    print(f'✓ {service_name} stopped')
                except subprocess.TimeoutExpired:
                    process.kill()
                    print(f'✓ {service_name} killed')

    def display_summary(self):
        """Display startup summary"""
        print('\n' + '=' * 60)
        print('GearGuard Microservices Running Successfully!')
        print('=' * 60)

        print('\n📍 Service Endpoints:')
        for service_name in self.startup_order:
            if service_name in self.SERVICES:
                port = self.SERVICES[service_name]['port']
                print(f'  • {service_name:20s} http://localhost:{port}')

        print('\n🌐 Frontend:')
        print('  • Dashboard               http://localhost:8000')

        print('\n📊 Monitoring:')
        print('  • RabbitMQ UI             http://localhost:15672 (guest/guest)')
        print('  • EventStoreDB UI         http://localhost:2113')

        print('\n📖 Documentation:')
        print('  • Architecture Docs:      MICROSERVICES_ARCHITECTURE.md')

        print('\n✅ All services initialized and ready!')
        print('=' * 60)

    def monitor_services(self):
        """Monitor service processes"""
        try:
            while True:
                all_running = True
                for service_name, process in self.processes.items():
                    if process.poll() is not None:
                        print(f'⚠️  {service_name} has crashed!')
                        all_running = False

                if all_running:
                    time.sleep(5)
                else:
                    print('Some services have crashed. Use Ctrl+C to exit.')
                    time.sleep(1)
        except KeyboardInterrupt:
            print('\n\nShutting down...')
            self.stop_all()

def main():
    launcher = MicroservicesLauncher()

    try:
        # Start all services
        if launcher.start_all():
            launcher.display_summary()
            launcher.monitor_services()
        else:
            print('✗ Failed to start microservices')
            sys.exit(1)

    except KeyboardInterrupt:
        print('\n\nReceived interrupt signal')
        launcher.stop_all()
        sys.exit(0)

    except Exception as e:
        print(f'✗ Unexpected error: {e}')
        launcher.stop_all()
        sys.exit(1)

if __name__ == '__main__':
    main()
