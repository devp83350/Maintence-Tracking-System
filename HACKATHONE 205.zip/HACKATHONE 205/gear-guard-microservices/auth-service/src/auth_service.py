"""
Auth Service Microservice
Handles authentication, authorization, and team management
JWT token generation and validation
"""

from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse
import json
import uuid
from typing import Dict, List, Any
from datetime import datetime, timedelta
import hashlib
import sys
import os

# Add shared directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../')))

from shared.event_bus import get_event_bus

class AuthService:
    """Authentication and Team management service"""

    def __init__(self):
        self.users: Dict[str, Dict[str, Any]] = {}
        self.teams: Dict[str, Dict[str, Any]] = {}
        self.team_members: Dict[str, List[str]] = {}
        self.event_bus = get_event_bus()

    def create_user(self, username: str, password: str, role: str = 'technician') -> Dict:
        """Create new user"""
        user_id = str(uuid.uuid4())
        user = {
            'id': user_id,
            'username': username,
            'password_hash': self._hash_password(password),
            'role': role,
            'created_at': datetime.now().isoformat()
        }
        
        self.users[user_id] = user
        
        self.event_bus.publish('user.created', {
            'user_id': user_id,
            'username': username,
            'role': role
        })
        
        return {k: v for k, v in user.items() if k != 'password_hash'}

    def authenticate(self, username: str, password: str) -> Dict:
        """Authenticate user and return JWT token"""
        for user in self.users.values():
            if user['username'] == username and self._verify_password(password, user['password_hash']):
                token = self._generate_token(user['id'])
                
                self.event_bus.publish('user.authenticated', {
                    'user_id': user['id'],
                    'username': username,
                    'timestamp': datetime.now().isoformat()
                })
                
                return {
                    'token': token,
                    'user_id': user['id'],
                    'username': user['username'],
                    'role': user['role']
                }
        
        return None

    def create_team(self, name: str, specialization: str) -> Dict:
        """Create new team"""
        team_id = str(uuid.uuid4())
        team = {
            'id': team_id,
            'name': name,
            'specialization': specialization,
            'created_at': datetime.now().isoformat()
        }
        
        self.teams[team_id] = team
        self.team_members[team_id] = []
        
        self.event_bus.publish('team.created', {
            'team_id': team_id,
            'name': name,
            'specialization': specialization
        })
        
        return team

    def add_team_member(self, team_id: str, user_id: str, role: str = 'member') -> Dict:
        """Add member to team"""
        if team_id not in self.teams:
            return None
        
        if user_id not in self.users:
            return None
        
        if user_id not in self.team_members[team_id]:
            self.team_members[team_id].append(user_id)
        
        self.event_bus.publish('team.member_added', {
            'team_id': team_id,
            'user_id': user_id,
            'role': role
        })
        
        return {
            'team_id': team_id,
            'user_id': user_id,
            'role': role
        }

    def list_teams(self) -> List[Dict]:
        """List all teams with members"""
        teams = []
        for team_id, team in self.teams.items():
            team_data = team.copy()
            team_data['members'] = [
                self.users[uid] for uid in self.team_members[team_id]
                if uid in self.users
            ]
            teams.append(team_data)
        return teams

    def get_team(self, team_id: str) -> Dict:
        """Get team details"""
        if team_id not in self.teams:
            return None
        
        team = self.teams[team_id].copy()
        team['members'] = [
            self.users[uid] for uid in self.team_members[team_id]
            if uid in self.users
        ]
        return team

    def _hash_password(self, password: str) -> str:
        """Hash password"""
        return hashlib.sha256(password.encode()).hexdigest()

    def _verify_password(self, password: str, password_hash: str) -> bool:
        """Verify password"""
        return self._hash_password(password) == password_hash

    def _generate_token(self, user_id: str) -> str:
        """Generate JWT token"""
        # Simplified JWT (for production use PyJWT)
        header = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9'  # HS256
        payload = json.dumps({
            'sub': user_id,
            'iat': datetime.now().isoformat(),
            'exp': (datetime.now() + timedelta(hours=24)).isoformat()
        }).replace(' ', '')
        signature = hashlib.sha256(f'{header}.{payload}'.encode()).hexdigest()[:32]
        
        return f'{header}.{payload}.{signature}'

# Global service instance
auth_service = AuthService()

class AuthHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        path = urlparse(self.path).path
        
        try:
            if path == '/teams':
                teams = auth_service.list_teams()
                self.send_json_response(teams)
            elif path.startswith('/teams/'):
                team_id = path.split('/')[-1]
                team = auth_service.get_team(team_id)
                if team:
                    self.send_json_response(team)
                else:
                    self.send_json_response({'error': 'Team not found'}, 404)
            elif path == '/health':
                self.send_json_response({'status': 'healthy'})
            else:
                self.send_json_response({'error': 'Not found'}, 404)
        except Exception as e:
            self.send_json_response({'error': str(e)}, 500)

    def do_POST(self):
        path = urlparse(self.path).path
        content_length = int(self.headers.get('Content-Length', 0))
        body = json.loads(self.rfile.read(content_length).decode('utf-8'))

        try:
            if path == '/auth/login':
                result = auth_service.authenticate(
                    username=body.get('username'),
                    password=body.get('password')
                )
                if result:
                    self.send_json_response(result)
                else:
                    self.send_json_response({'error': 'Invalid credentials'}, 401)
            
            elif path == '/auth/register':
                user = auth_service.create_user(
                    username=body.get('username'),
                    password=body.get('password'),
                    role=body.get('role', 'technician')
                )
                self.send_json_response(user, 201)
            
            elif path == '/teams':
                team = auth_service.create_team(
                    name=body.get('name'),
                    specialization=body.get('specialization')
                )
                self.send_json_response(team, 201)
            
            elif path.startswith('/teams/') and '/members' in path:
                parts = path.split('/')
                team_id = parts[2]
                member = auth_service.add_team_member(
                    team_id=team_id,
                    user_id=body.get('user_id'),
                    role=body.get('role', 'member')
                )
                if member:
                    self.send_json_response(member, 201)
                else:
                    self.send_json_response({'error': 'Team or user not found'}, 404)
            
            else:
                self.send_json_response({'error': 'Not found'}, 404)
        except Exception as e:
            self.send_json_response({'error': str(e)}, 500)

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

    def send_json_response(self, data: Any, status_code: int = 200):
        self.send_response(status_code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(json.dumps(data).encode('utf-8'))

    def log_message(self, format, *args):
        print(f"[AUTH-SERVICE] {format % args}")

if __name__ == '__main__':
    PORT = 5001
    server = HTTPServer(('0.0.0.0', PORT), AuthHandler)
    print(f'✓ Auth Service running on http://localhost:{PORT}')
    print(f'✓ JWT token generation enabled')
    server.serve_forever()
