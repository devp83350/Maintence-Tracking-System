"""
Event Store Service
Persists all domain events for event sourcing
Provides event replay and audit trail
"""

from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse
import json
import sqlite3
from datetime import datetime
from typing import List, Dict, Any
import uuid

class EventStore:
    """In-memory event store (can be replaced with EventStoreDB)"""

    def __init__(self, db_path: str = ':memory:'):
        self.db_path = db_path
        self._init_db()

    def _init_db(self):
        """Initialize database schema"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS events (
                event_id TEXT PRIMARY KEY,
                event_type TEXT NOT NULL,
                aggregate_id TEXT NOT NULL,
                aggregate_type TEXT NOT NULL,
                data TEXT NOT NULL,
                version INTEGER NOT NULL,
                timestamp TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        cursor.execute('''
            CREATE INDEX IF NOT EXISTS idx_aggregate_id 
            ON events(aggregate_id)
        ''')
        
        cursor.execute('''
            CREATE INDEX IF NOT EXISTS idx_event_type 
            ON events(event_type)
        ''')
        
        conn.commit()
        conn.close()

    def append_event(self, event_id: str, event_type: str, aggregate_id: str,
                    aggregate_type: str, data: dict, version: int) -> bool:
        """Append event to store"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO events 
                (event_id, event_type, aggregate_id, aggregate_type, data, version, timestamp)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (
                event_id,
                event_type,
                aggregate_id,
                aggregate_type,
                json.dumps(data),
                version,
                datetime.now().isoformat()
            ))
            
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            print(f'✗ Error appending event: {e}')
            return False

    def get_events(self, aggregate_id: str) -> List[Dict[str, Any]]:
        """Get all events for an aggregate"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT event_id, event_type, data, version, timestamp
                FROM events
                WHERE aggregate_id = ?
                ORDER BY version ASC
            ''', (aggregate_id,))
            
            events = []
            for row in cursor.fetchall():
                events.append({
                    'event_id': row[0],
                    'event_type': row[1],
                    'data': json.loads(row[2]),
                    'version': row[3],
                    'timestamp': row[4]
                })
            
            conn.close()
            return events
        except Exception as e:
            print(f'✗ Error getting events: {e}')
            return []

    def get_all_events(self, event_type: str = None) -> List[Dict[str, Any]]:
        """Get all events, optionally filtered by type"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            if event_type:
                cursor.execute('''
                    SELECT event_id, event_type, aggregate_id, data, version, timestamp
                    FROM events
                    WHERE event_type = ?
                    ORDER BY created_at ASC
                ''', (event_type,))
            else:
                cursor.execute('''
                    SELECT event_id, event_type, aggregate_id, data, version, timestamp
                    FROM events
                    ORDER BY created_at ASC
                ''')
            
            events = []
            for row in cursor.fetchall():
                events.append({
                    'event_id': row[0],
                    'event_type': row[1],
                    'aggregate_id': row[2],
                    'data': json.loads(row[3]),
                    'version': row[4],
                    'timestamp': row[5]
                })
            
            conn.close()
            return events
        except Exception as e:
            print(f'✗ Error getting all events: {e}')
            return []

# Global event store
event_store = EventStore()

class EventStoreHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        path = urlparse(self.path).path
        
        try:
            if path == '/events':
                events = event_store.get_all_events()
                self.send_json_response(events)
            elif path.startswith('/events/'):
                aggregate_id = path.split('/')[-1]
                events = event_store.get_events(aggregate_id)
                self.send_json_response(events)
            elif path == '/health':
                self.send_json_response({'status': 'healthy'})
            else:
                self.send_json_response({'error': 'Not found'}, 404)
        except Exception as e:
            self.send_json_response({'error': str(e)}, 500)

    def do_POST(self):
        path = urlparse(self.path).path
        content_length = int(self.headers.get('Content-Length', 0))
        body = json.loads(self.rfile.read(content_length).decode('utf-8'))

        try:
            if path == '/events':
                event_id = str(uuid.uuid4())
                success = event_store.append_event(
                    event_id=event_id,
                    event_type=body.get('event_type'),
                    aggregate_id=body.get('aggregate_id'),
                    aggregate_type=body.get('aggregate_type'),
                    data=body.get('data', {}),
                    version=body.get('version', 1)
                )
                
                if success:
                    self.send_json_response({
                        'event_id': event_id,
                        'message': 'Event stored'
                    }, 201)
                else:
                    self.send_json_response({'error': 'Failed to store event'}, 500)
            else:
                self.send_json_response({'error': 'Not found'}, 404)
        except Exception as e:
            self.send_json_response({'error': str(e)}, 500)

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

    def send_json_response(self, data: Any, status_code: int = 200):
        self.send_response(status_code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(json.dumps(data).encode('utf-8'))

    def log_message(self, format, *args):
        print(f"[EVENT-STORE] {format % args}")

if __name__ == '__main__':
    PORT = 5005
    server = HTTPServer(('0.0.0.0', PORT), EventStoreHandler)
    print(f'✓ Event Store running on http://localhost:{PORT}')
    print(f'✓ Event Sourcing enabled')
    server.serve_forever()
