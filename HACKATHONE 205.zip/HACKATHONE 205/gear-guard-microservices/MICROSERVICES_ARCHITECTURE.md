# GearGuard Microservices Architecture

## Overview

GearGuard has been transformed from a monolithic architecture to a **distributed microservices system** with enterprise-grade patterns:

- **API Gateway**: Single entry point with request routing and load balancing
- **Microservices**: 4 independent services handling specific domains
- **Event-Driven**: Message broker for asynchronous communication
- **Event Sourcing**: Complete event history for audit trails
- **CQRS Pattern**: Separated command and query responsibilities
- **Saga Pattern**: Distributed transaction orchestration

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                           Frontend (Port 8000)                   │
│                    React/Vanilla JS Dashboard                    │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ↓
┌─────────────────────────────────────────────────────────────────┐
│                    API Gateway (Port 5000)                       │
│                   Request Routing & Load Balancing               │
│              Rate Limiting, Authentication, Logging              │
└──┬──────────────┬──────────────┬──────────────┬─────────────────┘
   │              │              │              │
   ↓              ↓              ↓              ↓
┌──────────┐ ┌──────────┐ ┌─────────────┐ ┌──────────────┐
│Auth Svc  │ │Equipment │ │Workflow Svc │ │Analytics Svc │
│(5001)    │ │Svc(5002) │ │ (5003)      │ │ (5004)       │
│          │ │          │ │             │ │              │
│JWT Tokens│ │CRUD Ops  │ │Saga Pattern │ │Read Models   │
│Teams     │ │Queries   │ │State Machine│ │Metrics       │
│Users     │ │Lifecycle │ │Distributed  │ │Performance   │
└──────────┘ └──────────┘ │Transactions │ │Analytics     │
                          └─────────────┘ └──────────────┘
                             │
                    ┌────────┴────────┐
                    │                 │
                    ↓                 ↓
            ┌──────────────┐   ┌─────────────────┐
            │RabbitMQ      │   │Event Store      │
            │Message Broker│   │(EventStoreDB)   │
            │(Port 5672)   │   │(Port 1113)      │
            │- Events      │   │- Event History  │
            │- Commands    │   │- Replay         │
            │- Pub/Sub     │   │- Audit Trail    │
            └──────────────┘   └─────────────────┘
```

## Microservices Details

### 1. API Gateway (Port 5000)

**Responsibilities**:
- Central entry point for all client requests
- Routes requests to appropriate microservices
- Implements rate limiting (100 requests/minute per client)
- Service health checks and circuit breaking
- Request/response transformation
- Cross-origin request handling (CORS)

**Endpoints**:
```
GET  /api/gateway/health        - Gateway health status + all services
GET  /api/auth/*                - Routes to Auth Service
GET  /api/equipment/*           - Routes to Equipment Service
POST /api/equipment/*           - Routes to Equipment Service
PUT  /api/equipment/*           - Routes to Equipment Service
DELETE /api/equipment/*         - Routes to Equipment Service
GET  /api/workflow/*            - Routes to Workflow Service
POST /api/workflow/*            - Routes to Workflow Service
GET  /api/analytics/*           - Routes to Analytics Service
```

**Features**:
- Transparent routing with header preservation
- Service discovery and health monitoring
- Rate limiting per client IP
- Request logging and metrics collection

### 2. Auth Service (Port 5001)

**Responsibilities**:
- User authentication and authorization
- JWT token generation and validation
- Team and technician management
- Role-based access control (RBAC)

**Endpoints**:
```
POST /auth/login                - User login (returns JWT token)
POST /auth/register             - User registration
GET  /teams                     - List all teams with members
GET  /teams/{teamId}            - Get team details
POST /teams                     - Create new team
POST /teams/{teamId}/members    - Add member to team
```

**Data Models**:
```
User:
  - id (UUID)
  - username (string)
  - password_hash (string)
  - role (string) - admin, supervisor, technician
  - created_at (timestamp)

Team:
  - id (UUID)
  - name (string)
  - specialization (string)
  - members (List[User])
  - created_at (timestamp)
```

**Events Published**:
- `user.created` - When new user is registered
- `user.authenticated` - When user logs in
- `team.created` - When new team is created
- `team.member_added` - When member joins team

### 3. Equipment Service (Port 5002)

**Responsibilities**:
- Equipment lifecycle management (CRUD)
- Equipment assignment to maintenance teams
- Equipment query and filtering
- Maintenance history tracking

**Endpoints**:
```
GET  /equipment                 - List all equipment
GET  /equipment/{equipmentId}   - Get equipment details
POST /equipment                 - Create new equipment
PUT  /equipment/{equipmentId}   - Update equipment
DELETE /equipment/{equipmentId} - Delete equipment
POST /equipment/{id}/assign     - Assign to team
```

**Data Models**:
```
Equipment:
  - id (UUID)
  - name (string)
  - serial_number (string)
  - department (string)
  - location (string)
  - default_team_id (UUID)
  - status (string) - active, in-repair, scrapped
  - created_at (timestamp)
  - updated_at (timestamp)
```

**Events Published**:
- `equipment.created` - When new equipment is added
- `equipment.updated` - When equipment is modified
- `equipment.assigned_to_team` - When equipment assigned to team
- `equipment.deleted` - When equipment is removed

### 4. Workflow Service (Port 5003)

**Responsibilities**:
- Maintenance request processing with state machine
- Saga pattern for distributed transactions
- Request lifecycle orchestration
- Technician assignment and scheduling

**Endpoints**:
```
GET  /requests                  - List all requests
GET  /requests/{requestId}      - Get request details
POST /requests                  - Create new request (Saga initiation)
PUT  /requests/{id}             - Update request status (Saga steps)
  Actions: assign, start, complete, cancel
```

**Request State Machine**:
```
┌────────┐
│PENDING │  (Request created)
└───┬────┘
    │ [assign action]
    ↓
┌────────────┐
│  ASSIGNED  │  (Team & technician assigned)
└───┬────────┘
    │ [start action]
    ↓
┌──────────────┐
│ IN_PROGRESS  │  (Work started)
└───┬──────────┘
    │ [complete or cancel action]
    ↓
┌────────────┬──────────┐
│ COMPLETED  │ CANCELLED│  (Final states)
└────────────┴──────────┘
```

**CQRS Pattern**:
- **Commands**: CreateRequest, AssignRequest, StartWork, CompleteRequest, CancelRequest
- **Queries**: GetRequest, ListRequestsByStatus, GetTeamWorkload

**Saga Pattern**:
```
Saga: CreateAndAssignMaintenanceRequest
  1. Create request (Workflow Service)
  2. Reserve technician (Auth Service) 
  3. Update equipment status (Equipment Service)
  4. Notify via event bus
  Compensation: 
    - Cancel request if any step fails
    - Release technician
    - Revert equipment status
```

**Data Models**:
```
MaintenanceRequest:
  - id (UUID)
  - subject (string)
  - description (string)
  - equipment_id (UUID)
  - request_type (string) - preventive, corrective, inspection
  - priority (string) - low, medium, high, urgent
  - status (enum) - pending, assigned, in_progress, completed, cancelled
  - assigned_team_id (UUID)
  - assigned_technician_id (UUID)
  - hours_spent (float)
  - completion_notes (string)
  - created_at (timestamp)
  - started_at (timestamp)
  - completed_at (timestamp)
```

**Events Published**:
- `request.created` - Saga initiator
- `request.assigned` - After team assignment
- `request.work_started` - When work begins
- `request.completed` - When work finished
- `request.cancelled` - When request cancelled

### 5. Analytics Service (Port 5004)

**Responsibilities**:
- Event-driven analytics and reporting
- Real-time metrics collection
- Performance dashboard data
- Team productivity metrics
- Equipment utilization analysis

**Endpoints**:
```
GET /dashboard                  - Main dashboard metrics
GET /team-performance           - Team performance analytics
GET /equipment-stats            - Equipment statistics
GET /metrics                    - Raw metrics data
```

**Read Models**:
```
DashboardMetrics:
  - total_requests
  - completed_requests
  - pending_requests
  - completion_rate
  - average_resolution_hours

TeamPerformance:
  - assigned_requests
  - completed_requests
  - average_resolution_time
  - performance_score

EquipmentStats:
  - maintenance_frequency
  - average_downtime
  - reliability_score
```

**Event Subscribers**:
- `request.created` - Increment metrics
- `request.completed` - Update completion stats and avg time
- `request.assigned` - Track team workload

## Communication Patterns

### Synchronous (HTTP REST)
- Frontend ↔ API Gateway
- API Gateway ↔ Microservices (internal)
- Service-to-service queries when needed

### Asynchronous (Message Broker)
- Services publish domain events to RabbitMQ
- Services subscribe to relevant events
- Event Bus handles pub/sub distribution
- Guarantees eventual consistency

### Event Store
- All domain events persisted in EventStoreDB
- Provides event replay capability
- Complete audit trail of all changes
- Enables temporal queries ("What was state at time T?")

## Event Flow Example: Creating Maintenance Request

```
1. Frontend: POST /api/workflow/requests
   │
   ├─→ API Gateway receives request
   │   └─→ Validates format and rate limit
   │       └─→ Routes to Workflow Service
   │
   ├─→ Workflow Service processes command
   │   ├─→ Create request in memory
   │   ├─→ Publish "request.created" event to RabbitMQ
   │   └─→ Return request details (HTTP 201)
   │
   ├─→ RabbitMQ distributes event
   │   ├─→ Event Store: Persist event
   │   ├─→ Analytics: Increment metrics
   │   └─→ Workflow: Trigger Saga (assign technician)
   │
   ├─→ Analytics Service updates read model
   │   ├─→ Increment pending_requests
   │   ├─→ Increment total_requests
   │   └─→ Broadcast updated metrics
   │
   └─→ Eventual consistency: All services synchronized via events
```

## Data Consistency Strategy

**Saga Pattern for Distributed Transactions**:

```
Request: Create + Assign Maintenance Work

SUCCESS PATH:
  1. CreateRequest (Workflow Service) ✓
  2. ReserveTechnician (Auth Service) ✓
  3. UpdateEquipmentStatus (Equipment Service) ✓
  4. CommitSaga ✓

FAILURE PATH (e.g., step 3 fails):
  1. CreateRequest (Workflow Service) ✓
  2. ReserveTechnician (Auth Service) ✓
  3. UpdateEquipmentStatus FAILED ✗
  
  COMPENSATION:
  3. ReleaseTechnician (Auth Service) - UNDO
  2. DeleteRequest (Workflow Service) - UNDO
```

## Technology Stack

| Component | Technology | Port | Purpose |
|-----------|-----------|------|---------|
| API Gateway | Python HTTP | 5000 | Request routing & load balancing |
| Auth Service | Python HTTP | 5001 | Authentication & authorization |
| Equipment Service | Python HTTP | 5002 | Equipment CRUD & lifecycle |
| Workflow Service | Python HTTP | 5003 | Maintenance request orchestration |
| Analytics Service | Python HTTP | 5004 | Real-time metrics & reporting |
| Message Broker | RabbitMQ | 5672 | Event distribution |
| Event Store | EventStoreDB | 1113 | Event sourcing & audit trail |
| Frontend | HTML/CSS/JS | 8000 | User interface |

## Deployment

### Docker Compose

```bash
docker-compose up --build
```

This starts:
- All 4 microservices with health checks
- RabbitMQ with management UI (port 15672)
- EventStoreDB with UI (port 2113)
- Frontend server
- All networks and volumes configured

### Service Dependencies

```
Startup order (defined in docker-compose.yml):
1. RabbitMQ (message broker foundation)
2. EventStoreDB (event store foundation)
3. Auth Service (depends on RabbitMQ)
4. Equipment Service (depends on RabbitMQ)
5. Workflow Service (depends on RabbitMQ + EventStoreDB)
6. Analytics Service (depends on RabbitMQ)
7. API Gateway (depends on all services)
8. Frontend (independent)
```

## API Gateway URLs

After docker-compose up:

```
Frontend:           http://localhost:8000
API Gateway:        http://localhost:5000
Auth Service:       http://localhost:5001
Equipment Service:  http://localhost:5002
Workflow Service:   http://localhost:5003
Analytics Service:  http://localhost:5004
RabbitMQ UI:        http://localhost:15672 (guest/guest)
EventStoreDB UI:    http://localhost:2113
```

## Usage Examples

### Authentication

```bash
# Register user
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"username":"john","password":"pass123","role":"technician"}'

# Login
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"john","password":"pass123"}'
```

### Equipment Management

```bash
# Create equipment
curl -X POST http://localhost:5000/api/equipment \
  -H "Content-Type: application/json" \
  -d '{"name":"Pump A","serial_number":"PA-001","department":"Manufacturing","location":"Floor 1"}'

# List equipment
curl http://localhost:5000/api/equipment

# Get equipment
curl http://localhost:5000/api/equipment/{id}

# Update equipment
curl -X PUT http://localhost:5000/api/equipment/{id} \
  -H "Content-Type: application/json" \
  -d '{"location":"Floor 2"}'
```

### Maintenance Workflow

```bash
# Create request
curl -X POST http://localhost:5000/api/workflow/requests \
  -H "Content-Type: application/json" \
  -d '{
    "subject":"Pump maintenance",
    "description":"Routine maintenance",
    "equipment_id":"xxx",
    "request_type":"preventive",
    "priority":"medium"
  }'

# Assign request
curl -X PUT http://localhost:5000/api/workflow/requests/{id} \
  -H "Content-Type: application/json" \
  -d '{"action":"assign","team_id":"yyy","technician_id":"zzz"}'

# Start work
curl -X PUT http://localhost:5000/api/workflow/requests/{id} \
  -H "Content-Type: application/json" \
  -d '{"action":"start"}'

# Complete request
curl -X PUT http://localhost:5000/api/workflow/requests/{id} \
  -H "Content-Type: application/json" \
  -d '{"action":"complete","hours_spent":2.5,"completion_notes":"Maintenance completed successfully"}'
```

### Analytics & Reporting

```bash
# Dashboard metrics
curl http://localhost:5000/api/analytics/dashboard

# Team performance
curl http://localhost:5000/api/analytics/team-performance

# Equipment stats
curl http://localhost:5000/api/analytics/equipment-stats
```

## Monitoring

### Health Checks

```bash
# Check all services via gateway
curl http://localhost:5000/api/gateway/health

# Example response:
{
  "status": "healthy",
  "services": {
    "auth": "online",
    "equipment": "online",
    "workflow": "online",
    "analytics": "online"
  }
}
```

### RabbitMQ Management

Access http://localhost:15672 (credentials: guest/guest)
- View exchanges (gear-guard exchange)
- Monitor queues and messages
- Track published events in real-time

### EventStoreDB

Access http://localhost:2113
- Browse event stream
- Replay events
- View projections
- Complete audit trail

## Key Patterns Implemented

### 1. **CQRS (Command Query Responsibility Segregation)**
- Commands: CreateRequest, AssignRequest, CompleteRequest
- Queries: GetRequest, ListRequests, GetMetrics
- Separated write (command) and read (query) models
- Analytics Service maintains read model

### 2. **Event Sourcing**
- All state changes recorded as domain events
- EventStoreDB persists complete event history
- Services can rebuild state by replaying events
- Complete audit trail and temporal queries enabled

### 3. **Saga Pattern**
- Distributed transaction for CreateAndAssignRequest
- Coordinates multiple services as single logical transaction
- Compensation transactions for failure handling
- Ensures data consistency across services

### 4. **API Gateway Pattern**
- Single entry point for all clients
- Handles cross-cutting concerns:
  - Request routing
  - Load balancing
  - Rate limiting
  - Authentication/Authorization
  - Request logging
- Simplifies client code

### 5. **Event-Driven Architecture**
- Services communicate via published events
- Loose coupling through message broker
- Asynchronous processing
- Enables service autonomy and scalability

### 6. **Service Autonomy**
- Each service owns its data
- Independent deployment
- Isolated technology choices
- Async communication reduces coupling

## Scalability Considerations

### Horizontal Scaling

```bash
# Scale Equipment Service to 3 instances
docker-compose up --scale equipment-service=3
```

### Load Balancing
- API Gateway distributes requests via service discovery
- RabbitMQ enables multiple instances subscribing to events
- Each event processed by single consumer (competing consumers pattern)

### Future Improvements
- Implement circuit breakers for service failures
- Add request caching layer (Redis)
- Implement distributed tracing (Jaeger)
- Add metrics collection (Prometheus + Grafana)
- Enable service mesh (Istio) for advanced traffic management

## Transitioning from Monolith

### Original Monolithic Stack
- Single Python HTTP server (port 5000)
- In-memory data storage
- No event history
- Tightly coupled components

### New Microservices Stack
- 4 independent services + API Gateway + Event Store
- Distributed event-driven communication
- Complete event sourcing and audit trail
- Loosely coupled through events
- Horizontally scalable
- Event replay and temporal queries
- CQRS separation for independent scaling

### Data Migration
Original monolith data can be replayed as events:
1. Export equipment as `equipment.created` events
2. Export users as `user.created` events
3. Export requests as `request.created` events + status transitions
4. Replay all events through EventStore
5. Services rebuild their state from event history

## Development Guidelines

### Adding New Feature

1. **Define Domain Events** in `shared/events/domain_events.py`
2. **Choose Service Owner** (which service handles this domain)
3. **Implement Commands** in owning service
4. **Publish Events** when state changes
5. **Subscribe to Events** in other services if needed
6. **Add Tests** for command handlers and event handlers
7. **Update API Gateway** routing if new endpoints
8. **Document Events** and their usage

### Service Template

```python
from event_bus import get_event_bus

class MyService:
    def __init__(self):
        self.event_bus = get_event_bus()
    
    def execute_command(self, data):
        # 1. Validate
        # 2. Execute business logic
        # 3. Persist state
        # 4. Publish event
        self.event_bus.publish('domain.event_type', data)
        return result
```

## Troubleshooting

### Service Not Responding
```bash
# Check service health
curl http://localhost:5000/api/gateway/health

# Check RabbitMQ
curl http://localhost:15672 (guest/guest)

# Check EventStoreDB
curl http://localhost:2113
```

### Events Not Flowing
```bash
# Check RabbitMQ management UI
# Navigate to: http://localhost:15672
# View "Exchanges" tab for "gear-guard" exchange
# Check "Queues" for messages
```

### Service Discovery
- Services configured with hardcoded ports (5001-5004)
- API Gateway has service registry (SERVICES dict)
- Update gateway.py if service URLs change

## References

- **Event Sourcing**: https://martinfowler.com/eaaDev/EventSourcing.html
- **CQRS**: https://martinfowler.com/bliki/CQRS.html
- **Saga Pattern**: https://microservices.io/patterns/data/saga.html
- **Microservices**: https://microservices.io/
- **RabbitMQ**: https://www.rabbitmq.com/
- **EventStoreDB**: https://www.eventstore.com/
