# GearGuard Microservices - Quick Start Guide

## 🚀 Getting Started

### Prerequisites

- Python 3.11+
- Docker & Docker Compose (optional, for full infrastructure)
- pip packages: `requests`, `pika`

### Option 1: Local Python Services (Recommended for Development)

```bash
# Install dependencies
pip install requests pika

# From the gear-guard-microservices directory, run:
python launcher.py
```

This starts all services with:
- ✅ Proper initialization order
- ✅ Health checks for each service
- ✅ Service monitoring
- ✅ Graceful shutdown (Ctrl+C)

### Option 2: Docker Compose (Recommended for Production)

```bash
# Requires Docker and Docker Compose

# Build and start all services + infrastructure
docker-compose up --build

# View logs
docker-compose logs -f

# Stop all services
docker-compose down
```

## 📍 Service Locations

Once started, access services at:

```
API Gateway:         http://localhost:5000
├─ Auth Service:     http://localhost:5001
├─ Equipment Svc:    http://localhost:5002
├─ Workflow Svc:     http://localhost:5003
└─ Analytics Svc:    http://localhost:5004

Event Store:         http://localhost:5005
Frontend:            http://localhost:8000
RabbitMQ (Docker):   http://localhost:5672
RabbitMQ UI (Docker):http://localhost:15672
```

## 🧪 Quick Test

### 1. Check Gateway Health

```bash
curl http://localhost:5000/api/gateway/health
```

Expected response:
```json
{
  "status": "healthy",
  "services": {
    "auth": "online",
    "equipment": "online",
    "workflow": "online",
    "analytics": "online"
  }
}
```

### 2. Create Equipment

```bash
curl -X POST http://localhost:5000/api/equipment \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Hydraulic Press",
    "serial_number": "HP-001",
    "department": "Manufacturing",
    "location": "Floor 1"
  }'
```

### 3. Create Maintenance Request

```bash
curl -X POST http://localhost:5000/api/workflow/requests \
  -H "Content-Type: application/json" \
  -d '{
    "subject": "Hydraulic Press Maintenance",
    "description": "Routine maintenance required",
    "equipment_id": "<equipment-id-from-step-2>",
    "request_type": "preventive",
    "priority": "medium"
  }'
```

### 4. View Dashboard

```bash
curl http://localhost:5000/api/analytics/dashboard
```

### 5. Open Frontend

```
http://localhost:8000
```

## 📁 Project Structure

```
gear-guard-microservices/
├── api-gateway/                  # Request routing & load balancing
│   ├── gateway.py
│   └── Dockerfile
├── auth-service/                 # Authentication & Teams
│   ├── src/
│   │   └── auth_service.py
│   └── Dockerfile
├── equipment-service/            # Equipment CRUD & lifecycle
│   ├── src/
│   │   └── equipment_service.py
│   └── Dockerfile
├── workflow-service/             # Maintenance workflows & Saga
│   ├── src/
│   │   └── workflow_service.py
│   └── Dockerfile
├── analytics-service/            # Metrics & reporting
│   ├── src/
│   │   └── analytics_service.py
│   └── Dockerfile
├── event-store/                  # Event sourcing
│   └── event_store.py
├── shared/                       # Shared code
│   ├── events/
│   │   └── domain_events.py
│   ├── event_bus.py
│   └── commands/
├── frontend/                     # UI (from monolith)
│   ├── index.html
│   ├── styles/
│   ├── scripts/
│   └── images/
├── docker-compose.yml            # Complete infrastructure
├── launcher.py                   # Python launcher script
├── MICROSERVICES_ARCHITECTURE.md # Full architecture docs
└── README.md                     # This file
```

## 🔄 Microservices Communication

```
                Frontend (8000)
                     │
                     ↓
              API Gateway (5000)
             /        |        \       \
            /         |         \       \
    Auth (5001)  Equipment    Workflow  Analytics
               (5002)        (5003)     (5004)
                     │         │
                     └────┬────┘
                          ↓
                 Event Bus (RabbitMQ)
                          ↓
                    Event Store
```

## ⚙️ Configuration

### Service Ports
Edit in `launcher.py` or `docker-compose.yml`:
- API Gateway: 5000
- Auth Service: 5001
- Equipment Service: 5002
- Workflow Service: 5003
- Analytics Service: 5004
- Event Store: 5005

### RabbitMQ Connection
Default: `localhost:5672`
In production, update in `shared/event_bus.py`:
```python
event_bus = get_event_bus(host='your-rabbitmq-host')
```

## 🐛 Troubleshooting

### Services Not Starting

```bash
# Check Python version
python --version  # Should be 3.11+

# Check dependencies
pip install requests pika

# Check port availability
# Windows: netstat -ano | findstr :5000
# Linux/Mac: lsof -i :5000
```

### Gateway Showing Services Offline

```bash
# Verify each service individually
curl http://localhost:5001/health  # Auth
curl http://localhost:5002/health  # Equipment
curl http://localhost:5003/health  # Workflow
curl http://localhost:5004/health  # Analytics
```

### Events Not Processing

1. Check RabbitMQ is running (if using Docker)
2. Verify event_bus.py has correct RabbitMQ host
3. Check service logs for connection errors
4. Restart services

### Docker Issues

```bash
# Remove old containers
docker-compose down -v

# Rebuild from scratch
docker-compose build --no-cache
docker-compose up
```

## 📊 Monitoring

### Application Logs
- All services log to console
- Launcher shows startup sequence
- Monitor for service crashes

### Health Status
```bash
# Via API Gateway
curl http://localhost:5000/api/gateway/health

# Per service
curl http://localhost:500X/health  # where X = 1,2,3,4,5
```

### Database/Event Store
When using Docker:
- RabbitMQ: http://localhost:15672 (guest/guest)
- EventStoreDB: http://localhost:2113

## 🚀 Performance Tips

### Local Development
- Use `launcher.py` for faster startup
- Services run in foreground (see logs immediately)
- Easy to kill and restart individual services

### Production
- Use `docker-compose` for isolation
- Services run in background containers
- Volume persistence for RabbitMQ and EventStore
- Health checks with automatic restart

### Scaling
```bash
# Scale Equipment Service to 3 instances (Docker)
docker-compose up --scale equipment-service=3
```

## 📖 Documentation

- **Full Architecture**: See `MICROSERVICES_ARCHITECTURE.md`
- **API Endpoints**: See service documentation
- **Event Models**: See `shared/events/domain_events.py`
- **Original Monolith**: See `../gear-guard-maintenance/README.md`

## 🎯 Next Steps

1. ✅ Start microservices
2. ✅ Test API endpoints
3. ✅ Explore dashboard
4. ✅ Read architecture docs
5. Implement custom features
6. Add authentication to frontend
7. Deploy to cloud (Azure, AWS, GCP)

## 💡 Key Concepts

**Microservices**: Independent services handling specific domains
**API Gateway**: Single entry point routing to services
**Event Sourcing**: Storing state changes as events
**CQRS**: Separating read and write responsibilities
**Saga Pattern**: Distributed transaction orchestration
**Event Bus**: RabbitMQ distributes events between services

## 🔗 Resources

- [Microservices.io](https://microservices.io/)
- [Event Sourcing](https://martinfowler.com/eaaDev/EventSourcing.html)
- [CQRS Pattern](https://martinfowler.com/bliki/CQRS.html)
- [RabbitMQ Docs](https://www.rabbitmq.com/)
- [EventStoreDB Docs](https://www.eventstore.com/)

---

**Questions?** Check `MICROSERVICES_ARCHITECTURE.md` for detailed documentation.
