"""
GearGuard Shared Module
Contains shared events, event bus, and common utilities
"""

from .event_bus import get_event_bus, EventBus

__all__ = ['get_event_bus', 'EventBus']
