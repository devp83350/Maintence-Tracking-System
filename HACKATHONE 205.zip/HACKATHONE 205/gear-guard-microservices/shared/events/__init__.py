"""
GearGuard Domain Events
All domain events for event sourcing
"""

from .domain_events import (
    DomainEvent,
    EquipmentCreatedEvent,
    EquipmentUpdatedEvent,
    EquipmentAssignedToTeamEvent,
    EquipmentScrapppedEvent,
    MaintenanceRequestCreatedEvent,
    MaintenanceRequestAssignedEvent,
    MaintenanceRequestStatusChangedEvent,
    MaintenanceRequestCompletedEvent,
    TeamCreatedEvent,
    TeamMemberAddedEvent,
    UserAuthenticatedEvent,
    RequestMetricsUpdatedEvent,
    TeamPerformanceUpdatedEvent,
)

__all__ = [
    'DomainEvent',
    'EquipmentCreatedEvent',
    'EquipmentUpdatedEvent',
    'EquipmentAssignedToTeamEvent',
    'EquipmentScrapppedEvent',
    'MaintenanceRequestCreatedEvent',
    'MaintenanceRequestAssignedEvent',
    'MaintenanceRequestStatusChangedEvent',
    'MaintenanceRequestCompletedEvent',
    'TeamCreatedEvent',
    'TeamMemberAddedEvent',
    'UserAuthenticatedEvent',
    'RequestMetricsUpdatedEvent',
    'TeamPerformanceUpdatedEvent',
]
