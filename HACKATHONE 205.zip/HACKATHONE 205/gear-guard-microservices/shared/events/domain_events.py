"""
Shared Domain Events for Event Sourcing
Published when domain changes occur
"""

from datetime import datetime
from typing import Any, Dict
import json
from dataclasses import dataclass, asdict

@dataclass
class DomainEvent:
    """Base class for all domain events"""
    event_id: str
    event_type: str
    aggregate_id: str
    timestamp: str
    version: int
    data: Dict[str, Any]

    def to_dict(self):
        return asdict(self)

    def to_json(self):
        return json.dumps(self.to_dict())

# Equipment Service Events
@dataclass
class EquipmentCreatedEvent(DomainEvent):
    """Fired when new equipment is created"""
    pass

@dataclass
class EquipmentUpdatedEvent(DomainEvent):
    """Fired when equipment is updated"""
    pass

@dataclass
class EquipmentAssignedToTeamEvent(DomainEvent):
    """Fired when equipment is assigned to maintenance team"""
    pass

@dataclass
class EquipmentScrapppedEvent(DomainEvent):
    """Fired when equipment is marked as scrapped"""
    pass

# Workflow Service Events
@dataclass
class MaintenanceRequestCreatedEvent(DomainEvent):
    """Fired when maintenance request is created"""
    pass

@dataclass
class MaintenanceRequestAssignedEvent(DomainEvent):
    """Fired when request is assigned to technician"""
    pass

@dataclass
class MaintenanceRequestStatusChangedEvent(DomainEvent):
    """Fired when request status changes"""
    pass

@dataclass
class MaintenanceRequestCompletedEvent(DomainEvent):
    """Fired when maintenance work is completed"""
    pass

# Team/Auth Service Events
@dataclass
class TeamCreatedEvent(DomainEvent):
    """Fired when team is created"""
    pass

@dataclass
class TeamMemberAddedEvent(DomainEvent):
    """Fired when member joins team"""
    pass

@dataclass
class UserAuthenticatedEvent(DomainEvent):
    """Fired when user is authenticated"""
    pass

# Analytics Events
@dataclass
class RequestMetricsUpdatedEvent(DomainEvent):
    """Fired when request metrics are updated"""
    pass

@dataclass
class TeamPerformanceUpdatedEvent(DomainEvent):
    """Fired when team performance is calculated"""
    pass
