"""
Message Bus for Event Publishing
Handles event distribution across microservices
"""

import json
import threading
from typing import Callable, Dict, List
from datetime import datetime

try:
    import pika
    PIKA_AVAILABLE = True
except ImportError:
    PIKA_AVAILABLE = False
    print("Warning: pika not installed. RabbitMQ features will be limited.")

class EventBus:
    """Message bus using RabbitMQ for event distribution"""

    def __init__(self, host: str = 'localhost', exchange: str = 'gear-guard'):
        self.host = host
        self.exchange = exchange
        self.connection = None
        self.channel = None
        self.subscribers: Dict[str, List[Callable]] = {}
        self._connect()

    def _connect(self):
        """Establish RabbitMQ connection"""
        if not PIKA_AVAILABLE:
            print(f'⚠️  RabbitMQ not available (pika not installed)')
            print(f'⚠️  Install with: pip install pika')
            print(f'⚠️  Events will be logged but not published')
            return
        
        try:
            self.connection = pika.BlockingConnection(
                pika.ConnectionParameters(self.host)
            )
            self.channel = self.connection.channel()
            self.channel.exchange_declare(
                exchange=self.exchange,
                exchange_type='topic',
                durable=True
            )
            print(f'✓ Connected to RabbitMQ at {self.host}')
        except Exception as e:
            print(f'⚠️  Failed to connect to RabbitMQ: {e}')
            print(f'⚠️  Running in degraded mode (no message broker)')

    def publish(self, event_type: str, data: dict):
        """Publish event to message bus"""
        if not PIKA_AVAILABLE or self.channel is None:
            print(f'✓ Event published (local): {event_type}')
            return
        
        try:
            message = {
                'event_type': event_type,
                'data': data,
                'timestamp': datetime.now().isoformat()
            }
            self.channel.basic_publish(
                exchange=self.exchange,
                routing_key=event_type,
                body=json.dumps(message),
                properties=pika.BasicProperties(
                    delivery_mode=2  # Make message persistent
                )
            )
            print(f'✓ Published event: {event_type}')
        except Exception as e:
            print(f'⚠️  Failed to publish event: {e}')

    def subscribe(self, event_type: str, callback: Callable):
        """Subscribe to event type"""
        if event_type not in self.subscribers:
            self.subscribers[event_type] = []
        self.subscribers[event_type].append(callback)

    def consume(self):
        """Start consuming events"""
        if not PIKA_AVAILABLE or self.channel is None:
            print(f'⚠️  Event consuming disabled (RabbitMQ not available)')
            return
        
        try:
            queue_name = self.channel.queue_declare(queue='', exclusive=True).method.queue
            
            # Bind to all subscribed events
            for event_type in self.subscribers:
                self.channel.queue_bind(
                    exchange=self.exchange,
                    queue=queue_name,
                    routing_key=event_type
                )

            def callback(ch, method, properties, body):
                try:
                    event = json.loads(body)
                    event_type = event['event_type']
                    
                    # Call all callbacks for this event
                    if event_type in self.subscribers:
                        for callback_fn in self.subscribers[event_type]:
                            callback_fn(event['data'])
                    
                    ch.basic_ack(delivery_tag=method.delivery_tag)
                except Exception as e:
                    print(f'⚠️  Error processing event: {e}')
                    ch.basic_nack(delivery_tag=method.delivery_tag)

            self.channel.basic_consume(queue=queue_name, on_message_callback=callback)
            print(f'✓ Consuming events from {queue_name}')
            self.channel.start_consuming()
        except Exception as e:
            print(f'⚠️  Failed to consume events: {e}')

    def close(self):
        """Close connection"""
        if self.connection and not self.connection.is_closed:
            self.connection.close()

# Global event bus instance
event_bus = None

def get_event_bus(host: str = 'localhost') -> EventBus:
    """Get or create global event bus"""
    global event_bus
    if event_bus is None:
        event_bus = EventBus(host)
    return event_bus
