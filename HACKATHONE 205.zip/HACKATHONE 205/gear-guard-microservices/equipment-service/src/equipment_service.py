"""
Equipment Service Microservice
Handles equipment CRUD operations and lifecycle
Event-driven with CQRS pattern
"""

from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
import json
import uuid
from typing import Dict, List, Any
import sys
import os

# Add shared directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../')))

from shared.event_bus import get_event_bus

class EquipmentService:
    """Equipment domain service"""

    def __init__(self):
        self.equipment: Dict[str, Dict[str, Any]] = {}
        self.event_bus = get_event_bus()

    def create_equipment(self, name: str, serial_number: str, department: str,
                        location: str, default_team_id: str = None) -> Dict:
        """Create new equipment"""
        equipment_id = str(uuid.uuid4())
        equipment = {
            'id': equipment_id,
            'name': name,
            'serial_number': serial_number,
            'department': department,
            'location': location,
            'default_team_id': default_team_id,
            'status': 'active',
            'created_at': None,
            'updated_at': None
        }
        
        self.equipment[equipment_id] = equipment
        
        # Publish event
        self.event_bus.publish('equipment.created', {
            'equipment_id': equipment_id,
            'name': name,
            'serial_number': serial_number
        })
        
        return equipment

    def get_equipment(self, equipment_id: str) -> Dict:
        """Get equipment by ID"""
        return self.equipment.get(equipment_id)

    def list_equipment(self) -> List[Dict]:
        """List all equipment"""
        return list(self.equipment.values())

    def update_equipment(self, equipment_id: str, data: Dict) -> Dict:
        """Update equipment"""
        if equipment_id not in self.equipment:
            return None
        
        self.equipment[equipment_id].update(data)
        
        # Publish event
        self.event_bus.publish('equipment.updated', {
            'equipment_id': equipment_id,
            'data': data
        })
        
        return self.equipment[equipment_id]

    def delete_equipment(self, equipment_id: str) -> bool:
        """Delete equipment"""
        if equipment_id in self.equipment:
            del self.equipment[equipment_id]
            
            # Publish event
            self.event_bus.publish('equipment.deleted', {
                'equipment_id': equipment_id
            })
            
            return True
        return False

    def assign_team(self, equipment_id: str, team_id: str) -> Dict:
        """Assign equipment to maintenance team"""
        if equipment_id not in self.equipment:
            return None
        
        self.equipment[equipment_id]['default_team_id'] = team_id
        
        # Publish event
        self.event_bus.publish('equipment.assigned_to_team', {
            'equipment_id': equipment_id,
            'team_id': team_id
        })
        
        return self.equipment[equipment_id]

# Global service instance
equipment_service = EquipmentService()

class EquipmentHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        path = urlparse(self.path).path
        
        try:
            if path == '/equipment':
                equipment_list = equipment_service.list_equipment()
                self.send_json_response(equipment_list)
            elif path.startswith('/equipment/'):
                equipment_id = path.split('/')[-1]
                equipment = equipment_service.get_equipment(equipment_id)
                if equipment:
                    self.send_json_response(equipment)
                else:
                    self.send_json_response({'error': 'Equipment not found'}, 404)
            elif path == '/health':
                self.send_json_response({'status': 'healthy'})
            else:
                self.send_json_response({'error': 'Not found'}, 404)
        except Exception as e:
            self.send_json_response({'error': str(e)}, 500)

    def do_POST(self):
        path = urlparse(self.path).path
        content_length = int(self.headers.get('Content-Length', 0))
        body = json.loads(self.rfile.read(content_length).decode('utf-8'))

        try:
            if path == '/equipment':
                equipment = equipment_service.create_equipment(
                    name=body.get('name'),
                    serial_number=body.get('serial_number'),
                    department=body.get('department'),
                    location=body.get('location'),
                    default_team_id=body.get('default_team_id')
                )
                self.send_json_response(equipment, 201)
            else:
                self.send_json_response({'error': 'Not found'}, 404)
        except Exception as e:
            self.send_json_response({'error': str(e)}, 500)

    def do_PUT(self):
        path = urlparse(self.path).path
        content_length = int(self.headers.get('Content-Length', 0))
        body = json.loads(self.rfile.read(content_length).decode('utf-8'))

        try:
            if path.startswith('/equipment/'):
                equipment_id = path.split('/')[-1]
                updated = equipment_service.update_equipment(equipment_id, body)
                if updated:
                    self.send_json_response(updated)
                else:
                    self.send_json_response({'error': 'Equipment not found'}, 404)
            else:
                self.send_json_response({'error': 'Not found'}, 404)
        except Exception as e:
            self.send_json_response({'error': str(e)}, 500)

    def do_DELETE(self):
        path = urlparse(self.path).path

        try:
            if path.startswith('/equipment/'):
                equipment_id = path.split('/')[-1]
                if equipment_service.delete_equipment(equipment_id):
                    self.send_json_response({'message': 'Equipment deleted'})
                else:
                    self.send_json_response({'error': 'Equipment not found'}, 404)
            else:
                self.send_json_response({'error': 'Not found'}, 404)
        except Exception as e:
            self.send_json_response({'error': str(e)}, 500)

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

    def send_json_response(self, data: Any, status_code: int = 200):
        self.send_response(status_code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(json.dumps(data).encode('utf-8'))

    def log_message(self, format, *args):
        print(f"[EQUIPMENT-SERVICE] {format % args}")

if __name__ == '__main__':
    PORT = 5002
    server = HTTPServer(('0.0.0.0', PORT), EquipmentHandler)
    print(f'✓ Equipment Service running on http://localhost:{PORT}')
    print(f'✓ Microservice initialized')
    server.serve_forever()
