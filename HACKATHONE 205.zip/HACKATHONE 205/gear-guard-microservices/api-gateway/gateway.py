"""
GearGuard Microservices - API Gateway
Routes requests to appropriate microservices
Implements load balancing and rate limiting
"""

from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
import json
import time
from typing import Dict, Any
import requests

# Service Registry
SERVICES = {
    'auth': 'http://localhost:5001',
    'equipment': 'http://localhost:5002',
    'workflow': 'http://localhost:5003',
    'analytics': 'http://localhost:5004'
}

# Rate limiting store
rate_limit_store: Dict[str, list] = {}
RATE_LIMIT = 100  # requests per minute

class APIGateway(BaseHTTPRequestHandler):
    def do_GET(self):
        path = urlparse(self.path).path
        
        try:
            # Route to appropriate service
            if path.startswith('/api/auth'):
                self.proxy_request('auth', path, 'GET')
            elif path.startswith('/api/equipment'):
                self.proxy_request('equipment', path, 'GET')
            elif path.startswith('/api/workflow'):
                self.proxy_request('workflow', path, 'GET')
            elif path.startswith('/api/analytics'):
                self.proxy_request('analytics', path, 'GET')
            elif path == '/api/gateway/health':
                self.send_json_response({
                    'status': 'healthy',
                    'services': self._check_services()
                })
            else:
                self.send_json_response({'error': 'Not found'}, 404)
        except Exception as e:
            self.send_json_response({'error': str(e)}, 500)

    def do_POST(self):
        path = urlparse(self.path).path
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length)

        try:
            if path.startswith('/api/auth'):
                self.proxy_request('auth', path, 'POST', body)
            elif path.startswith('/api/equipment'):
                self.proxy_request('equipment', path, 'POST', body)
            elif path.startswith('/api/workflow'):
                self.proxy_request('workflow', path, 'POST', body)
            elif path.startswith('/api/analytics'):
                self.proxy_request('analytics', path, 'POST', body)
            else:
                self.send_json_response({'error': 'Not found'}, 404)
        except Exception as e:
            self.send_json_response({'error': str(e)}, 500)

    def do_PUT(self):
        path = urlparse(self.path).path
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length)

        try:
            if path.startswith('/api/equipment'):
                self.proxy_request('equipment', path, 'PUT', body)
            elif path.startswith('/api/workflow'):
                self.proxy_request('workflow', path, 'PUT', body)
            else:
                self.send_json_response({'error': 'Not found'}, 404)
        except Exception as e:
            self.send_json_response({'error': str(e)}, 500)

    def do_DELETE(self):
        path = urlparse(self.path).path

        try:
            if path.startswith('/api/equipment'):
                self.proxy_request('equipment', path, 'DELETE')
            elif path.startswith('/api/workflow'):
                self.proxy_request('workflow', path, 'DELETE')
            else:
                self.send_json_response({'error': 'Not found'}, 404)
        except Exception as e:
            self.send_json_response({'error': str(e)}, 500)

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization')
        self.end_headers()

    def proxy_request(self, service: str, path: str, method: str, body: bytes = None):
        # Check rate limiting
        if not self._check_rate_limit():
            self.send_json_response({'error': 'Rate limit exceeded'}, 429)
            return

        service_url = SERVICES.get(service)
        if not service_url:
            self.send_json_response({'error': f'Service {service} not found'}, 404)
            return

        try:
            # Remove /api/{service} prefix from path
            clean_path = path.replace(f'/api/{service}', '', 1)
            target_url = f"{service_url}{clean_path}"

            headers = {
                'Content-Type': 'application/json',
                'Authorization': self.headers.get('Authorization', '')
            }

            if method == 'GET':
                response = requests.get(target_url, headers=headers, timeout=5)
            elif method == 'POST':
                response = requests.post(target_url, data=body, headers=headers, timeout=5)
            elif method == 'PUT':
                response = requests.put(target_url, data=body, headers=headers, timeout=5)
            elif method == 'DELETE':
                response = requests.delete(target_url, headers=headers, timeout=5)
            else:
                self.send_json_response({'error': 'Method not allowed'}, 405)
                return

            self.send_response(response.status_code)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(response.content)

        except requests.exceptions.Timeout:
            self.send_json_response({'error': 'Service timeout'}, 504)
        except Exception as e:
            self.send_json_response({'error': f'Gateway error: {str(e)}'}, 500)

    def _check_rate_limit(self) -> bool:
        client_ip = self.client_address[0]
        current_time = time.time()

        if client_ip not in rate_limit_store:
            rate_limit_store[client_ip] = []

        # Remove old requests (older than 60 seconds)
        rate_limit_store[client_ip] = [
            req_time for req_time in rate_limit_store[client_ip]
            if current_time - req_time < 60
        ]

        if len(rate_limit_store[client_ip]) >= RATE_LIMIT:
            return False

        rate_limit_store[client_ip].append(current_time)
        return True

    def _check_services(self) -> Dict[str, str]:
        status = {}
        for service_name, service_url in SERVICES.items():
            try:
                response = requests.get(f"{service_url}/health", timeout=2)
                status[service_name] = 'online' if response.status_code == 200 else 'offline'
            except:
                status[service_name] = 'offline'
        return status

    def send_json_response(self, data: Any, status_code: int = 200):
        self.send_response(status_code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(json.dumps(data).encode('utf-8'))

    def log_message(self, format, *args):
        print(f"[GATEWAY] {format % args}")

if __name__ == '__main__':
    PORT = 5000
    server = HTTPServer(('0.0.0.0', PORT), APIGateway)
    print(f'✓ GearGuard API Gateway running on http://localhost:{PORT}')
    print(f'✓ Routes traffic to microservices')
    print(f'✓ Health check: http://localhost:{PORT}/api/gateway/health')
    server.serve_forever()
