"""
Workflow Service Microservice
Handles maintenance request processing with Saga pattern
State machine for request lifecycle
"""

from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse
import json
import uuid
from typing import Dict, List, Any
from enum import Enum
from datetime import datetime
import sys
import os

# Add shared directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../')))

from shared.event_bus import get_event_bus

class RequestStatus(Enum):
    """Maintenance request status"""
    PENDING = 'pending'
    ASSIGNED = 'assigned'
    IN_PROGRESS = 'in_progress'
    COMPLETED = 'completed'
    CANCELLED = 'cancelled'

class WorkflowService:
    """Maintenance request workflow orchestration"""

    def __init__(self):
        self.requests: Dict[str, Dict[str, Any]] = {}
        self.event_bus = get_event_bus()

    def create_request(self, subject: str, description: str, equipment_id: str,
                      request_type: str, priority: str = 'medium',
                      assigned_team_id: str = None) -> Dict:
        """Create new maintenance request (Saga initiator)"""
        request_id = str(uuid.uuid4())
        
        request = {
            'id': request_id,
            'subject': subject,
            'description': description,
            'equipment_id': equipment_id,
            'request_type': request_type,
            'priority': priority,
            'status': RequestStatus.PENDING.value,
            'assigned_team_id': assigned_team_id,
            'created_at': datetime.now().isoformat(),
            'updated_at': datetime.now().isoformat()
        }
        
        self.requests[request_id] = request
        
        # Publish event to start Saga
        self.event_bus.publish('request.created', {
            'request_id': request_id,
            'equipment_id': equipment_id,
            'assigned_team_id': assigned_team_id,
            'priority': priority
        })
        
        return request

    def assign_request(self, request_id: str, team_id: str, technician_id: str) -> Dict:
        """Assign request to team (Saga step 1)"""
        if request_id not in self.requests:
            return None
        
        self.requests[request_id]['assigned_team_id'] = team_id
        self.requests[request_id]['assigned_technician_id'] = technician_id
        self.requests[request_id]['status'] = RequestStatus.ASSIGNED.value
        self.requests[request_id]['updated_at'] = datetime.now().isoformat()
        
        # Publish event for Saga continuation
        self.event_bus.publish('request.assigned', {
            'request_id': request_id,
            'team_id': team_id,
            'technician_id': technician_id
        })
        
        return self.requests[request_id]

    def start_work(self, request_id: str) -> Dict:
        """Start work on request (Saga step 2)"""
        if request_id not in self.requests:
            return None
        
        self.requests[request_id]['status'] = RequestStatus.IN_PROGRESS.value
        self.requests[request_id]['started_at'] = datetime.now().isoformat()
        self.requests[request_id]['updated_at'] = datetime.now().isoformat()
        
        self.event_bus.publish('request.work_started', {
            'request_id': request_id,
            'started_at': self.requests[request_id]['started_at']
        })
        
        return self.requests[request_id]

    def complete_request(self, request_id: str, hours_spent: float,
                        completion_notes: str = '') -> Dict:
        """Complete request (Saga step 3)"""
        if request_id not in self.requests:
            return None
        
        self.requests[request_id]['status'] = RequestStatus.COMPLETED.value
        self.requests[request_id]['completed_at'] = datetime.now().isoformat()
        self.requests[request_id]['hours_spent'] = hours_spent
        self.requests[request_id]['completion_notes'] = completion_notes
        self.requests[request_id]['updated_at'] = datetime.now().isoformat()
        
        # Publish event to trigger analytics and notifications
        self.event_bus.publish('request.completed', {
            'request_id': request_id,
            'hours_spent': hours_spent,
            'completed_at': self.requests[request_id]['completed_at']
        })
        
        return self.requests[request_id]

    def cancel_request(self, request_id: str, reason: str = '') -> Dict:
        """Cancel request (Saga compensation)"""
        if request_id not in self.requests:
            return None
        
        self.requests[request_id]['status'] = RequestStatus.CANCELLED.value
        self.requests[request_id]['cancellation_reason'] = reason
        self.requests[request_id]['updated_at'] = datetime.now().isoformat()
        
        # Publish compensation event
        self.event_bus.publish('request.cancelled', {
            'request_id': request_id,
            'reason': reason
        })
        
        return self.requests[request_id]

    def get_request(self, request_id: str) -> Dict:
        """Get request details"""
        return self.requests.get(request_id)

    def list_requests(self, status: str = None) -> List[Dict]:
        """List requests, optionally filtered by status"""
        if status:
            return [r for r in self.requests.values() if r['status'] == status]
        return list(self.requests.values())

# Global service instance
workflow_service = WorkflowService()

class WorkflowHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        path = urlparse(self.path).path
        
        try:
            if path == '/requests':
                requests = workflow_service.list_requests()
                self.send_json_response(requests)
            elif path.startswith('/requests/'):
                request_id = path.split('/')[-1]
                request = workflow_service.get_request(request_id)
                if request:
                    self.send_json_response(request)
                else:
                    self.send_json_response({'error': 'Request not found'}, 404)
            elif path == '/health':
                self.send_json_response({'status': 'healthy'})
            else:
                self.send_json_response({'error': 'Not found'}, 404)
        except Exception as e:
            self.send_json_response({'error': str(e)}, 500)

    def do_POST(self):
        path = urlparse(self.path).path
        content_length = int(self.headers.get('Content-Length', 0))
        body = json.loads(self.rfile.read(content_length).decode('utf-8'))

        try:
            if path == '/requests':
                request = workflow_service.create_request(
                    subject=body.get('subject'),
                    description=body.get('description'),
                    equipment_id=body.get('equipment_id'),
                    request_type=body.get('request_type'),
                    priority=body.get('priority', 'medium'),
                    assigned_team_id=body.get('assigned_team_id')
                )
                self.send_json_response(request, 201)
            else:
                self.send_json_response({'error': 'Not found'}, 404)
        except Exception as e:
            self.send_json_response({'error': str(e)}, 500)

    def do_PUT(self):
        path = urlparse(self.path).path
        content_length = int(self.headers.get('Content-Length', 0))
        body = json.loads(self.rfile.read(content_length).decode('utf-8'))

        try:
            if path.startswith('/requests/'):
                request_id = path.split('/')[-1]
                action = body.get('action')
                
                if action == 'assign':
                    request = workflow_service.assign_request(
                        request_id=request_id,
                        team_id=body.get('team_id'),
                        technician_id=body.get('technician_id')
                    )
                elif action == 'start':
                    request = workflow_service.start_work(request_id)
                elif action == 'complete':
                    request = workflow_service.complete_request(
                        request_id=request_id,
                        hours_spent=body.get('hours_spent', 0),
                        completion_notes=body.get('completion_notes', '')
                    )
                elif action == 'cancel':
                    request = workflow_service.cancel_request(
                        request_id=request_id,
                        reason=body.get('reason', '')
                    )
                else:
                    self.send_json_response({'error': 'Invalid action'}, 400)
                    return
                
                if request:
                    self.send_json_response(request)
                else:
                    self.send_json_response({'error': 'Request not found'}, 404)
            else:
                self.send_json_response({'error': 'Not found'}, 404)
        except Exception as e:
            self.send_json_response({'error': str(e)}, 500)

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

    def send_json_response(self, data: Any, status_code: int = 200):
        self.send_response(status_code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(json.dumps(data).encode('utf-8'))

    def log_message(self, format, *args):
        print(f"[WORKFLOW-SERVICE] {format % args}")

if __name__ == '__main__':
    PORT = 5003
    server = HTTPServer(('0.0.0.0', PORT), WorkflowHandler)
    print(f'✓ Workflow Service running on http://localhost:{PORT}')
    print(f'✓ Saga pattern enabled for distributed transactions')
    server.serve_forever()
